function GXflowEntryPoint()
{
	this.Width;
	this.Height;
	this.EntryPoint;
	this.User;
	this.Password;
	this.Scrolling;
	this.Border;

	this.show = function()
	{
		///UserCodeRegionStart:[show] (do not remove this comment.)
		if (!this.IsPostBack){
			var url = '';
			var menu = '';
			
            if (gx.gen.isDotNet())
                url = 'wfentrypoint.aspx';	
			else
				url = 'com.gxflow.wfentrypoint'
		
			switch(this.EntryPoint){

				case "Inbox" : 	
					menu = 'INBOX';
					break;
				case "Outbox" :
					menu = 'OUTBOX';
					break;				
				case "MyProcesses" :
					menu = 'MY_PROCESSES';
					break;				
				case "MyDocuments" :
					menu = 'MY_DOCUMENTS';
					break;					
				case "Processes" :
					menu = 'PROCESSES';
					break;									
				case "Tasks" :
					menu = 'TASKS';
					break;				
				case "BusinessEvents" :
					menu = 'BUSINESS_EVENTS';
					break;									
				case "ProcessDefinitions" :
					menu = 'PROCESS_DEFINITIONS';
					break;	
				case "Participants" :
					menu = 'PARTICIPANTS';
					break;									
				case "Documents" :
					menu = 'DOCUMENTS';
					break;	
				case "Events" :
					menu = 'EVENTS';
					break;	
				case "Users" :
					menu = 'USERS';
					break;	
				case "Roles" :
					menu = 'ROLES';
					break;	
				case "OrganizationalUnitDefinitions" :
					menu = 'ORGANIZATIONAL_UNIT_DEFINITIONS';
					break;	
				case "OrganizationalUnits" :
					menu = 'ORGANIZATIONAL_UNITS';
					break;	
				case "WorkWithDocuments" :
					menu = 'WORK_WITH_DOCUMENTS';
					break;	
				case "History" :
					menu = 'HISTORY';
					break;										
				case "ProcessPerformance" :
					menu = 'PROCESS_PERFORMANCE';
					break;
				case "ProcessAnalysis" :
					menu = 'PROCESS_ANALYSIS';
					break;
				case "TaskPerformance" :
					menu = 'TASK_PERFORMANCE';
					break;
				case "TaskAnalysis" :
					menu = 'TASK_ANALYSIS';
					break;
				case "TeamPerformance" :
					menu = 'TEAM_PERFORMANCE';
					break;
				case "MyPerformance" :
					menu = 'MY_PERFORMANCE';
					break;					
			}
	  
			url += '?' + menu;
			url += ',' + this.ProcessInstanceId;
				
			if (this.User != "")
				url += ',' + this.User + ',' + this.Password;
			
			var tag_iframe = '<iframe id="gxep_iframe" src="' + url + '" width="' + this.Width + '" height="' + this.Height + '" scrolling="' + this.Scrolling + '" frameborder="' + this.Border + '">';
			this.getContainerControl().innerHTML = tag_iframe;
			this.getContainerControl().style.height = "100%";
			
			var iframe = gx.dom.el('gxep_iframe');
			gx.evt.attach(iframe, 'load', popup.closure(this, [iframe]));
			
			function popup (iframe)
			{
				var win = window;
				var iframeWindow = iframe.contentWindow;
				iframeWindow.gx.popup.openPopup = function()
				{
					var popup = win.gx.popup.openPopup.apply(win.gx.popup, arguments);
					var gxO = iframeWindow.gx.O;
					var returnParms, 
						onCloseCmds;
					popup.beforeClose = function () {
						onCloseCmds = this.OncloseCmds;
						this.OncloseCmds = [];
						returnParms = this.getOutputParms();
					};
					popup.afterClose = function (cParms) {
						iframeWindow.gx.ajax.dispatchCommands(onCloseCmds);
						if (cParms && !this.IsPrompt) {
							if (returnParms && gx.lang.isArray(returnParms) && returnParms.length > 0) {
								iframeWindow.gx.fn.setReturnParms(gxO, returnParms, cParms);
							}
						}
					};
					return popup;
				}
			}
			
		}
		///UserCodeRegionEnd: (do not remove this comment.)
	}
	
	///UserCodeRegionStart:[User Functions] (do not remove this comment.)

	///UserCodeRegionEnd: (do not remove this comment.):
}


