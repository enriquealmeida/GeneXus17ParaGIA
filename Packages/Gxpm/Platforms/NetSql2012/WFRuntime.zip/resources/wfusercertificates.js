/*!   GeneXus .NET Framework 17_0_10-161416 on 6/23/2022 1:35:18.35
*/
gx.evt.autoSkip = false;
gx.define('wfusercertificates', true, function (CmpContext) {
   this.ServerClass =  "wfusercertificates" ;
   this.PackageName =  "GXflow.Programs" ;
   this.ServerFullClass =  "wfusercertificates.aspx" ;
   this.setObjectType("web");
   this.setCmpContext(CmpContext);
   this.ReadonlyForm = true;
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
      this.AV40UsrSH=gx.fn.getControlValue("vUSRSH") ;
      this.AV38UsrCod=gx.fn.getControlValue("vUSRCOD") ;
      this.AV13error=gx.fn.getIntegerValue("vERROR",gx.thousandSeparator) ;
      this.AV7Certificates=gx.fn.getControlValue("vCERTIFICATES") ;
   };
   this.Validv_Certvalidfrom=function()
   {
      var currentRow = gx.fn.currentGridRowImpl(5);
      return this.validCliEvt("Validv_Certvalidfrom", 5, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vCERTVALIDFROM");
         this.AnyError  = 0;
         if ( ! ( (new gx.date.gxdate('').compare(this.AV9certValidFrom)===0) || new gx.date.gxdate( this.AV9certValidFrom ).compare( gx.date.ymdhmstot( 1753, 1, 1, 0, 0, 0) ) >= 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Valid From"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Certvalidto=function()
   {
      var currentRow = gx.fn.currentGridRowImpl(5);
      return this.validCliEvt("Validv_Certvalidto", 5, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vCERTVALIDTO");
         this.AnyError  = 0;
         if ( ! ( (new gx.date.gxdate('').compare(this.AV10certValidTo)===0) || new gx.date.gxdate( this.AV10certValidTo ).compare( gx.date.ymdhmstot( 1753, 1, 1, 0, 0, 0) ) >= 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Valid To"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.e152e2_client=function()
   {
      this.clearMessages();
      this.AV46window.Url =  gx.http.formatLink("wfaddcertificate.aspx",[this.AV38UsrCod])  ;
      this.AV46window.ReturnParms =  []  ;
      this.popupOpen(this.AV46window) ;
      this.refreshOutputs([]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e112e2_client=function()
   {
      return this.executeServerEvent("'DELETE'", false, null, false, false);
   };
   this.e162e1_client=function()
   {
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e172e2_client=function()
   {
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,6,7,8,9,10,13,16,18];
   this.GXLastCtrlId =18;
   this.SfcertificatesContainer = new gx.grid.grid(this, 2,"WbpLvl2",5,"Sfcertificates","Sfcertificates","SfcertificatesContainer",this.CmpContext,this.IsMasterPage,"wfusercertificates",[],false,1,false,true,0,false,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),false,false,true,null,null,false,"",false,[1,1,1,1],false,0,false,false);
   var SfcertificatesContainer = this.SfcertificatesContainer;
   SfcertificatesContainer.addCheckBox("Remove",6,"vREMOVE","","","remove","char","Y","N",null,true,false,0,"px","");
   SfcertificatesContainer.addSingleLineEdit("Certid",7,"vCERTID",gx.getMessage( "Code Long"),"","certId","int",0,"px",10,10,"right",null,[],"Certid","certId",false,0,false,false,"Attribute",1,"");
   SfcertificatesContainer.addSingleLineEdit("Certissuedby",8,"vCERTISSUEDBY","","","certIssuedBy","char",100,"px",200,80,"left",null,[],"Certissuedby","certIssuedBy",true,0,false,false,"Attribute",1,"");
   SfcertificatesContainer.addSingleLineEdit("Certvalidfrom",9,"vCERTVALIDFROM","","","certValidFrom","dtime",100,"px",17,17,"right",null,[],"Certvalidfrom","certValidFrom",true,5,false,false,"Attribute",1,"");
   SfcertificatesContainer.addSingleLineEdit("Certvalidto",10,"vCERTVALIDTO","","","certValidTo","dtime",100,"px",17,17,"right",null,[],"Certvalidto","certValidTo",true,5,false,false,"Attribute",1,"");
   this.SfcertificatesContainer.emptyText = gx.getMessage( "");
   this.setGrid(SfcertificatesContainer);
   GXValidFnc[2]={ id: 2, fld:"TABLE11",grid:0};
   GXValidFnc[6]={ id:6 ,lvl:2,type:"char",len:1,dec:0,sign:false,ro:0,isacc:0,grid:5,gxgrid:this.SfcertificatesContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vREMOVE",fmt:0,gxz:"ZV32remove",gxold:"OV32remove",gxvar:"AV32remove",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"checkbox",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV32remove=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV32remove=Value},v2c:function(row){gx.fn.setGridCheckBoxValue("vREMOVE",row || gx.fn.currentGridRowImpl(5),gx.O.AV32remove,"Y")},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV32remove=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vREMOVE",row || gx.fn.currentGridRowImpl(5))},nac:gx.falseFn,values:['Y','N']};
   GXValidFnc[7]={ id:7 ,lvl:2,type:"int",len:10,dec:0,sign:false,pic:"ZZZZZZZZZ9",ro:0,isacc:0,grid:5,gxgrid:this.SfcertificatesContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCERTID",fmt:0,gxz:"ZV5certId",gxold:"OV5certId",gxvar:"AV5certId",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV5certId=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV5certId=gx.num.intval(Value)},v2c:function(row){gx.fn.setGridControlValue("vCERTID",row || gx.fn.currentGridRowImpl(5),gx.O.AV5certId,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV5certId=gx.num.intval(this.val(row))},val:function(row){return gx.fn.getGridIntegerValue("vCERTID",row || gx.fn.currentGridRowImpl(5),gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[8]={ id:8 ,lvl:2,type:"char",len:200,dec:0,sign:false,ro:0,isacc:0,grid:5,gxgrid:this.SfcertificatesContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCERTISSUEDBY",fmt:0,gxz:"ZV8certIssuedBy",gxold:"OV8certIssuedBy",gxvar:"AV8certIssuedBy",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV8certIssuedBy=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV8certIssuedBy=Value},v2c:function(row){gx.fn.setGridControlValue("vCERTISSUEDBY",row || gx.fn.currentGridRowImpl(5),gx.O.AV8certIssuedBy,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV8certIssuedBy=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vCERTISSUEDBY",row || gx.fn.currentGridRowImpl(5))},nac:gx.falseFn};
   GXValidFnc[9]={ id:9 ,lvl:2,type:"dtime",len:8,dec:5,sign:false,ro:0,isacc:0,grid:5,gxgrid:this.SfcertificatesContainer,fnc:this.Validv_Certvalidfrom,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCERTVALIDFROM",fmt:0,gxz:"ZV9certValidFrom",gxold:"OV9certValidFrom",gxvar:"AV9certValidFrom",dp:{f:0,st:true,wn:false,mf:false,pic:"99/99/99 99:99",dec:5},ucs:[],op:[9],ip:[9],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV9certValidFrom=gx.fn.toDatetimeValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV9certValidFrom=gx.fn.toDatetimeValue(Value)},v2c:function(row){gx.fn.setGridControlValue("vCERTVALIDFROM",row || gx.fn.currentGridRowImpl(5),gx.O.AV9certValidFrom,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV9certValidFrom=gx.fn.toDatetimeValue(this.val(row))},val:function(row){return gx.fn.getGridDateTimeValue("vCERTVALIDFROM",row || gx.fn.currentGridRowImpl(5))},nac:gx.falseFn};
   GXValidFnc[10]={ id:10 ,lvl:2,type:"dtime",len:8,dec:5,sign:false,ro:0,isacc:0,grid:5,gxgrid:this.SfcertificatesContainer,fnc:this.Validv_Certvalidto,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCERTVALIDTO",fmt:0,gxz:"ZV10certValidTo",gxold:"OV10certValidTo",gxvar:"AV10certValidTo",dp:{f:0,st:true,wn:false,mf:false,pic:"99/99/99 99:99",dec:5},ucs:[],op:[10],ip:[10],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV10certValidTo=gx.fn.toDatetimeValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV10certValidTo=gx.fn.toDatetimeValue(Value)},v2c:function(row){gx.fn.setGridControlValue("vCERTVALIDTO",row || gx.fn.currentGridRowImpl(5),gx.O.AV10certValidTo,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV10certValidTo=gx.fn.toDatetimeValue(this.val(row))},val:function(row){return gx.fn.getGridDateTimeValue("vCERTVALIDTO",row || gx.fn.currentGridRowImpl(5))},nac:gx.falseFn};
   GXValidFnc[13]={ id: 13, fld:"TBLBUTTONS",grid:0};
   GXValidFnc[16]={ id: 16, fld:"BTNADD",grid:0,evt:"e162e1_client",std:"ENTER"};
   GXValidFnc[18]={ id: 18, fld:"BTNDELETE",grid:0,evt:"e112e2_client"};
   this.ZV32remove = "" ;
   this.OV32remove = "" ;
   this.ZV5certId = 0 ;
   this.OV5certId = 0 ;
   this.ZV8certIssuedBy = "" ;
   this.OV8certIssuedBy = "" ;
   this.ZV9certValidFrom = gx.date.nullDate() ;
   this.OV9certValidFrom = gx.date.nullDate() ;
   this.ZV10certValidTo = gx.date.nullDate() ;
   this.OV10certValidTo = gx.date.nullDate() ;
   this.AV38UsrCod = "" ;
   this.AV42wfmode = "" ;
   this.AV32remove = "" ;
   this.AV5certId = 0 ;
   this.AV8certIssuedBy = "" ;
   this.AV9certValidFrom = gx.date.nullDate() ;
   this.AV10certValidTo = gx.date.nullDate() ;
   this.AV40UsrSH = "" ;
   this.AV13error = 0 ;
   this.AV7Certificates = [ ] ;
   this.AV46window = {} ;
   this.Events = {"e112e2_client": ["'DELETE'", true] ,"e162e1_client": ["ENTER", true] ,"e172e2_client": ["CANCEL", true] ,"e152e2_client": ["'ADD'", false]};
   this.EvtParms["REFRESH"] = [[{av:'SFCERTIFICATES_nFirstRecordOnPage'},{av:'SFCERTIFICATES_nEOF'},{av:'gx.fn.getCtrlProperty("vREMOVE","Visible")',ctrl:'vREMOVE',prop:'Visible'},{ctrl:'vCERTISSUEDBY',prop:'Titleformat'},{av:'gx.fn.getCtrlProperty("vCERTISSUEDBY","Title")',ctrl:'vCERTISSUEDBY',prop:'Title'},{ctrl:'vCERTVALIDFROM',prop:'Titleformat'},{av:'gx.fn.getCtrlProperty("vCERTVALIDFROM","Title")',ctrl:'vCERTVALIDFROM',prop:'Title'},{ctrl:'vCERTVALIDTO',prop:'Titleformat'},{av:'gx.fn.getCtrlProperty("vCERTVALIDTO","Title")',ctrl:'vCERTVALIDTO',prop:'Title'},{av:'AV38UsrCod',fld:'vUSRCOD',pic:'@!'},{av:'AV13error',fld:'vERROR',pic:'ZZZ9'},{av:'AV7Certificates',fld:'vCERTIFICATES',pic:''},{av:'sPrefix'},{av:'AV40UsrSH',fld:'vUSRSH',pic:''}],[]];
   this.EvtParms["VALIDV_CERTVALIDFROM"] = [[{av:'AV9certValidFrom',fld:'vCERTVALIDFROM',pic:'99/99/99 99:99'}],[{av:'AV9certValidFrom',fld:'vCERTVALIDFROM',pic:'99/99/99 99:99'}]];
   this.EvtParms["VALIDV_CERTVALIDTO"] = [[{av:'AV10certValidTo',fld:'vCERTVALIDTO',pic:'99/99/99 99:99'}],[{av:'AV10certValidTo',fld:'vCERTVALIDTO',pic:'99/99/99 99:99'}]];
   this.EnterCtrl = ["BTNADD"];
   this.setVCMap("AV40UsrSH", "vUSRSH", 0, "svchar", 200, 100);
   this.setVCMap("AV38UsrCod", "vUSRCOD", 0, "svchar", 100, 40);
   this.setVCMap("AV13error", "vERROR", 0, "int", 4, 0);
   this.setVCMap("AV7Certificates", "vCERTIFICATES", 0, "CollCAPkiCertificateSDT", 0, 0);
   this.setVCMap("AV40UsrSH", "vUSRSH", 0, "svchar", 200, 100);
   this.setVCMap("AV38UsrCod", "vUSRCOD", 0, "svchar", 100, 40);
   this.setVCMap("AV13error", "vERROR", 0, "int", 4, 0);
   this.setVCMap("AV7Certificates", "vCERTIFICATES", 0, "CollCAPkiCertificateSDT", 0, 0);
   SfcertificatesContainer.addRefreshingVar({rfrVar:"AV32remove", rfrProp:"Visible", gxAttId:"Remove"});
   SfcertificatesContainer.addRefreshingVar({rfrVar:"AV8certIssuedBy", rfrProp:"Titleformat", gxAttId:"Certissuedby"});
   SfcertificatesContainer.addRefreshingVar({rfrVar:"AV8certIssuedBy", rfrProp:"Title", gxAttId:"Certissuedby"});
   SfcertificatesContainer.addRefreshingVar({rfrVar:"AV9certValidFrom", rfrProp:"Titleformat", gxAttId:"Certvalidfrom"});
   SfcertificatesContainer.addRefreshingVar({rfrVar:"AV9certValidFrom", rfrProp:"Title", gxAttId:"Certvalidfrom"});
   SfcertificatesContainer.addRefreshingVar({rfrVar:"AV10certValidTo", rfrProp:"Titleformat", gxAttId:"Certvalidto"});
   SfcertificatesContainer.addRefreshingVar({rfrVar:"AV10certValidTo", rfrProp:"Title", gxAttId:"Certvalidto"});
   SfcertificatesContainer.addRefreshingVar({rfrVar:"AV40UsrSH"});
   SfcertificatesContainer.addRefreshingVar({rfrVar:"AV38UsrCod"});
   SfcertificatesContainer.addRefreshingVar({rfrVar:"AV13error"});
   SfcertificatesContainer.addRefreshingVar({rfrVar:"AV7Certificates"});
   SfcertificatesContainer.addRefreshingParm({rfrVar:"AV32remove", rfrProp:"Visible", gxAttId:"Remove"});
   SfcertificatesContainer.addRefreshingParm({rfrVar:"AV8certIssuedBy", rfrProp:"Titleformat", gxAttId:"Certissuedby"});
   SfcertificatesContainer.addRefreshingParm({rfrVar:"AV8certIssuedBy", rfrProp:"Title", gxAttId:"Certissuedby"});
   SfcertificatesContainer.addRefreshingParm({rfrVar:"AV9certValidFrom", rfrProp:"Titleformat", gxAttId:"Certvalidfrom"});
   SfcertificatesContainer.addRefreshingParm({rfrVar:"AV9certValidFrom", rfrProp:"Title", gxAttId:"Certvalidfrom"});
   SfcertificatesContainer.addRefreshingParm({rfrVar:"AV10certValidTo", rfrProp:"Titleformat", gxAttId:"Certvalidto"});
   SfcertificatesContainer.addRefreshingParm({rfrVar:"AV10certValidTo", rfrProp:"Title", gxAttId:"Certvalidto"});
   SfcertificatesContainer.addRefreshingParm({rfrVar:"AV40UsrSH"});
   SfcertificatesContainer.addRefreshingParm({rfrVar:"AV38UsrCod"});
   SfcertificatesContainer.addRefreshingParm({rfrVar:"AV13error"});
   SfcertificatesContainer.addRefreshingParm({rfrVar:"AV7Certificates"});
   this.Initialize( );
});
