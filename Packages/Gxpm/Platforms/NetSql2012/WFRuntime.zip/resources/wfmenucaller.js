/*!   GeneXus .NET Framework 17_0_10-161416 on 6/23/2022 1:35:20.35
*/
gx.evt.autoSkip = false;
gx.define('wfmenucaller', true, function (CmpContext) {
   this.ServerClass =  "wfmenucaller" ;
   this.PackageName =  "GXflow.Programs" ;
   this.ServerFullClass =  "wfmenucaller.aspx" ;
   this.setObjectType("web");
   this.setCmpContext(CmpContext);
   this.ReadonlyForm = true;
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
   };
   this.e131l2_client=function()
   {
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e141l2_client=function()
   {
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXLastCtrlId =0;
   this.PANELContainer = gx.uc.getNew(this, 2, 0, "gxui.Panel", this.CmpContext + "PANELContainer", "Panel", "PANEL");
   var PANELContainer = this.PANELContainer;
   PANELContainer.setProp("Class", "Class", "", "char");
   PANELContainer.setProp("Enabled", "Enabled", true, "boolean");
   PANELContainer.setProp("Width", "Width", 100, "num");
   PANELContainer.setProp("Height", "Height", 100, "num");
   PANELContainer.setProp("Draggable", "Draggable", "false", "str");
   PANELContainer.setProp("ShowAsWindow", "Showaswindow", false, "bool");
   PANELContainer.setProp("Layout", "Layout", "default", "str");
   PANELContainer.setProp("AddToParentGxUIControl", "Addtoparentgxuicontrol", true, "bool");
   PANELContainer.setProp("ButtonPressedId", "Buttonpressedid", "", "char");
   PANELContainer.setProp("EditFieldValue", "Editfieldvalue", "", "char");
   PANELContainer.setProp("Visible", "Visible", true, "boolean");
   PANELContainer.setProp("Refresh", "Refresh", false, "boolean");
   PANELContainer.setProp("AutoWidth", "Autowidth", "true", "str");
   PANELContainer.setProp("AutoHeight", "Autoheight", "false", "str");
   PANELContainer.setDynProp("Title", "Title", "", "str");
   PANELContainer.setProp("IconCls", "Iconcls", "", "str");
   PANELContainer.setProp("Cls", "Cls", "", "str");
   PANELContainer.setProp("Frame", "Frame", "true", "str");
   PANELContainer.setProp("Border", "Border", true, "bool");
   PANELContainer.setProp("Modal", "Modal", false, "bool");
   PANELContainer.setProp("UseToolbar", "Usetoolbar", "false", "str");
   PANELContainer.addV2CFunction('AV11gxuiToolbar', "vGXUITOOLBAR", 'SetToolbarData');
   PANELContainer.addC2VFunction(function(UC) { UC.ParentObject.AV11gxuiToolbar=UC.GetToolbarData();gx.fn.setControlValue("vGXUITOOLBAR",UC.ParentObject.AV11gxuiToolbar); });
   PANELContainer.setProp("Resizable", "Resizable", "false", "str");
   PANELContainer.setProp("MinWidth", "Minwidth", 100, "num");
   PANELContainer.setProp("MaxWidth", "Maxwidth", 800, "num");
   PANELContainer.setProp("MinHeight", "Minheight", 100, "num");
   PANELContainer.setProp("MaxHeight", "Maxheight", 600, "num");
   PANELContainer.setProp("Pinned", "Pinned", "true", "str");
   PANELContainer.setProp("Handles", "Handles", "s e se", "str");
   PANELContainer.setProp("Collapsible", "Collapsible", "false", "str");
   PANELContainer.setProp("Collapsed", "Collapsed", "false", "str");
   PANELContainer.setProp("AnimateCollapse", "Animatecollapse", "false", "str");
   PANELContainer.setProp("Stateful", "Stateful", "true", "str");
   PANELContainer.setProp("StateId", "Stateid", "", "str");
   PANELContainer.setC2ShowFunction(function(UC) { UC.show(); });
   this.setUserControl(PANELContainer);
   this.AV11gxuiToolbar = {Buttons:[],SeparateAll:false,MaxButtons:0} ;
   this.AV8menu = "" ;
   this.A791WFSubMenuId = "" ;
   this.A863WFSubMenuName = "" ;
   this.A864WFSubMenuObj = "" ;
   this.A865WFSubMenuParm = "" ;
   this.Events = {"e131l2_client": ["ENTER", true] ,"e141l2_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[],[]];
   this.Initialize( );
});
