/*!   GeneXus Java 17_0_10-161416 on June 23, 2022 1:51:48.6
*/
gx.evt.autoSkip = false;
gx.define('wferrorpopup', true, function (CmpContext) {
   this.ServerClass =  "wferrorpopup" ;
   this.PackageName =  "com.gxflow" ;
   this.ServerFullClass =  "com.gxflow.wferrorpopup" ;
   this.setObjectType("web");
   this.setCmpContext(CmpContext);
   this.ReadonlyForm = true;
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
   };
   this.e131o2_client=function()
   {
      return this.executeServerEvent("'CLEAN'", true, null, false, false);
   };
   this.e151o2_client=function()
   {
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e161o2_client=function()
   {
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXLastCtrlId =0;
   this.MSGContainer = gx.uc.getNew(this, 2, 0, "gxui.Message", this.CmpContext + "MSGContainer", "Msg", "MSG");
   var MSGContainer = this.MSGContainer;
   MSGContainer.setProp("Class", "Class", "", "char");
   MSGContainer.setProp("Enabled", "Enabled", true, "boolean");
   MSGContainer.setProp("Width", "Width", "100", "str");
   MSGContainer.setProp("Height", "Height", "100", "str");
   MSGContainer.setDynProp("Show", "Show", "true", "str");
   MSGContainer.setProp("Title", "Title", gx.getMessage( "GXWF_Error"), "str");
   MSGContainer.setDynProp("Message", "Message", "", "str");
   MSGContainer.setProp("Type", "Type", "notification", "str");
   MSGContainer.setProp("Icon", "Icon", "error", "str");
   MSGContainer.setProp("Cls", "Cls", "x-box-error-popup", "str");
   MSGContainer.setProp("Position", "Position", "t", "str");
   MSGContainer.setProp("Duration", "Duration", 2, "num");
   MSGContainer.setProp("Visible", "Visible", true, "bool");
   MSGContainer.setC2ShowFunction(function(UC) { UC.show(); });
   this.setUserControl(MSGContainer);
   this.Events = {"e131o2_client": ["'CLEAN'", true] ,"e151o2_client": ["ENTER", true] ,"e161o2_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{av:'AV6errorMsg',fld:'vERRORMSG',pic:''}],[{av:'AV6errorMsg',fld:'vERRORMSG',pic:''},{av:'this.MSGContainer.Message',ctrl:'MSG',prop:'Message'},{av:'this.MSGContainer.Show',ctrl:'MSG',prop:'Show'}]];
   this.Initialize( );
});
