/*!   GeneXus Java 17_0_10-161416 on June 23, 2022 1:51:51.91
*/
gx.evt.autoSkip = false;
gx.define('wfnotificationtemplates', true, function (CmpContext) {
   this.ServerClass =  "wfnotificationtemplates" ;
   this.PackageName =  "com.gxflow" ;
   this.ServerFullClass =  "com.gxflow.wfnotificationtemplates" ;
   this.setObjectType("web");
   this.setCmpContext(CmpContext);
   this.ReadonlyForm = true;
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
   };
   this.s212_client=function()
   {
      this.AV13refreshNow =  true  ;
      gx.fn.setCtrlProperty("vREFRESHGRID","Visible", 0 );
   };
   this.s122_client=function()
   {
      if ( ( this.AV12refreshGrid == true ) && ( this.AV13refreshNow == true ) )
      {
         this.s202_client();
         this.AV12refreshGrid =  false  ;
      }
   };
   this.s202_client=function()
   {
      this.GRIDContainer.Refresh() ;
   };
   this.s162_client=function()
   {
      this.AV21window.Url =  gx.http.formatLink("com.gxflow.wfnotificationtemplate",[this.AV23templateId, "DSP"])  ;
      this.AV21window.ReturnParms =  ["AV23templateId"]  ;
      this.popupOpen(this.AV21window) ;
   };
   this.e121f2_client=function()
   {
      return this.executeServerEvent("GRID.LOADEXCEPTION", false, null, true, true);
   };
   this.e111f2_client=function()
   {
      return this.executeServerEvent("GRID.BUTTONPRESSED", false, null, true, true);
   };
   this.e161f2_client=function()
   {
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e171f2_client=function()
   {
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[4];
   this.GXLastCtrlId =4;
   this.GRIDContainer = gx.uc.getNew(this, 3, 0, "gxui.Grid", this.CmpContext + "GRIDContainer", "Grid", "GRID");
   var GRIDContainer = this.GRIDContainer;
   GRIDContainer.setProp("Class", "Class", "", "char");
   GRIDContainer.setProp("Enabled", "Enabled", true, "boolean");
   GRIDContainer.setProp("Width", "Width", 100, "num");
   GRIDContainer.setProp("Height", "Height", 100, "num");
   GRIDContainer.setProp("ButtonPressedId", "Buttonpressedid", "", "char");
   GRIDContainer.setProp("LoadExceptionError", "Loadexceptionerror", "", "char");
   GRIDContainer.setProp("EditFieldValue", "Editfieldvalue", "", "char");
   GRIDContainer.setProp("AutoWidth", "Autowidth", "false", "str");
   GRIDContainer.setProp("AutoHeight", "Autoheight", "false", "str");
   GRIDContainer.setProp("ForceFit", "Forcefit", "true", "str");
   GRIDContainer.setProp("AutoExpandColumn", "Autoexpandcolumn", "", "str");
   GRIDContainer.setProp("Title", "Title", "", "str");
   GRIDContainer.setProp("IconCls", "Iconcls", "", "str");
   GRIDContainer.setProp("Cls", "Cls", "", "str");
   GRIDContainer.setProp("Frame", "Frame", "false", "str");
   GRIDContainer.setProp("StripeRows", "Striperows", "true", "str");
   GRIDContainer.setProp("UseToolbar", "Usetoolbar", "true", "str");
   GRIDContainer.addV2CFunction('AV18toolbar', "vTOOLBAR", 'SetToolbarData');
   GRIDContainer.addC2VFunction(function(UC) { UC.ParentObject.AV18toolbar=UC.GetToolbarData();gx.fn.setControlValue("vTOOLBAR",UC.ParentObject.AV18toolbar); });
   GRIDContainer.setProp("AddSearchField", "Addsearchfield", "true", "str");
   GRIDContainer.setProp("SearchFieldWidth", "Searchfieldwidth", 200, "num");
   GRIDContainer.setProp("SearchFieldAutoRefresh", "Searchfieldautorefresh", true, "bool");
   GRIDContainer.setProp("SearchFieldAutoRefreshTimeout", "Searchfieldautorefreshtimeout", 350, "num");
   GRIDContainer.setProp("UseFilters", "Usefilters", "true", "str");
   GRIDContainer.setProp("FiltersMode", "Filtersmode", "menu", "str");
   GRIDContainer.setProp("LocalFilters", "Localfilters", "false", "str");
   GRIDContainer.setProp("AutoReloadFilters", "Autoreloadfilters", "true", "str");
   GRIDContainer.setProp("FiltersStateId", "Filtersstateid", "", "str");
   GRIDContainer.setProp("FiltersCls", "Filterscls", "", "str");
   GRIDContainer.setProp("ShowFiltersMenu", "Showfiltersmenu", "true", "str");
   GRIDContainer.setDynProp("FiltersText", "Filterstext", "Filters", "str");
   GRIDContainer.setDynProp("YesText", "Yestext", "Yes", "str");
   GRIDContainer.setDynProp("NoText", "Notext", "No", "str");
   GRIDContainer.setDynProp("BeforeText", "Beforetext", "Before", "str");
   GRIDContainer.setDynProp("AfterText", "Aftertext", "After", "str");
   GRIDContainer.setDynProp("OnText", "Ontext", "On", "str");
   GRIDContainer.setProp("TreeMode", "Treemode", "false", "str");
   GRIDContainer.setProp("TreeParentField", "Treeparentfield", "_parent", "str");
   GRIDContainer.setProp("TreeIsLeafField", "Treeisleaffield", "_is_leaf", "str");
   GRIDContainer.setProp("TreeMasterColumn", "Treemastercolumn", "", "str");
   GRIDContainer.setProp("TreeRootTitle", "Treeroottitle", "", "str");
   GRIDContainer.setProp("Resizable", "Resizable", "false", "str");
   GRIDContainer.setProp("MinWidth", "Minwidth", 100, "num");
   GRIDContainer.setProp("MaxWidth", "Maxwidth", 800, "num");
   GRIDContainer.setProp("MinHeight", "Minheight", 100, "num");
   GRIDContainer.setProp("MaxHeigt", "Maxheight", 600, "num");
   GRIDContainer.setProp("Wrap", "Wrap", "true", "str");
   GRIDContainer.setProp("Pinned", "Pinned", "true", "str");
   GRIDContainer.setProp("Handles", "Handles", "s e se", "str");
   GRIDContainer.setProp("Collapsible", "Collapsible", "false", "str");
   GRIDContainer.setProp("AnimateCollapse", "Animatecollapse", "false", "str");
   GRIDContainer.setProp("TrackMouseOver", "Trackmouseover", "true", "str");
   GRIDContainer.setProp("SelectionModel", "Selectionmodel", "RowSelectionModel", "str");
   GRIDContainer.setProp("SingleSelect", "Singleselect", "false", "str");
   GRIDContainer.setProp("LockSelections", "Lockselections", "false", "str");
   GRIDContainer.addV2CFunction('AV16selectedRows', "vSELECTEDROWS", 'SetSelectedRowData');
   GRIDContainer.addC2VFunction(function(UC) { UC.ParentObject.AV16selectedRows=UC.GetSelectedRowData();gx.fn.setControlValue("vSELECTEDROWS",UC.ParentObject.AV16selectedRows); });
   GRIDContainer.setProp("Grouping", "Grouping", "true", "str");
   GRIDContainer.setProp("GroupField", "Groupfield", "", "str");
   GRIDContainer.setProp("HideGroupedField", "Hidegroupedfield", "true", "str");
   GRIDContainer.setProp("GroupTemplate", "Grouptemplate", "{text}", "str");
   GRIDContainer.setProp("EnableDragDrop", "Enabledragdrop", "true", "str");
   GRIDContainer.setProp("AutoSizeColumns", "Autosizecolumns", "true", "str");
   GRIDContainer.setProp("MinColumnWidth", "Mincolumnwidth", 25, "num");
   GRIDContainer.setProp("EnableColumnHide", "Enablecolumnhide", "true", "str");
   GRIDContainer.setProp("EnableColumnMove", "Enablecolumnmove", "true", "str");
   GRIDContainer.setProp("DefaultSortable", "Defaultsortable", "true", "str");
   GRIDContainer.setProp("DefaultResizable", "Defaultresizable", "true", "str");
   GRIDContainer.setProp("LoadingIndicator", "Loadingindicator", "true", "str");
   GRIDContainer.setDynProp("LoadingMsg", "Loadingmsg", "Loading...", "str");
   GRIDContainer.setProp("AutoRefresh", "Autorefresh", false, "bool");
   GRIDContainer.setProp("RefreshTimeout", "Refreshtimeout", 300, "num");
   GRIDContainer.setProp("Paging", "Paging", "true", "str");
   GRIDContainer.setDynProp("PageSize", "Pagesize", 10, "num");
   GRIDContainer.setProp("DisplayInfo", "Displayinfo", "true", "str");
   GRIDContainer.setDynProp("DisplayMsg", "Displaymsg", "Displaying results {0} - {1} of {2}", "str");
   GRIDContainer.setDynProp("EmptyMsg", "Emptymsg", "No results to display", "str");
   GRIDContainer.setDynProp("AfterPageText", "Afterpagetext", "of {0}", "str");
   GRIDContainer.setDynProp("BeforePageText", "Beforepagetext", "Page", "str");
   GRIDContainer.setDynProp("FirstText", "Firsttext", "First Page", "str");
   GRIDContainer.setDynProp("LastText", "Lasttext", "Last Page", "str");
   GRIDContainer.setDynProp("NextText", "Nexttext", "Next Page", "str");
   GRIDContainer.setDynProp("PreviousText", "Previoustext", "Previous Page", "str");
   GRIDContainer.setDynProp("RefreshText", "Refreshtext", "Refresh", "str");
   GRIDContainer.setProp("RemoteSort", "Remotesort", "true", "str");
   GRIDContainer.setProp("DefaultSortField", "Defaultsortfield", "created", "str");
   GRIDContainer.setProp("DefaultSortDir", "Defaultsortdirection", "DESC", "str");
   GRIDContainer.addV2CFunction('AV5columnModel', "vCOLUMNMODEL", 'SetColumnModel');
   GRIDContainer.addC2VFunction(function(UC) { UC.ParentObject.AV5columnModel=UC.GetColumnModel();gx.fn.setControlValue("vCOLUMNMODEL",UC.ParentObject.AV5columnModel); });
   GRIDContainer.addV2CFunction('AV6data', "vDATA", 'SetData');
   GRIDContainer.addC2VFunction(function(UC) { UC.ParentObject.AV6data=UC.GetData();gx.fn.setControlValue("vDATA",UC.ParentObject.AV6data); });
   GRIDContainer.setProp("Root", "Root", "Items", "str");
   GRIDContainer.setDynProp("DataStoreURL", "Datastoreurl", "", "str");
   GRIDContainer.setProp("DataStoreParms", "Datastoreparms", '', "str");
   GRIDContainer.setProp("Record", "Record", "Item", "str");
   GRIDContainer.setProp("Identifier", "Identifier", "id", "str");
   GRIDContainer.setProp("Total", "Total", "Total", "str");
   GRIDContainer.setProp("Stateful", "Stateful", "true", "str");
   GRIDContainer.setDynProp("StateId", "Stateid", "", "str");
   GRIDContainer.setProp("Visible", "Visible", true, "bool");
   GRIDContainer.setC2ShowFunction(function(UC) { UC.show(); });
   GRIDContainer.addEventHandler("ButtonPressed", this.e111f2_client);
   GRIDContainer.addEventHandler("LoadException", this.e121f2_client);
   this.setUserControl(GRIDContainer);
   GXValidFnc[4]={ id:4 ,lvl:0,type:"boolean",len:4,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vREFRESHGRID",fmt:0,gxz:"ZV12refreshGrid",gxold:"OV12refreshGrid",gxvar:"AV12refreshGrid",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV12refreshGrid=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV12refreshGrid=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setControlValue("vREFRESHGRID",gx.O.AV12refreshGrid,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV12refreshGrid=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vREFRESHGRID")},nac:gx.falseFn};
   this.AV12refreshGrid = false ;
   this.ZV12refreshGrid = false ;
   this.OV12refreshGrid = false ;
   this.AV18toolbar = {Buttons:[],SeparateAll:false,MaxButtons:0} ;
   this.AV12refreshGrid = false ;
   this.AV9menu = "" ;
   this.AV13refreshNow = false ;
   this.AV23templateId = 0 ;
   this.AV21window = {} ;
   this.Events = {"e121f2_client": ["GRID.LOADEXCEPTION", true] ,"e111f2_client": ["GRID.BUTTONPRESSED", true] ,"e161f2_client": ["ENTER", true] ,"e171f2_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{av:'AV12refreshGrid',fld:'vREFRESHGRID',pic:''},{av:'AV13refreshNow',fld:'vREFRESHNOW',pic:''}],[{av:'AV12refreshGrid',fld:'vREFRESHGRID',pic:''}]];
   this.Initialize( );
});
