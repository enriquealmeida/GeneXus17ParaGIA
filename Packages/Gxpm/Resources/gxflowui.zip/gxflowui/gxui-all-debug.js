/*
 * gxui Library 1.1 beta (Build 353)
 * Copyright (c) 2009, Artech
 * All rights reserved.
 * 
 * gxui Library is freely distributable under the terms of the BSD license.
 * 
 */


Ext.form.ColorField = function(config){
    Ext.form.ColorField.superclass.constructor.call(this, config);
};

Ext.extend(Ext.form.ColorField, Ext.form.TriggerField,  {
    
    invalidText : "{0} is not a valid color - it must be in a the hex format {1}",
    
    triggerClass : 'x-form-color-trigger',
    

    // private
    defaultAutoCreate : {tag: "input", type: "text", size: "10", maxlength: "7", autocomplete: "off"},

    // Limit input to hex values
    maskRe: /[a-f0-9]/i,
    regex: /[a-f0-9]/i,

    // private
    validateValue : function(value){
        if(!Ext.form.ColorField.superclass.validateValue.call(this, value)){
            return false;
        }
        if(value.length < 1){ // if it's blank and textfield didn't flag it then it's valid
             return true;
        }

        var parseOK = this.parseColor(value);

        if(!value || (parseOK == false)){
            this.markInvalid(String.format(this.invalidText, value, '#AABBCC'));
            return false;
        }

        return true;
    },

    // private
    // Provides logic to override the default TriggerField.validateBlur which just returns true
    validateBlur : function(){
        return !this.menu || !this.menu.isVisible();
    },

    
    getValue : function(){
        return Ext.form.ColorField.superclass.getValue.call(this) || "";
    },

    
    setValue : function(color){
        Ext.form.ColorField.superclass.setValue.call(this, this.formatColor(color));
    },

    // private
    parseColor : function(value){
	return (!value || (value.substring(0,1) != '#')) ?
		false : true;
    },

    // private
    formatColor : function(value){
	if (value && (this.parseColor(value) == false)) {
		value = '#' + value;
	}

        return value;
    },

    // private
    menuListeners : {
        select: function(e, c){
            this.setValue(c);
        },
        show : function(){ // retain focus styling
            this.onFocus();
        },
        hide : function(){
            this.focus();
            var ml = this.menuListeners;
            this.menu.un("select", ml.select,  this);
            this.menu.un("show", ml.show,  this);
            this.menu.un("hide", ml.hide,  this);
        }
    },

    // private
    // Implements the default empty TriggerField.onTriggerClick function to display the ColorPalette
    onTriggerClick : function(){
        if(this.disabled){
            return;
        }
        if(this.menu == null){
            this.menu = new Ext.menu.ColorMenu();
        }

        this.menu.on(Ext.apply({}, this.menuListeners, {
            scope:this
        }));

        this.menu.show(this.el, "tl-bl?");
    }
});
Ext.ComponentMgr.registerType('colorfield', Ext.form.ColorField);
Ext.ux.NestedViewport = Ext.extend(Ext.Container, {
	initComponent : function() {
        Ext.ux.NestedViewport.superclass.initComponent.call(this);
        document.getElementsByTagName('html')[0].className += ' x-viewport';
		this.renderTo = Ext.get(this.renderTo);
		this.renderTo.addClass("x-nested");
		
        this.el = this.renderTo;
        this.el.setHeight = Ext.emptyFn;
        this.el.setWidth = Ext.emptyFn;
        this.el.setSize = Ext.emptyFn;
        this.el.dom.scroll = 'no';
        this.allowDomMove = false;
        this.autoWidth = true;
        this.autoHeight = true;
        Ext.EventManager.onWindowResize(this.fireResize, this);
	},
	
	fireResize : function(w, h){
	    this.fireEvent('resize', this, w, h, w, h);
    }
});
Ext.reg('xnestedviewport', Ext.ux.NestedViewport);


Ext.menu.EditableItem = Ext.extend(Ext.menu.BaseItem, {
    itemCls : "x-menu-item",
    hideOnClick: false,
    
    initComponent: function(){
      Ext.menu.EditableItem.superclass.initComponent.call(this);
    	this.addEvents('keyup');
    	
			this.editor = this.editor || new Ext.form.TextField();
			if(this.text) {
				this.editor.setValue(this.text);
      }
    },
	
	onRender: function(container){
        var s = container.createChild({
        	cls: this.itemCls,
        	html: String.format(
                '<img src="{0}" class="x-menu-item-icon x-menu-editable-icon {1}" />',
                this.icon || Ext.BLANK_IMAGE_URL, this.iconCls || '')
		});	
    
        Ext.apply(this.config, {width: 125});
        this.editor.render(s);
        
        this.el = s;
        this.relayEvents(this.editor.el, ["keyup"]);
        
        if(Ext.isGecko) {
    			s.setStyle('overflow', 'auto');
        }
			
        Ext.menu.EditableItem.superclass.onRender.call(this, container);
    },
    
    getValue: function(){
    	return this.editor.getValue();
    },
    
    setValue: function(value){
    	this.editor.setValue(value);
    },
    
    isValid: function(preventMark){
    	return this.editor.isValid(preventMark);
    }
});


Ext.menu.RangeMenu = function(config){
	Ext.menu.RangeMenu.superclass.constructor.call(this, config);
  
	this.updateTask = new Ext.util.DelayedTask(this.fireUpdate, this);

	var cfg = this.fieldCfg;
	var cls = this.fieldCls;
	var fields = this.fields = Ext.applyIf(this.fields || {}, {
		'gt': new Ext.menu.EditableItem({
			iconCls: 'x-filter-icon-gt',
			editor: new cls(typeof cfg == "object" ? cfg.gt || '' : cfg)}),
		'lt': new Ext.menu.EditableItem({
			iconCls: 'x-filter-icon-lt',
			editor: new cls(typeof cfg == "object" ? cfg.lt || '' : cfg)}),
		'eq': new Ext.menu.EditableItem({
			iconCls:  'x-filter-icon-eq',
			editor: new cls(typeof cfg == "object" ? cfg.gt || '' : cfg)})
	});
	
	this.add(fields.gt, fields.lt, '-', fields.eq);
	
	for(var key in fields) {
		fields[key].on('keyup', this.onKeyUp.createDelegate(this, [fields[key]], true), this);
  }
  
	this.addEvents('update');
};

Ext.extend(Ext.menu.RangeMenu, Ext.menu.Menu, {
	fieldCls:     Ext.form.NumberField,
	fieldCfg:     '',
	updateBuffer: 500,
		
	fireUpdate: function() {
		this.fireEvent("update", this);
	},
	
	setValue: function(data) {
		for(var key in this.fields) {
			this.fields[key].setValue(data[key] !== undefined ? data[key] : '');
    }
		this.fireEvent("update", this);
	},
	
	getValue: function() {
		var result = {};
		for(var key in this.fields) {
			var field = this.fields[key];
			if(field.isValid() && String(field.getValue()).length > 0) { 
				result[key] = field.getValue();
      }
		}
		
		return result;
	},
  
  onKeyUp: function(event, input, notSure, field) {
    if(event.getKey() == event.ENTER && field.isValid()) {
	    this.hide(true);
	    return;
	  }
	
	  if(field == this.fields.eq) {
	    this.fields.gt.setValue(null);
	    this.fields.lt.setValue(null);
	  } else {
	    this.fields.eq.setValue(null);
	  }
	  
	  this.updateTask.delay(this.updateBuffer);
  }
});


Ext.grid.GridFilters = function(config){		
	this.filters = new Ext.util.MixedCollection();
	this.filters.getKey = function(o) {return o ? o.dataIndex : null};
	
	for(var i=0, len=config.filters.length; i<len; i++) {
		this.addFilter(config.filters[i]);
  }
  
	this.deferredUpdate = new Ext.util.DelayedTask(this.reload, this);
	
	delete config.filters;
	Ext.apply(this, config);
};
Ext.extend(Ext.grid.GridFilters, Ext.util.Observable, {
	
	updateBuffer: 500,
	
	paramPrefix: 'filter',
	
	filterCls: 'ux-filtered-column',
	
	local: false,
	
	autoReload: true,
	
	stateId: undefined,
	
	showMenu: true,

	init: function(grid){
    if(grid instanceof Ext.grid.GridPanel){
      this.grid  = grid;
      
      this.store = this.grid.getStore();
      if(this.local){
        this.store.on('load', function(store) {
          store.filterBy(this.getRecordFilter());
        }, this);
      } else {
        this.store.on('beforeload', this.onBeforeLoad, this);
      }
      
      this.grid.filters = this;
      
      this.grid.addEvents('filterupdate');
      
      grid.on("render", this.onRender, this);
      grid.on("beforestaterestore", this.applyState, this);
      grid.on("beforestatesave", this.saveState, this);
      
    } else if(grid instanceof Ext.PagingToolbar) {
      this.toolbar = grid;
    }
	},
		
	
	applyState: function(grid, state){
		this.applyingState = true;
		this.clearFilters();
		if(state.filters)
			for(var key in state.filters){
				var filter = this.filters.get(key);
				if(filter){
					filter.setValue(state.filters[key]);
					filter.setActive(true);
				}
			}
			
		this.deferredUpdate.cancel();
		if(this.local)
			this.reload();
			
		delete this.applyingState;
	},
	
	
	saveState: function(grid, state){
		var filters = {};
		this.filters.each(function(filter) {
			if(filter.active) {
				filters[filter.dataIndex] = filter.getValue();
      }
		});
		return state.filters = filters;
	},
	
	
	onRender: function(){
		var hmenu;
		
		if(this.showMenu) {
			hmenu = this.grid.getView().hmenu;
			
			this.sep  = hmenu.addSeparator();
			this.menu = hmenu.add(new Ext.menu.CheckItem({
					text: this.menuFilterText,
					menu: new Ext.menu.Menu()
				}));
			this.menu.on('checkchange', this.onCheckChange, this);
			this.menu.on('beforecheckchange', this.onBeforeCheck, this);
				
			hmenu.on('beforeshow', this.onMenu, this);
		}
		
		this.grid.getView().on("refresh", this.onRefresh, this);
		this.updateColumnHeadings(this.grid.getView());
	},
	
	
	onMenu: function(filterMenu) {
		var filter = this.getMenuFilter();
		if(filter) {
			this.menu.menu = filter.menu;
			this.menu.setChecked(filter.active, false);
		}
		
		this.menu.setVisible(filter !== undefined);
		this.sep.setVisible(filter !== undefined);
	},
	
	
	onCheckChange: function(item, value) {
		this.getMenuFilter().setActive(value);
	},
	
	
	onBeforeCheck: function(check, value) {
		return !value || this.getMenuFilter().isActivatable();
	},
	
	
	onStateChange: function(event, filter){
    	if(event == "serialize") return;
    
		if(filter == this.getMenuFilter())
			this.menu.setChecked(filter.active, false);
			
		if((this.autoReload || this.local) && !this.applyingState)
			this.deferredUpdate.delay(this.updateBuffer);
		
		var view = this.grid.getView();
		this.updateColumnHeadings(view);
			
		if(!this.applyingState)
			this.grid.saveState();
			
		this.grid.fireEvent('filterupdate', this, filter);
	},
	
	
	onBeforeLoad: function(store, options) {
    options.params = options.params || {};
		this.cleanParams(options.params);		
		var params = this.buildQuery(this.getFilterData());
		Ext.apply(options.params, params);
	},
	
	
	onRefresh: function(view) {
		this.updateColumnHeadings(view);
	},
	
	
	getMenuFilter: function() {
		var view = this.grid.getView();
		if(!view || view.hdCtxIndex === undefined) {
			return null;
    }
		
		return this.filters.get(view.cm.config[view.hdCtxIndex].dataIndex);
	},
	
	
	updateColumnHeadings: function(view) {
		if(!view || !view.mainHd) {
      return;
    }
		
		var hds = view.mainHd.select('td').removeClass(this.filterCls);
		for(var i=0, len=view.cm.config.length; i<len; i++) {
			var filter = this.getFilter(view.cm.config[i].dataIndex);
			if(filter && filter.active) {
				hds.item(i).addClass(this.filterCls);
      }
		}
	},
	
	
	reload: function() {
		if(this.local){
			this.grid.store.clearFilter(true);
			this.grid.store.filterBy(this.getRecordFilter());
		} else {
			this.deferredUpdate.cancel();
			var store = this.grid.store;
			if(this.toolbar) {
				var start = this.toolbar.paramNames.start;
				if(store.lastOptions && store.lastOptions.params && store.lastOptions.params[start]) {
					store.lastOptions.params[start] = 0;
        }
			}
			store.reload();
		}
	},
	
	
	getRecordFilter: function() {
		var f = [];
		this.filters.each(function(filter) {
			if(filter.active) {
        f.push(filter);
      }
		});
		
		var len = f.length;
		return function(record) {
			for(var i=0; i<len; i++) {
				if(!f[i].validateRecord(record)) {
					return false;
        }
      }
			return true;
		};
	},
	
	
	addFilter: function(config) {
		var filter = config.menu ? config : new (this.getFilterClass(config.type))(config);
		this.filters.add(filter);
		
		Ext.util.Observable.capture(filter, this.onStateChange, this);
		return filter;
	},
	
	
	getFilter: function(dataIndex){
		return this.filters.get(dataIndex);
	},

	
	clearFilters: function() {
		this.filters.each(function(filter) {
			filter.setActive(false);
		});
	},

	
	getFilterData: function() {
		var filters = [];
		
		this.filters.each(function(f) {
			if(f.active) {
				var d = [].concat(f.serialize());
				for(var i=0, len=d.length; i<len; i++) {
					filters.push({field: f.dataIndex, data: d[i]});
        }
			}
		});
		
		return filters;
	},
	
	
	buildQuery: function(filters) {
		var p = {};
		for(var i=0, len=filters.length; i<len; i++) {
			var f = filters[i];
			var root = [this.paramPrefix, '[', i, ']'].join('');
			p[root + '[field]'] = f.field;
			
			var dataPrefix = root + '[data]';
			for(var key in f.data) {
				p[[dataPrefix, '[', key, ']'].join('')] = f.data[key];
      }
		}
		
		return p;
	},
	
	
	cleanParams: function(p) {
		var regex = new RegExp("^" + this.paramPrefix + "\[[0-9]+\]");
		for(var key in p) {
			if(regex.test(key)) {
				delete p[key];
      }
    }
	},
	
	
	getFilterClass: function(type){
		return Ext.grid.filter[type.substr(0, 1).toUpperCase() + type.substr(1) + 'Filter'];
	}
});

Ext.ns('Ext.ux.grid');


Ext.ux.grid.RowExpander = Ext.extend(Ext.util.Observable, {
    
    expandOnEnter : true,
    
    expandOnDblClick : true,

    header : '',
    width : 20,
    sortable : false,
    fixed : true,
    menuDisabled : true,
    dataIndex : '',
    id : 'expander',
    lazyRender : true,
    enableCaching : true,

    constructor: function(config){
        Ext.apply(this, config);

        this.addEvents({
            
            beforeexpand: true,
            
            expand: true,
            
            beforecollapse: true,
            
            collapse: true
        });

        Ext.ux.grid.RowExpander.superclass.constructor.call(this);

        if(this.tpl){
            if(typeof this.tpl == 'string'){
                this.tpl = new Ext.Template(this.tpl);
            }
            this.tpl.compile();
        }

        this.state = {};
        this.bodyContent = {};
    },

    getRowClass : function(record, rowIndex, p, ds){
        p.cols = p.cols-1;
        var content = this.bodyContent[record.id];
        if(!content && !this.lazyRender){
            content = this.getBodyContent(record, rowIndex);
        }
        if(content){
            p.body = content;
        }
        return this.state[record.id] ? 'x-grid3-row-expanded' : 'x-grid3-row-collapsed';
    },

    init : function(grid){
        this.grid = grid;

        var view = grid.getView();
        view.getRowClass = this.getRowClass.createDelegate(this);

        view.enableRowBody = true;


        grid.on('render', this.onRender, this);
        grid.on('destroy', this.onDestroy, this);
    },

    // @private
    onRender: function() {
        var grid = this.grid;
        var mainBody = grid.getView().mainBody;
        mainBody.on('mousedown', this.onMouseDown, this, {delegate: '.x-grid3-row-expander'});
        if (this.expandOnEnter) {
            this.keyNav = new Ext.KeyNav(this.grid.getGridEl(), {
                'enter' : this.onEnter,
                scope: this
            });
        }
        if (this.expandOnDblClick) {
            grid.on('rowdblclick', this.onRowDblClick, this);
        }
    },
    
    // @private    
    onDestroy: function() {
        if(this.keyNav){
            this.keyNav.disable();
            delete this.keyNav;
        }
        
        var sm = g.getSelectionModel();
        var sels = sm.getSelections();
        for (var i = 0, len = sels.length; i < len; i++) {
            var rowIdx = g.getStore().indexOf(sels[i]);
            this.toggleRow(rowIdx);
        }
    },

    getBodyContent : function(record, index){
        if(!this.enableCaching){
            return this.tpl.apply(record.data);
        }
        var content = this.bodyContent[record.id];
        if(!content){
            content = this.tpl.apply(record.data);
            this.bodyContent[record.id] = content;
        }
        return content;
    },

    onMouseDown : function(e, t){
        e.stopEvent();
        var row = e.getTarget('.x-grid3-row');
        this.toggleRow(row);
    },

    renderer : function(v, p, record){
        p.cellAttr = 'rowspan="2"';
        return '<div class="x-grid3-row-expander">&#160;</div>';
    },

    beforeExpand : function(record, body, rowIndex){
        if(this.fireEvent('beforeexpand', this, record, body, rowIndex) !== false){
            if(this.tpl && this.lazyRender){
                body.innerHTML = this.getBodyContent(record, rowIndex);
            }
            return true;
        }else{
            return false;
        }
    },

    toggleRow : function(row){
        if(typeof row == 'number'){
            row = this.grid.view.getRow(row);
        }
        this[Ext.fly(row).hasClass('x-grid3-row-collapsed') ? 'expandRow' : 'collapseRow'](row);
    },

    expandRow : function(row){
        if(typeof row == 'number'){
            row = this.grid.view.getRow(row);
        }
        var record = this.grid.store.getAt(row.rowIndex);
        var body = Ext.DomQuery.selectNode('tr:nth(2) div.x-grid3-row-body', row);
        if(this.beforeExpand(record, body, row.rowIndex)){
            this.state[record.id] = true;
            Ext.fly(row).replaceClass('x-grid3-row-collapsed', 'x-grid3-row-expanded');
            this.fireEvent('expand', this, record, body, row.rowIndex);
        }
    },

    collapseRow : function(row){
        if(typeof row == 'number'){
            row = this.grid.view.getRow(row);
        }
        var record = this.grid.store.getAt(row.rowIndex);
        var body = Ext.fly(row).child('tr:nth(1) div.x-grid3-row-body', true);
        if(this.fireEvent('beforecollapse', this, record, body, row.rowIndex) !== false){
            this.state[record.id] = false;
            Ext.fly(row).replaceClass('x-grid3-row-expanded', 'x-grid3-row-collapsed');
            this.fireEvent('collapse', this, record, body, row.rowIndex);
        }
    }
});

//Ext.preg('rowexpander', Ext.ux.grid.RowExpander);

//backwards compat
Ext.grid.RowExpander = Ext.ux.grid.RowExpander;
Ext.namespace('Ext.ux.maximgb.treegrid');


Ext.ux.maximgb.treegrid.AbstractTreeStore = Ext.extend(Ext.data.Store,
{
	
	leaf_field_name : '_is_leaf',
	
	
	page_offset : 0,
	
	
	active_node : null,
	
	
	constructor : function(config)
	{
		Ext.ux.maximgb.treegrid.AbstractTreeStore.superclass.constructor.call(this, config);
		
		if (!this.paramNames.active_node) {
			this.paramNames.active_node = 'anode';
		}
		
		this.addEvents(
			
			'beforeexpandnode',
			
			'expandnode',
			
			'expandnodefailed',
			
			'beforecollapsenode',
			
			'collapsenode',
			
			'beforeactivenodechange',
			
			'activenodechange'
		);
	},	

	// Store methods.
	// -----------------------------------------------------------------------------------------------	
	
	remove : function(record)
	{
		// ----- Modification start
		if (record === this.active_node) {
			this.setActiveNode(null);
		}
		this.removeNodeDescendants(record);
		// ----- End of modification		
		Ext.ux.maximgb.treegrid.AbstractTreeStore.superclass.remove.call(this, record);
	},
	
	
	removeNodeDescendants : function(rc)
	{
		var i, len, children = this.getNodeChildren(rc);
		for (i = 0, len = children.length; i < len; i++) {
			this.remove(children[i]);
		}
	},
	
	
	applySort : function()
	{
		if(this.sortInfo && !this.remoteSort){
			var s = this.sortInfo, f = s.field;
			this.sortData(f, s.direction);
		}
		// ----- Modification start
		else {
			this.applyTreeSort();
		}
		// ----- End of modification
	},
	
	
	sortData : function(f, direction) 
	{
		direction = direction || 'ASC';
		var st = this.fields.get(f).sortType;
		var fn = function(r1, r2){
			var v1 = st(r1.data[f]), v2 = st(r2.data[f]);
			return v1 > v2 ? 1 : (v1 < v2 ? -1 : 0);
		};
		this.data.sort(direction, fn);
		if(this.snapshot && this.snapshot != this.data){
			this.snapshot.sort(direction, fn);
		}
		// ----- Modification start
		this.applyTreeSort();
		// ----- End of modification
	},
	
	
	load : function(options)
	{
		if (options) {
			if (options.params) {
				if (options.params[this.paramNames.active_node] === undefined) {
					options.params[this.paramNames.active_node] = this.active_node ? this.active_node.id : null;
				}
			}
			else {
				options.params = {};
				options.params[this.paramNames.active_node] = this.active_node ? this.active_node.id : null;
			}
		}
		else {
			options = {params: {}};
			options.params[this.paramNames.active_node] = this.active_node ? this.active_node.id : null;
		}
		if (options.params[this.paramNames.active_node] !== null) {
			options.add = true;
		}
		return Ext.ux.maximgb.treegrid.AbstractTreeStore.superclass.load.call(this, options); 
	},
	
	
	loadRecords : function(o, options, success)
	{
    if (!o || success === false) {
      if (success !== false) {
        this.fireEvent("load", this, [], options);
      }
      if (options.callback) {
        options.callback.call(options.scope || this, [], options, false);
      }
      return;
    }
    
    var r = o.records, t = o.totalRecords || r.length,  
    		page_offset = this.getPageOffsetFromOptions(options),
    		loaded_node_id = this.getLoadedNodeIdFromOptions(options), 
    		loaded_node, i, len, self = this;
    
    if (!options || options.add !== true || loaded_node_id === null) {
      if (this.pruneModifiedRecords) {
        this.modified = [];
      }
      for (var i = 0, len = r.length; i < len; i++) {
        r[i].join(this);
      }
      if (this.snapshot) {
        this.data = this.snapshot;
        delete this.snapshot;
      }
      this.data.clear();
      this.data.addAll(r);
      this.page_offset = page_offset;
      this.totalLength = t;
      this.applySort();
      this.fireEvent("datachanged", this);
    } else {
    	loaded_node = this.getById(loaded_node_id);
    	if (loaded_node) {
    		this.setNodeChildrenOffset(loaded_node, page_offset);
    		this.setNodeChildrenTotalCount(loaded_node, Math.max(t, r.length));
    		
				this.removeNodeDescendants(loaded_node);
				this.suspendEvents();
				for (i = 0, len = r.length; i < len; i++) {
      		this.add(r[i]);
      	}
      	this.applySort();
      	this.resumeEvents();
      	idx = [];
      	
      	r.sort(function(r1, r2) {
      		var idx1 = self.data.indexOf(r1),
      				idx2 = self.data.indexOf(r2),
      				r;
      		 
      		if (idx1 > idx2) {
      			r = 1;
      		}
      		else {
      			r = -1;
      		}
      		return r;
      	});
      	
      	for (i = 0, len = r.length; i < len; i++) {
      		this.fireEvent("add", this, [r[i]], this.data.indexOf(r[i]));
      	}
      	
      	
      }
    }
    this.fireEvent("load", this, r, options);
    if (options.callback) {
      options.callback.call(options.scope || this, r, options, true);
    }
  },
	
	// Tree support methods.
	// -----------------------------------------------------------------------------------------------

	
	applyTreeSort : function()
	{
		var i, len, temp,
				rec, records = [],
				roots = this.getRootNodes();
				
		// Sorting data
		for (i = 0, len = roots.length; i < len; i++) {
			rec = roots[i];
			records.push(rec);
			this.collectNodeChildrenTreeSorted(records, rec); 
		}
		
		if (records.length > 0) {
			this.data.clear();
			this.data.addAll(records);
		}
		
		// Sorting the snapshot if one present.
		if (this.snapshot && this.snapshot !== this.data) {
			temp = this.data;
			this.data = this.snapshot;
			this.snapshot = null; 
			this.applyTreeSort();
			this.snapshot = this.data;
			this.data = temp;
		}
	},
	
	
	collectNodeChildrenTreeSorted : function(records, rec)
	{
		var i, len,
				child, 
				children = this.getNodeChildren(rec);
				
		for (i = 0, len = children.length; i < len; i++) {
			child = children[i];
			records.push(child);
			this.collectNodeChildrenTreeSorted(records, child); 
		}
	},
	
	
	getActiveNode : function()
	{
		return this.active_node;
	},
	
	
	setActiveNode : function(rc)
	{
		if (this.active_node !== rc) {
			if (rc) {
				if (this.data.indexOf(rc) != -1) {
					if (this.fireEvent('beforeactivenodechange', this, this.active_node, rc) !== false) {
						this.active_node = rc;
						this.fireEvent('activenodechange', this, this.active_node, rc);
					}
				}
				else {
					throw "Given record is not from the store.";
				}
			}
			else {
				if (this.fireEvent('beforeactivenodechange', this, this.active_node, rc) !== false) {
					this.active_node = rc;
					this.fireEvent('activenodechange', this, this.active_node, rc);
				}
			}
		}
	},
	 
	
	isExpandedNode : function(rc)
	{
		return rc.ux_maximgb_treegrid_expanded === true;
	},
	
	
	setNodeExpanded : function(rc, value)
	{
		rc.ux_maximgb_treegrid_expanded = value;
	},
	
	
	isVisibleNode : function(rc)
	{
		var i, len,
				ancestors = this.getNodeAncestors(rc),
				result = true;
		
		for (i = 0, len = ancestors.length; i < len; i++) {
			result = result && this.isExpandedNode(ancestors[i]);
			if (!result) {
				break;
			}
		}
		
		return result;
	},
	
	
	isLeafNode : function(rc)
	{
		return rc.get(this.leaf_field_name) == true;
	},
	
	
	isLoadedNode : function(rc)
	{
		var result;
		
		if (rc.ux_maximgb_treegrid_loaded !== undefined) {
			result = rc.ux_maximgb_treegrid_loaded
		}
		else if (this.isLeafNode(rc) || this.hasChildNodes(rc)) {
			result = true;
		}
		else {
			result = false;
		}
		
		return result;
	},
	
	
	setNodeLoaded : function(rc, value)
	{
		rc.ux_maximgb_treegrid_loaded = value;
	},
	
	
	getNodeChildrenOffset : function(rc)
	{
		return rc.ux_maximgb_treegrid_offset || 0;
	},
	
	
	setNodeChildrenOffset : function(rc, value)
	{
		rc.ux_maximgb_treegrid_offset = value;
	},
	
	
	getNodeChildrenTotalCount : function(rc)
	{
		return rc.ux_maximgb_treegrid_total || 0;
	},
	
	
	setNodeChildrenTotalCount : function(rc, value)
	{
		rc.ux_maximgb_treegrid_total = value;
	},
	
	
	collapseNode : function(rc)
	{
		if (
			this.isExpandedNode(rc) &&
			this.fireEvent('beforecollapsenode', this, rc) !== false 
		) {
			this.setNodeExpanded(rc, false);
			this.fireEvent('collapsenode', this, rc);
		}
	},
	
	
	expandNode : function(rc)
	{
		var params;
		
		if (
			!this.isExpandedNode(rc) &&
			this.fireEvent('beforeexpandnode', this, rc) !== false
		) {
			// If node is already loaded then expanding now.
			if (this.isLoadedNode(rc)) {
				this.setNodeExpanded(rc, true);
				this.fireEvent('expandnode', this, rc);
			}
			// If node isn't loaded yet then expanding after load.
			else {
				params = {};
				params[this.paramNames.active_node] = rc.id;
				this.load({
					add : true,
					params : params,
					callback : this.expandNodeCallback,
					scope : this
				});
			}
		}
	},
	
	
	expandNodeCallback : function(r, options, success)
	{
		var rc = this.getById(options.params[this.paramNames.active_node]);
		
		if (success && rc) {
			this.setNodeLoaded(rc, true);
			this.setNodeExpanded(rc, true);
			this.fireEvent('expandnode', this, rc);
		}
		else {
			this.fireEvent('expandnodefailed', this, options.params[this.paramNames.active_node], rc);
		}
	},
	
	
	getLoadedNodeIdFromOptions : function(options)
	{
		var result = null;
		if (options && options.params && options.params[this.paramNames.active_node]) {
			result = options.params[this.paramNames.active_node];
		}
		return result;
	},
	
	
	getPageOffsetFromOptions : function(options)
	{
		var result = 0;
		if (options && options.params && options.params[this.paramNames.start]) {
			result = parseInt(options.params[this.paramNames.start], 10);
			if (isNaN(result)) {
				result = 0;
			}
		}
		return result;
	},
	
	// Public
	hasNextSiblingNode : function(rc)
	{
		return this.getNodeNextSibling(rc) !== null;
	},
	
	// Public
	hasPrevSiblingNode : function(rc)
	{
		return this.getNodePrevSibling(rc) !== null;
	},
	
	// Public
	hasChildNodes : function(rc)
	{
		return this.getNodeChildrenCount(rc) > 0;
	},
	
	// Public
	getNodeAncestors : function(rc)
	{
		var ancestors = [],
				parent;
		
		parent = this.getNodeParent(rc);
		while (parent) {
			ancestors.push(parent);
			parent = this.getNodeParent(parent);	
		}
		
		return ancestors;
	},
	
	// Public
	getNodeChildrenCount : function(rc)
	{
		return this.getNodeChildren(rc).length;
	},
	
	// Public
	getNodeNextSibling : function(rc)
	{
		var siblings,
				parent,
				index,
				result = null;
				
		parent = this.getNodeParent(rc);
		if (parent) {
			siblings = this.getNodeChildren(parent);
		}
		else {
			siblings = this.getRootNodes();
		}
		
		index = siblings.indexOf(rc);
		
		if (index < siblings.length - 1) {
			result = siblings[index + 1];
		}
		
		return result;
	},
	
	// Public
	getNodePrevSibling : function(rc)
	{
		var siblings,
				parent,
				index,
				result = null;
				
		parent = this.getNodeParent(rc);
		if (parent) {
			siblings = this.getNodeChildren(parent);
		}
		else {
			siblings = this.getRootNodes();
		}
		
		index = siblings.indexOf(rc);
		if (index > 0) {
			result = siblings[index - 1];
		}
		
		return result;
	},
	
	// Abstract tree support methods.
	// -----------------------------------------------------------------------------------------------
	
	// Public - Abstract
	getRootNodes : function()
	{
		throw 'Abstract method call';
	},
	
	// Public - Abstract
	getNodeDepth : function(rc)
	{
		throw 'Abstract method call';
	},
	
	// Public - Abstract
	getNodeParent : function(rc)
	{
		throw 'Abstract method call';
	},
	
	// Public - Abstract
	getNodeChildren : function(rc)
	{
		throw 'Abstract method call';
	},
	
	// Public - Abstract
	addToNode : function(parent, child)
	{
		throw 'Abstract method call';
	},
	
	// Public - Abstract
	removeFromNode : function(parent, child)
	{
		throw 'Abstract method call';
	},
	
	// Paging support methods.
	// -----------------------------------------------------------------------------------------------
	
	getPageOffset : function()
	{
		return this.page_offset;
	},
	
	
	getActiveNodePageOffset : function()
	{
		var result;
		
		if (this.active_node) {
			result = this.getNodeChildrenOffset(this.active_node);
		}
		else {
			result = this.getPageOffset();
		}
		
		return result;
	},
	
	
	getActiveNodeCount : function()
	{
		var result;
		
		if (this.active_node) {
			result = this.getNodeChildrenCount(this.active_node);
		}
		else {
			result = this.getRootNodes().length;
		}
		
		return result;
	},
	
	
	getActiveNodeTotalCount : function()
	{
		var result;
		
		if (this.active_node) {
			result = this.getNodeChildrenTotalCount(this.active_node);
		}
		else {
			result = this.getTotalCount();
		}
		
		return result;	
	}
	
});


Ext.ux.maximgb.treegrid.AdjacencyListStore = Ext.extend(Ext.ux.maximgb.treegrid.AbstractTreeStore,
{
	
	parent_id_field_name : '_parent',
	
	getRootNodes : function()
	{
		var i, 
				len, 
				result = [], 
				records = this.data.getRange();
		
		for (i = 0, len = records.length; i < len; i++) {
			if (!records[i].get(this.parent_id_field_name)) {
			//if (records[i].get(this.parent_id_field_name) == null) {
				result.push(records[i]);
			}
		}
		
		return result;
	},
	
	getNodeDepth : function(rc)
	{
		return this.getNodeAncestors(rc).length;
	},
	
	getNodeParent : function(rc)
	{
		return this.getById(rc.get(this.parent_id_field_name));
	},
	
	getNodeChildren : function(rc)
	{
		var i, 
				len, 
				result = [], 
				records = this.data.getRange();
		
		for (i = 0, len = records.length; i < len; i++) {
			if (records[i].get(this.parent_id_field_name) == rc.id) {
				result.push(records[i]);
			}
		}
		
		return result;
	}
});


Ext.ux.maximgb.treegrid.NestedSetStore = Ext.extend(Ext.ux.maximgb.treegrid.AbstractTreeStore,
{
	
	left_field_name : '_lft',
	
	
	right_field_name : '_rgt',
	
	
	level_field_name : '_level',
	
	
	root_node_level : 1,
	
	getRootNodes : function()
	{
		var i, 
				len, 
				result = [], 
				records = this.data.getRange();
		
		for (i = 0, len = records.length; i < len; i++) {
			if (records[i].get(this.level_field_name) == this.root_node_level) {
				result.push(records[i]);
			}
		}
		
		return result;
	},
	
	getNodeDepth : function(rc)
	{
		return rc.get(this.level_field_name) - this.root_node_level;
	},
	
	getNodeParent : function(rc)
	{
		var result = null,
				rec, records = this.data.getRange(),
				i, len,
				lft, r_lft,
				rgt, r_rgt,
				level, r_level;
				
		lft = rc.get(this.left_field_name);
		rgt = rc.get(this.right_field_name);
		level = rc.get(this.level_field_name);
		
		for (i = 0, len = records.length; i < len; i++) {
			rec = records[i];
			r_lft = rec.get(this.left_field_name);
			r_rgt = rec.get(this.right_field_name);
			r_level = rec.get(this.level_field_name);
			
			if (
				r_level == level - 1 &&
				r_lft < lft &&
				r_rgt > rgt
			) {
				result = rec;
				break;
			}
		}
		
		return result;
	},
	
	getNodeChildren : function(rc)
	{
		var lft, r_lft,
				rgt, r_rgt,
				level, r_level,
				records, rec,
				result = [];
				
		records = this.data.getRange();
		
		lft = rc.get(this.left_field_name);
		rgt = rc.get(this.right_field_name);
		level = rc.get(this.level_field_name);
		
		for (i = 0, len = records.length; i < len; i++) {
			rec = records[i];
			r_lft = rec.get(this.left_field_name);
			r_rgt = rec.get(this.right_field_name);
			r_level = rec.get(this.level_field_name);
			
			if (
				r_level == level + 1 &&
				r_lft > lft &&
				r_rgt < rgt
			) {
				result.push(rec);
			}
		}
		
		return result;
	}
});

Ext.ux.maximgb.treegrid.GridView = Ext.extend(Ext.grid.GridView, 
{
	// private
	breadcrumbs_el : null,
	
	// private - overriden
	initTemplates : function()
	{
		var ts = this.templates || {};
		
    ts.master = new Ext.Template(
			'<div class="x-grid3" hidefocus="true">',
				'<div class="x-grid3-viewport">',
					'<div class="x-grid3-header">',
						// Breadcrumbs
						'<div class="x-grid3-header-inner">',
							'<div class="x-grid3-header-offset">',
								'<div class="ux-maximgb-treegrid-breadcrumbs">&#160;</div>',
							'</div>',
						'</div>',
						'<div class="x-clear"></div>',
						// End of breadcrumbs
						// Header
						'<div class="x-grid3-header-inner">',
							'<div class="x-grid3-header-offset">{header}</div>',
						'</div>',
						'<div class="x-clear"></div>',
						// End of header
					'</div>',
					// Scroller
					'<div class="x-grid3-scroller">',
						'<div class="x-grid3-body">{body}</div>',
						'<a href="#" class="x-grid3-focus" tabIndex="-1"></a>',
					'</div>',
					// End of scroller
				'</div>',
				'<div class="x-grid3-resize-marker">&#160;</div>',
				'<div class="x-grid3-resize-proxy">&#160;</div>',
			'</div>'
		);
		
    ts.row = new Ext.Template(
			'<div class="x-grid3-row {alt} ux-maximgb-treegrid-level-{level}" style="{tstyle} {display_style}">',
				'<table class="x-grid3-row-table" border="0" cellspacing="0" cellpadding="0" style="{tstyle}">',
        	'<tbody>',
        		'<tr>{cells}</tr>',
            (
            	this.enableRowBody ? 
            		'<tr class="x-grid3-row-body-tr" style="{bodyStyle}">' +
            			'<td colspan="{cols}" class="x-grid3-body-cell" tabIndex="0" hidefocus="on">'+
            				'<div class="x-grid3-row-body">{body}</div>'+
            			'</td>'+
            		'</tr>' 
            			: 
            		''
            ),
          '</tbody>',
         '</table>',
        '</div>'
		);
		
    ts.cell = new Ext.Template(
			'<td class="x-grid3-col x-grid3-cell x-grid3-td-{id} {css}" style="{style}" tabIndex="0" {cellAttr}>',
				'{treeui}',
				'<div class="x-grid3-cell-inner x-grid3-col-{id}" unselectable="on" {attr}>{value}</div>',
			'</td>'
		);
		
		ts.treeui = new Ext.Template(
			'<div class="ux-maximgb-treegrid-uiwrap" style="width: {wrap_width}px">',
				'{elbow_line}',
				'<div style="left: {left}px" class="{cls}">&#160;</div>',
			'</div>'
		);
		
		ts.elbow_line = new Ext.Template(
			'<div style="left: {left}px" class="{cls}">&#160;</div>'
		);
		
		ts.brd_item = new Ext.Template(
			'<a href="#" id="ux-maximgb-treegrid-brditem-{id}" class="ux-maximgb-treegrid-brditem" title="{title}">{caption}</a>'
		);
		
		this.templates = ts;
		Ext.ux.maximgb.treegrid.GridView.superclass.initTemplates.call(this);
	},
	
	// private - overriden
  initElements : function()
  {
		var E = Ext.Element;
		
		var el = this.grid.getGridEl().dom.firstChild;
		var cs = el.childNodes;
		
		this.el = new E(el);
		
		this.mainWrap = new E(cs[0]);
		this.mainHd = new E(this.mainWrap.dom.firstChild);
		
		if(this.grid.hideHeaders){
		    this.mainHd.setDisplayed(false);
		}
		
		// ----- Modification start
		//Original: this.innerHd = this.mainHd.dom.firstChild;
		this.innerHd = this.mainHd.dom.childNodes[2];
		// ----- End of modification
		this.scroller = new E(this.mainWrap.dom.childNodes[1]);
		
		if(this.forceFit){
		    this.scroller.setStyle('overflow-x', 'hidden');
		}
		this.mainBody = new E(this.scroller.dom.firstChild);
		
		this.focusEl = new E(this.scroller.dom.childNodes[1]);
		this.focusEl.swallowEvent("click", true);
		
		this.resizeMarker = new E(cs[1]);
		this.resizeProxy = new E(cs[2]);
		
		this.breadcrumbs_el = this.el.child('.ux-maximgb-treegrid-breadcrumbs');
		this.setRootBreadcrumbs();
	},
	
	// Private - Overriden
	doRender : function(cs, rs, ds, startRow, colCount, stripe)
	{
		var ts = this.templates, ct = ts.cell, rt = ts.row, last = colCount-1;
		var tstyle = 'width:'+this.getTotalWidth()+';';
		// buffers
		var buf = [], cb, c, p = {}, rp = {tstyle: tstyle}, r;
		for (var j = 0, len = rs.length; j < len; j++) {
			r = rs[j]; cb = [];
			var rowIndex = (j+startRow);
			for (var i = 0; i < colCount; i++) {
        c = cs[i];
        p.id = c.id;
        p.css = i == 0 ? 'x-grid3-cell-first ' : (i == last ? 'x-grid3-cell-last ' : '');
        p.attr = p.cellAttr = "";
        p.value = c.renderer(r.data[c.name], p, r, rowIndex, i, ds);
        p.style = c.style;
				if (p.value == undefined || p.value === "") {
					p.value = "&#160;";
				}
				if (r.dirty && typeof r.modified[c.name] !== 'undefined') {
					p.css += ' x-grid3-dirty-cell';
				}
				// ----- Modification start
				if (c.id == this.grid.master_column_id) {
					p.treeui = this.renderCellTreeUI(r, ds);
				}
				else {
					p.treeui = '';
				}
				// ----- End of modification
				cb[cb.length] = ct.apply(p);
			}
			var alt = [];
      if (stripe && ((rowIndex+1) % 2 == 0)) {
				alt[0] = "x-grid3-row-alt";
      }
      if (r.dirty) {
				alt[1] = " x-grid3-dirty-row";
      }
      rp.cols = colCount;
      if(this.getRowClass){
          alt[2] = this.getRowClass(r, rowIndex, rp, ds);
      }
      rp.alt = alt.join(" ");
      rp.cells = cb.join("");
      // ----- Modification start
      if (!ds.isVisibleNode(r)) {
      	rp.display_style = 'display: none;';
      }
      else {
      	rp.display_style = '';
      }
      rp.level = ds.getNodeDepth(r);
      // ----- End of modification
      buf[buf.length] =  rt.apply(rp);
    }
    return buf.join("");
  },
  
  renderCellTreeUI : function(record, store)
  {
  	var tpl = this.templates.treeui,
  			line_tpl = this.templates.elbow_line,
  			tpl_data = {},
  			rec, parent,
  			depth = level = store.getNodeDepth(record);
  		
  	tpl_data.wrap_width = (depth + 1) * 16;	
  	if (level > 0) {
  		tpl_data.elbow_line = '';
  		rec = record;
  		left = 0;
  		while(level--) {
  			parent = store.getNodeParent(rec);
  			if (parent) {
	  			if (store.hasNextSiblingNode(parent)) {
	  				tpl_data.elbow_line = 
	  					line_tpl.apply({
	  						left : level * 16, 
	  						cls : 'ux-maximgb-treegrid-elbow-line'}) + 
	  					tpl_data.elbow_line;
	  			}
	  			else {
	  				tpl_data.elbow_line = 
	  					line_tpl.apply({
	  						left : level * 16,
	  						cls : 'ux-maximgb-treegrid-elbow-empty'
	  					}) +
	  					tpl_data.elbow_line;
	  			}
	  		}
	  		else {
	  			throw [
	  				"Tree inconsistency can't get level ",
	  				level + 1,
	  				" node(id=", rec.id, ") parent."
	  			].join("")
	  		}
	  		rec = parent;
  		}
  	}
		if (store.isLeafNode(record)) {
			if (store.hasNextSiblingNode(record)) {
				tpl_data.cls = 'ux-maximgb-treegrid-elbow';
			}
			else {
				tpl_data.cls = 'ux-maximgb-treegrid-elbow-end';
			}
		}
		else {
			tpl_data.cls = 'ux-maximgb-treegrid-elbow-active ';
			if (store.isExpandedNode(record)) {
				if (store.hasNextSiblingNode(record)) {
					tpl_data.cls += 'ux-maximgb-treegrid-elbow-minus';
				}
				else {
					tpl_data.cls += 'ux-maximgb-treegrid-elbow-end-minus';
				}
			}
			else {
				if (store.hasNextSiblingNode(record)) {
					tpl_data.cls += 'ux-maximgb-treegrid-elbow-plus';
				}
				else {
					tpl_data.cls += 'ux-maximgb-treegrid-elbow-end-plus';
				}
			}
		}
		tpl_data.left = 1 + depth * 16;
  			
  	return tpl.apply(tpl_data);
  },
	
	// Private
	getBreadcrumbsEl : function()
	{
		return this.breadcrumbs_el;
	},
	
	// Private
	expandRow : function(record, initial)
	{
		var ds = this.ds,
				i, len, row, pmel, children, index, child_index;
		
		if (typeof record == 'number') {
			index = record;
			record = ds.getAt(index);
		}
		else {
			index = ds.indexOf(record);
		}
		
		row = this.getRow(index);
		pmel = Ext.fly(row).child('.ux-maximgb-treegrid-elbow-active');
		if (pmel) {
			if (ds.hasNextSiblingNode(record)) {
				pmel.removeClass('ux-maximgb-treegrid-elbow-plus');
				pmel.removeClass('ux-maximgb-treegrid-elbow-end-plus');
				pmel.addClass('ux-maximgb-treegrid-elbow-minus');
			}
			else {
				pmel.removeClass('ux-maximgb-treegrid-elbow-plus');
				pmel.removeClass('ux-maximgb-treegrid-elbow-end-plus');
				pmel.addClass('ux-maximgb-treegrid-elbow-end-minus');
			}
			if (ds.isVisibleNode(record)) {
				children = ds.getNodeChildren(record);
				for (i = 0, len = children.length; i < len; i++) {
					child_index = ds.indexOf(children[i]);
					row = this.getRow(child_index);
					Ext.fly(row).setStyle('display', 'block');
					if (ds.isExpandedNode(children[i])) {
						this.expandRow(child_index);
					}
				}
			}
		}
	},
	
	collapseRow : function(record)
	{
		var ds = this.ds,
				i, len, children, row, index;
				
		if (typeof record == 'number') {
			index = record;
			record = ds.getAt(index);
		}
		else {
			index = ds.indexOf(record);
		}
		
		row = this.getRow(index);
		pmel = Ext.fly(row).child('.ux-maximgb-treegrid-elbow-active');
		if (pmel) {
			if (ds.hasNextSiblingNode(record)) {
				pmel.removeClass('ux-maximgb-treegrid-elbow-minus');
				pmel.removeClass('ux-maximgb-treegrid-elbow-end-minus');
				pmel.addClass('ux-maximgb-treegrid-elbow-plus');
			}
			else {
				pmel.removeClass('ux-maximgb-treegrid-elbow-minus');
				pmel.removeClass('ux-maximgb-treegrid-elbow-end-minus');
				pmel.addClass('ux-maximgb-treegrid-elbow-end-plus');
			}
			children = ds.getNodeChildren(record);
			for (i = 0, len = children.length; i < len; i++) {
				index = ds.indexOf(children[i]);
				row = this.getRow(index);
				Ext.fly(row).setStyle('display', 'none'); 
				this.collapseRow(index);
			}
		}
	},
	
	
	initData : function(ds, cm)
	{
		Ext.ux.maximgb.treegrid.GridView.superclass.initData.call(this, ds, cm);
		if (this.ds) {
			this.ds.un('activenodechange', this.onStoreActiveNodeChange, this);
			this.ds.un('expandnode', this.onStoreExpandNode, this);
			this.ds.un('collapsenode', this.onStoreCollapseNode, this);
		}
		if (ds) {
			ds.on('activenodechange', this.onStoreActiveNodeChange, this);
			ds.on('expandnode', this.onStoreExpandNode, this);
			ds.on('collapsenode', this.onStoreCollapseNode, this);
		}
	},
	
	onStoreActiveNodeChange : function(store, old_rc, new_rc)
	{
		var parents, i, len, rec, items = [],
				ts = this.templates;
				
		if (new_rc) {
			parents = this.ds.getNodeAncestors(new_rc),
			parents.reverse();
			parents.push(new_rc);
		
			for (i = 0, len = parents.length; i < len; i++) {
				rec = parents[i];
				items.push(
					ts.brd_item.apply({
						id : rec.id,
						title : this.grid.i18n.breadcrumbs_tip,
						caption : rec.get(
							this.cm.getDataIndex(
								this.cm.getIndexById(this.grid.master_column_id)
							)
						)
					})
				);
			}
			
			this.breadcrumbs_el.update(
				this.grid.i18n.path_separator +
				ts.brd_item.apply({
					id: '',
					title : this.grid.i18n.breadcrumbs_root_tip,
					caption : this.grid.root_title
				}) +
				this.grid.i18n.path_separator +
				items.join(this.grid.i18n.path_separator)
			);
		}
		else {
			this.setRootBreadcrumbs();
		}
	},
	
	setRootBreadcrumbs : function()
	{
		var ts = this.templates;
		this.breadcrumbs_el.update(
			this.grid.i18n.path_separator +
			ts.brd_item.apply({
					id: '',
					title : this.grid.i18n.breadcrumbs_root_tip,
					caption : this.grid.root_title
			})
		);
	},
	
	onLoad : function(store, records, options)
	{
		var id = store.getLoadedNodeIdFromOptions(options);
		if (id === null) {
			Ext.ux.maximgb.treegrid.GridView.superclass.onLoad.call(this, store, records, options);
		}
	},
	
	onStoreExpandNode : function(store, rc)
	{
		this.expandRow(rc);
	},
	
	onStoreCollapseNode : function(store, rc)
	{
		this.collapseRow(rc);
	}
});

Ext.ux.maximgb.treegrid.GridPanel = Ext.extend(Ext.grid.GridPanel, 
{
	
	master_column_id : 0,
	
	
	root_title : null,
	
	
	i18n : null,

	// Private
	initComponent : function()
	{
		Ext.ux.maximgb.treegrid.GridPanel.superclass.initComponent.call(this);
		
		Ext.applyIf(this.i18n, Ext.ux.maximgb.treegrid.GridPanel.prototype.i18n);
		
		if (!this.root_title) {
			this.root_title = this.title || this.i18n.root_title;
		}
		
		this.getSelectionModel().on(
			'selectionchange',
			this.onTreeGridSelectionChange,
			this
		);
	},

	
	getView : function()
	{
		if (!this.view) {
			this.view = new Ext.ux.maximgb.treegrid.GridView(this.viewConfig);
		}
		return this.view;
	},
	
	
	onClick : function(e)
	{
		var target = e.getTarget(),
				view = this.getView(),
				row = view.findRowIndex(target),
				store = this.getStore(),
				sm = this.getSelectionModel(), 
				record, record_id, do_default = true;
		
		// Row click
		if (row !== false) {
			if (Ext.fly(target).hasClass('ux-maximgb-treegrid-elbow-active')) {
				record = store.getAt(row);
				if (store.isExpandedNode(record)) {
					store.collapseNode(record);
				}
				else {
					store.expandNode(record);
				}
				do_default = false;
			}
		}
		// Breadcrumb click
		else if (Ext.fly(target).hasClass('ux-maximgb-treegrid-brditem')) {
			record_id = Ext.id(target);
			record_id = record_id.substr(record_id.lastIndexOf('-') + 1);
			if (record_id != '') {
				record = store.getById(record_id);
				row = store.indexOf(record);
				
				if (e.hasModifier()) {
					if (store.isExpandedNode(record)) {
						store.collapseNode(record);
					}
					else {
						store.expandNode(record);
					}
				}
				else if (sm.isSelected && !sm.isSelected(row)) {
					sm.selectRow(row);
				}
			}
			else {
				sm.clearSelections();
			}
			e.preventDefault();
		}

		if (do_default) {
			Ext.ux.maximgb.treegrid.GridPanel.superclass.onClick.call(this, e);
		}
	},

	
	onMouseDown : function(e)
	{
		var target = e.getTarget();

		if (!Ext.fly(target).hasClass('ux-maximgb-treegrid-elbow-active')) {
			Ext.ux.maximgb.treegrid.GridPanel.superclass.onMouseDown.call(this, e);
		}
	},
	
	
	onDblClick : function(e)
	{
		var target = e.getTarget(),
				view = this.getView(),
				row = view.findRowIndex(target),
				store = this.getStore(),
				sm = this.getSelectionModel(), 
				record, record_id;
			
		// Breadcrumbs select + expand/collapse	
		if (!row && Ext.fly(target).hasClass('ux-maximgb-treegrid-brditem')) {
			record_id = Ext.id(target);
			record_id = record_id.substr(record_id.lastIndexOf('-') + 1);
			if (record_id != '') {
				record = store.getById(record_id);
				row = store.indexOf(record);
				
				if (store.isExpandedNode(record)) {
					store.collapseNode(record);
				}
				else {
					store.expandNode(record);
				}
				
				if (sm.isSelected && !sm.isSelected(row)) {
					sm.selectRow(row);
				}
			}
			else {
				sm.clearSelections();
			}
		}
		
		Ext.ux.maximgb.treegrid.GridPanel.superclass.onDblClick.call(this, e);
	},
	
	
	onTreeGridSelectionChange : function(sm, selection)
	{
		var record;
		// Row selection model
		if (sm.getSelected) {
			record = sm.getSelected();
			this.getStore().setActiveNode(record);
		}
		// Cell selection model
		else if (Ext.type(selection) == 'array' && selection.length > 0) {
			record = store.getAt(selection[0])
			this.getStore().setActiveNode(record);
		}
		else {
			throw "Unknown selection model applyed to the grid.";
		}
	}
});

Ext.ux.maximgb.treegrid.GridPanel.prototype.i18n = {
	path_separator : ' / ',
	root_title : '[root]',
	breadcrumbs_tip : 'Click to select node, CTRL+Click to expand or collapse node, Double click to select and expand or collapse node.',
	breadcrumbs_root_tip : 'Click to select the top level node.'
}


Ext.ux.maximgb.treegrid.PagingToolbar = Ext.extend(Ext.PagingToolbar,
{
	onRender : function(ct, position)
	{
		Ext.ux.maximgb.treegrid.PagingToolbar.superclass.onRender.call(this, ct, position);
		this.updateUI();
	},

  getPageData : function()
  {
		var total = 0, cursor = 0;
		if (this.store) {
			cursor = this.store.getActiveNodePageOffset();
			total = this.store.getActiveNodeTotalCount();
		}
    return {
        total : total,
        activePage : Math.ceil((cursor + this.pageSize) / this.pageSize),
        pages :  total < this.pageSize ? 1 : Math.ceil(total / this.pageSize)
    };
	},
	
	updateInfo : function()
	{
		var count = 0, cursor = 0, total = 0, msg;
		if (this.displayEl) {
			if (this.store) {
				cursor = this.store.getActiveNodePageOffset();
				count = this.store.getActiveNodeCount();
				total = this.store.getActiveNodeTotalCount();
			}
			msg = count == 0 ?
				this.emptyMsg 
					:
        String.format(
            this.displayMsg,
            cursor + 1, cursor + count, total
        );
			this.displayEl.update(msg);
		}
	},
	
	updateUI : function()
	{
		var d = this.getPageData(), ap = d.activePage, ps = d.pages;

    this.afterTextEl.el.innerHTML = String.format(this.afterPageText, d.pages);
    this.field.dom.value = ap;
    this.first.setDisabled(ap == 1);
    this.prev.setDisabled(ap == 1);
    this.next.setDisabled(ap == ps);
    this.last.setDisabled(ap == ps);
    this.loading.enable();
    this.updateInfo();
	},

	unbind : function(store)
	{
		Ext.ux.maximgb.treegrid.PagingToolbar.superclass.unbind.call(this, store);
		store.un('activenodechange', this.onStoreActiveNodeChange, this);
	},

	bind : function(store)
	{
		Ext.ux.maximgb.treegrid.PagingToolbar.superclass.bind.call(this, store);
		store.on('activenodechange', this.onStoreActiveNodeChange, this);
	},
	
	beforeLoad : function(store, options)
	{
		Ext.ux.maximgb.treegrid.PagingToolbar.superclass.beforeLoad.call(this, store, options);
		if (options && options.params) {
			if(options.params[this.paramNames.start] === undefined) {
				options.params[this.paramNames.start] = 0;
			}
			if(options.params[this.paramNames.limit] === undefined) {
				options.params[this.paramNames.limit] = this.pageSize;
			}
		}
	},
	
	onClick : function(which)
	{
		var store = this.store,
				cursor = store ? store.getActiveNodePageOffset() : 0,
				total = store ? store.getActiveNodeTotalCount() : 0;
				
		switch(which){
			case "first":
				this.doLoad(0);
				break;
			case "prev":
				this.doLoad(Math.max(0, cursor - this.pageSize));
				break;
			case "next":
				this.doLoad(cursor + this.pageSize);
				break;
			case "last":
        var extra = total % this.pageSize;
        var lastStart = extra ? (total - extra) : total - this.pageSize;
        this.doLoad(lastStart);
				break;
			case "refresh":
				this.doLoad(cursor);
				break;
		}
	},
	
	onStoreActiveNodeChange : function(store, old_rec, new_rec)
	{
		if (this.rendered) {
			this.updateUI();
		}
	}
});

Ext.reg('ux-maximgb-treegrid', Ext.ux.maximgb.treegrid.GridPanel);
Ext.reg('ux-maximgb-paging', Ext.ux.maximgb.treegrid.PagingToolbar);



Ext.ns("Ext.grid.filter");
Ext.grid.filter.Filter = function(config){
	Ext.apply(this, config);
		
	this.events = {
		
		'activate': true,
		
		'deactivate': true,
		
		'update': true,
		
		'serialize': true
	};
	Ext.grid.filter.Filter.superclass.constructor.call(this);
	
	this.menu = new Ext.menu.Menu();
	this.init();
	
	if(config && config.value) {
		this.setValue(config.value);
		this.setActive(config.active !== false, true);
		delete config.value;
	}
};
Ext.extend(Ext.grid.filter.Filter, Ext.util.Observable, {
	
    
	active: false,
	
	dataIndex: null,
	
	menu: null,
	
	
	init: Ext.emptyFn,
	
	fireUpdate: function() {
		this.value = this.item.getValue();
		
		if(this.active) {
			this.fireEvent("update", this);
    }
		this.setActive(this.value.length > 0);
	},
	
	
	isActivatable: function() {
		return true;
	},
	
	
	setActive: function(active, suppressEvent) {
		if(this.active != active) {
			this.active = active;
			if(suppressEvent !== true) {
				this.fireEvent(active ? 'activate' : 'deactivate', this);
      }
		}
	},
	
	
	getValue: Ext.emptyFn,
	
		
	setValue: Ext.emptyFn,
	
	
	serialize: Ext.emptyFn,
	
	
	 validateRecord: function(){return true;}
});


Ext.grid.filter.StringFilter = Ext.extend(Ext.grid.filter.Filter, {
	updateBuffer: 500,
	
	
	init: function() {
		var value = this.value = new Ext.menu.EditableItem({iconCls: 'x-filter-icon-find'});
		value.on('keyup', this.onKeyUp, this);
		this.menu.add(value);
		
		this.updateTask = new Ext.util.DelayedTask(this.fireUpdate, this);
	},
	
	onKeyUp: function(event) {
		if(event.getKey() == event.ENTER){
			this.menu.hide(true);
			return;
		}
		this.updateTask.delay(this.updateBuffer);
	},
	
	isActivatable: function() {
		return this.value.getValue().length > 0;
	},
	
	fireUpdate: function() {		
		if(this.active) {
			this.fireEvent("update", this);
    }
		this.setActive(this.isActivatable());
	},
	
	setValue: function(value) {
		this.value.setValue(value);
		this.fireEvent("update", this);
	},
	
	getValue: function() {
		return this.value.getValue();
	},
	
	serialize: function() {
		var args = {type: 'string', value: this.getValue()};
		this.fireEvent('serialize', args, this);
		return args;
	},
	
	validateRecord: function(record) {
		var val = record.get(this.dataIndex);
		if(typeof val != "string") {
			return this.getValue().length == 0;
    }
		return val.toLowerCase().indexOf(this.getValue().toLowerCase()) > -1;
	}
});


Ext.grid.filter.DateFilter = Ext.extend(Ext.grid.filter.Filter, {
	dateFormat: 'm/d/Y',
	pickerOpts: {},
	beforeText: "Before", 
	afterText: "After", 
	onText: "On",	
	
	init: function() {
		var opts = Ext.apply(this.pickerOpts, {
			minDate: this.minDate, 
			maxDate: this.maxDate, 
			format:  this.dateFormat
		});
		var dates = this.dates = {
			'before': new Ext.menu.CheckItem({text: this.beforeText, menu: new Ext.menu.DateMenu(opts)}),
			'after':  new Ext.menu.CheckItem({text: this.afterText, menu: new Ext.menu.DateMenu(opts)}),
			'on':     new Ext.menu.CheckItem({text: this.onText, menu: new Ext.menu.DateMenu(opts)})
    };
				
		this.menu.add(dates.before, dates.after, "-", dates.on);
		
		for(var key in dates) {
			var date = dates[key];
			date.menu.on('select', this.onSelect.createDelegate(this, [date]), this);
  
      date.on('checkchange', function(){
        this.setActive(this.isActivatable());
			}, this);
		};
	},
  
	onSelect: function(date, menuItem, value, picker) {
    date.setChecked(true);
    var dates = this.dates;
    
    if(date == dates.on) {
      dates.before.setChecked(false, true);
      dates.after.setChecked(false, true);
    } else {
      dates.on.setChecked(false, true);
      
      if(date == dates.after && dates.before.menu.picker.value < value) {
        dates.before.setChecked(false, true);
      } else if (date == dates.before && dates.after.menu.picker.value > value) {
        dates.after.setChecked(false, true);
      }
    }
    
    this.fireEvent("update", this);
  },
  
	getFieldValue: function(field) {
		return this.dates[field].menu.picker.getValue();
	},
	
	getPicker: function(field) {
		return this.dates[field].menu.picker;
	},
	
	isActivatable: function() {
		return this.dates.on.checked || this.dates.after.checked || this.dates.before.checked;
	},
	
	setValue: function(value) {
		for(var key in this.dates) {
			if(value[key]) {
				this.dates[key].menu.picker.setValue(value[key]);
				this.dates[key].setChecked(true);
			} else {
				this.dates[key].setChecked(false);
			}
    }
	},
	
	getValue: function() {
		var result = {};
		for(var key in this.dates) {
			if(this.dates[key].checked) {
				result[key] = this.dates[key].menu.picker.getValue();
      }
    }	
		return result;
	},
	
	serialize: function() {
		var args = [];
		if(this.dates.before.checked) {
			args = [{type: 'date', comparison: 'lt', value: this.getFieldValue('before').format(this.dateFormat)}];
    }
		if(this.dates.after.checked) {
			args.push({type: 'date', comparison: 'gt', value: this.getFieldValue('after').format(this.dateFormat)});
    }
		if(this.dates.on.checked) {
			args = {type: 'date', comparison: 'eq', value: this.getFieldValue('on').format(this.dateFormat)};
    }

    this.fireEvent('serialize', args, this);
		return args;
	},
	
	validateRecord: function(record) {
		var val = record.get(this.dataIndex).clearTime(true).getTime();
		
		if(this.dates.on.checked && val != this.getFieldValue('on').clearTime(true).getTime()) {
			return false;
    }
		if(this.dates.before.checked && val >= this.getFieldValue('before').clearTime(true).getTime()) {
			return false;
    }
		if(this.dates.after.checked && val <= this.getFieldValue('after').clearTime(true).getTime()) {
			return false;
    }
		return true;
	}
});


Ext.grid.filter.ListFilter = Ext.extend(Ext.grid.filter.Filter, {
	labelField:  'text',
	loadingText: 'Loading...',
	loadOnShow:  true,
	value:       [],
	loaded:      false,
	phpMode:     false,
	
	init: function(){
		this.menu.add('<span class="loading-indicator">' + this.loadingText + '</span>');
		
		if(this.store && this.loadOnShow) {
		  this.menu.on('show', this.onMenuLoad, this);
		} else if(this.options) {
			var options = [];
			for(var i=0, len=this.options.length; i<len; i++) {
				var value = this.options[i];
				switch(Ext.type(value)) {
					case 'array':  
            options.push(value);
            break;
					case 'object':
            options.push([value.id, value[this.labelField]]);
            break;
					case 'string':
            options.push([value, value]);
            break;
				}
			}
			
			this.store = new Ext.data.Store({
				reader: new Ext.data.ArrayReader({id: 0}, ['id', this.labelField])
			});
			this.options = options;
			this.menu.on('show', this.onMenuLoad, this);
		}
    
		this.store.on('load', this.onLoad, this);
		this.bindShowAdapter();
	},
	
	
	bindShowAdapter: function() {
		var oShow = this.menu.show;
		var lastArgs = null;
		this.menu.show = function() {
			if(arguments.length == 0) {
				oShow.apply(this, lastArgs);
			} else {
				lastArgs = arguments;
				oShow.apply(this, arguments);
			}
		};
	},
	
	onMenuLoad: function() {
		if(!this.loaded) {
			if(this.options) {
				this.store.loadData(this.options);
      } else {
				this.store.load();
      }
		}
	},
	
	onLoad: function(store, records) {
		var visible = this.menu.isVisible();
		this.menu.hide(false);
		
		this.menu.removeAll();
		
		var gid = this.single ? Ext.id() : null;
		for(var i=0, len=records.length; i<len; i++) {
			var item = new Ext.menu.CheckItem({
				text: records[i].get(this.labelField), 
				group: gid, 
				checked: this.value.indexOf(records[i].id) > -1,
				hideOnClick: false
      });
			
			item.itemId = records[i].id;
			item.on('checkchange', this.checkChange, this);
						
			this.menu.add(item);
		}
		
		this.setActive(this.isActivatable());
		this.loaded = true;
		
		if(visible) {
			this.menu.show(); //Adaptor will re-invoke with previous arguments
    }
	},
	
	checkChange: function(item, checked) {
		var value = [];
		this.menu.items.each(function(item) {
			if(item.checked) {
				value.push(item.itemId);
      }
		},this);
		this.value = value;
		
		this.setActive(this.isActivatable());
		this.fireEvent("update", this);
	},
	
	isActivatable: function() {
		return this.value.length > 0;
	},
	
	setValue: function(value) {
		var value = this.value = [].concat(value);

		if(this.loaded) {
			this.menu.items.each(function(item) {
				item.setChecked(false, true);
				for(var i=0, len=value.length; i<len; i++) {
					if(item.itemId == value[i]) {
						item.setChecked(true, true);
          }
        }
			}, this);
    }
			
		this.fireEvent("update", this);
	},
	
	getValue: function() {
		return this.value;
	},
	
	serialize: function() {
    var args = {type: 'list', value: this.phpMode ? this.value.join(',') : this.value};
    this.fireEvent('serialize', args, this);
		return args;
	},
	
	validateRecord: function(record) {
		return this.getValue().indexOf(record.get(this.dataIndex)) > -1;
	}
});


Ext.grid.filter.NumericFilter = Ext.extend(Ext.grid.filter.Filter, {
	init: function() {
		this.menu = new Ext.menu.RangeMenu();
		
		this.menu.on("update", this.fireUpdate, this);
	},
	
	fireUpdate: function() {
		this.setActive(this.isActivatable());
		this.fireEvent("update", this);
	},
	
	isActivatable: function() {
		var value = this.menu.getValue();
		return value.eq !== undefined || value.gt !== undefined || value.lt !== undefined;
	},
	
	setValue: function(value) {
		this.menu.setValue(value);
	},
	
	getValue: function() {
		return this.menu.getValue();
	},
	
	serialize: function() {
		var args = [];
		var values = this.menu.getValue();
		for(var key in values) {
			args.push({type: 'numeric', comparison: key, value: values[key]});
    }
		this.fireEvent('serialize', args, this);
		return args;
	},
	
	validateRecord: function(record) {
		var val = record.get(this.dataIndex),
			values = this.menu.getValue();
			
		if(values.eq != undefined && val != values.eq) {
			return false;
    }
		if(values.lt != undefined && val >= values.lt) {
			return false;
    }
		if(values.gt != undefined && val <= values.gt) {
			return false;
    }
		return true;
	}
});


Ext.grid.filter.BooleanFilter = Ext.extend(Ext.grid.filter.Filter, {
  defaultValue: false,
  yesText: "Yes",
  noText: "No",
  
	init: function(){
    var gId = Ext.id();
		this.options = [
			new Ext.menu.CheckItem({text: this.yesText, group: gId, checked: this.defaultValue === true}),
			new Ext.menu.CheckItem({text: this.noText, group: gId, checked: this.defaultValue === false})
    ];
		
		this.menu.add(this.options[0], this.options[1]);
		
		for(var i=0; i<this.options.length; i++) {
			this.options[i].on('click', this.fireUpdate, this);
			this.options[i].on('checkchange', this.fireUpdate, this);
		}
	},
	
	isActivatable: function() {
		return true;
	},
	
	fireUpdate: function() {		
		this.fireEvent("update", this);			
		this.setActive(true);
	},
	
	setValue: function(value) {
		this.options[value ? 0 : 1].setChecked(true);
	},
	
	getValue: function() {
		return this.options[0].checked;
	},
	
	serialize: function() {
		var args = {type: 'boolean', value: this.getValue()};
		this.fireEvent('serialize', args, this);
		return args;
	},
	
	validateRecord: function(record) {
		return record.get(this.dataIndex) == this.getValue();
	}
});


Ext.app.SearchField = Ext.extend(Ext.form.TwinTriggerField, {
    initComponent : function(){
        Ext.app.SearchField.superclass.initComponent.call(this);
        this.on('specialkey', function(f, e){
            if(e.getKey() == e.ENTER){
                this.onTrigger2Click();
            }
        }, this);
    },

    validationEvent:false,
    validateOnBlur:false,
    trigger1Class:'x-form-clear-trigger',
    trigger2Class:'x-form-search-trigger',
    hideTrigger1:true,
    width:180,
    hasSearch : false,
    paramName : 'query',

    onTrigger1Click : function(){
        if(this.hasSearch){
            this.el.dom.value = '';			
            var o = {start: 0};
            this.store.baseParams = this.store.baseParams || {};
            this.store.baseParams[this.paramName] = '';
            this.store.reload({params:o});
            this.triggers[0].hide();
            this.hasSearch = false;
        }
		this.el.parent().parent().parent().parent().parent().parent().removeClass('x-toolbar-search');
    },

    onTrigger2Click : function(){
        var v = this.getRawValue();
        if(v.length < 1){
            this.onTrigger1Click();
            return;
        }
        var o = {start: 0};
        this.store.baseParams = this.store.baseParams || {};
        this.store.baseParams[this.paramName] = v;
        this.store.reload({params:o});
        this.hasSearch = true;
        this.triggers[0].show();
		this.el.parent().parent().parent().parent().parent().parent().addClass('x-toolbar-search');
    }
});

Ext.reg('gxuiSearchField', Ext.app.SearchField);

Ext.grid.SmartCheckboxSelectionModel = Ext.extend(Ext.grid.RowSelectionModel, {
    
    header: '<div id="x-grid3-hd-checker" class="x-grid3-hd-checker"> </div>',
    
    width: 20,
    
    sortable: false,
    
    email: false,
    
    excel: false,
    
    
    alwaysSelectOnCheck: false,
    
    // private
    menuDisabled:true,
    fixed:true,
    id: 'checker',
    dataIndex: '', // Define the dataIndex when you construct the selectionModel, not here

    // private
    initEvents : function(){
        // Call the parent
        Ext.grid.SmartCheckboxSelectionModel.superclass.initEvents.call(this);
        // Assign the handlers for the mousedown events
        this.grid.on('render', function(){
            var view = this.grid.getView();
            view.on('columnmove', this.onColumnMove, this);
            view.mainBody.on('mousedown', this.onMouseDown, this);
            Ext.fly(view.innerHd).on('mousedown', this.onHdMouseDown, this);
        }, this);        
           // Disable the rowNav created in our parent object, otherwise pressing DOWN will go down two rows!
        this.rowNav.disable();
        // Create our new rowNav that controls checkboxes as well
        this.rowNav2 = new Ext.KeyNav(this.grid.getGridEl(), {
            "up" : function(e){
                if(!e.shiftKey){
                    if(!this.email){ this.selectPreviousChecked(e.shiftKey); }
                    if(this.email){ this.selectPrevious(e.shiftKey); }
                }
                else if(this.last !== false && this.lastActive !== false){
                    var last = this.last;
                    if(!this.email){ this.selectRangeChecked(this.last, this.lastActive-1); }
                    if(this.email){ this.selectRange(this.last,  this.lastActive-1); }
                    this.grid.getView().focusRow(this.lastActive);
                    if(last !== false){
                        this.last = last;
                    }
                }
                else{
                    this.selectFirstRow();
                    if(!this.email){ this.toggleChecked(0, true); }
                }
            },
            "down" : function(e){
                if(!e.shiftKey){
                    if(!this.email){ this.selectNextChecked(e.shiftKey); }
                    if(this.email){ this.selectNext(e.shiftKey); }
                }
                else if(this.last !== false && this.lastActive !== false){
                    var last = this.last;
                    if(!this.email){ this.selectRangeChecked(this.last, this.lastActive+1); }
                    if(this.email){ this.selectRange(this.last,  this.lastActive+1); }
                    this.grid.getView().focusRow(this.lastActive,true);
                    if(last !== false){
                        this.last = last;
                    }
                }
                else{
                    this.selectFirstRow();
                    if(!this.email){ this.toggleChecked(0, true); }
                }
            },
            scope: this
        });
        // Listen for the movement of the columns  
        this.grid.on('columnmove', function(p){
            var t = Ext.get('x-grid3-hd-checker');
            if(t != null){
                if(t.dom.className != 'x-grid3-hd-checker'){
                       Ext.fly(t.dom.parentNode).removeClass('x-grid3-hd-checker');
                }
            }
        });
        // If we sent a store to the selModel, auto-select rows based on dataIndex
        if (this.grid.store){
            this.grid.store.on('load', function(p){
                // This block of code checks the status of the checkbox header, 
                // and if checked, will check all other checkboxes (but not on the initial load)
                var t = Ext.get('x-grid3-hd-checker');
                if(t != null){
                    if(t.dom.className == 'x-grid3-hd-checker' && Ext.state.Manager.loaded){
                        var hd = Ext.fly(t.dom.parentNode);
                        var isChecked = hd.hasClass('x-grid3-hd-checker-on');
                        if(isChecked){
                            hd.addClass('x-grid3-hd-checker-on');
                            if(!this.email){ this.selectAll(); }
                            this.selectAllChecked(true);
                        }
                    }
                    else{
                           Ext.fly(t.dom.parentNode).removeClass('x-grid3-hd-checker');
                    }
                }
            
                // This block of code will pre-select checkboxes based on the dataIndex supplied,
                // but only on the initial load.
                  var dataIndex = this.grid.getSelectionModel().dataIndex; // the dataIndex for the selectionModel
                  var count = this.grid.store.getCount();
                for(var i = 0, len = count; i < len; i++){
                    var dataIndexValue = p.data.items[i].data[dataIndex]; // the value of the dataIndex for each row
                    var isSelected = this.isSelected(i);
                    if((dataIndexValue == true || isSelected) && !Ext.state.Manager.loaded){
                        // This code will only run the first time a grid is loaded 
                        // Make sure that any "checked" rows are also selected
                        if(!this.email || this.alwaysSelectOnCheck){ this.grid.getSelectionModel().selectRow(i, true); }
                    }
                    else if(isSelected){
                        // Let the state.Manager check the correct rows now
                        if(!this.email){ this.toggleChecked(i, true); }
                    }
                    else{
                        // Uncheck everything else
                        if(!this.email){ this.toggleChecked(i, false); }
                    }
                }
            }, this);
        }
    },

    
    toggleChecked : function(rowIndex, c){
        if(this.locked) return;
           var record = this.grid.store.getAt(rowIndex);
        if(c === true){
            // Check
               record.set(this.dataIndex, true);
           }
           else if(c === false){
               // Uncheck
               record.set(this.dataIndex, false);
           }
           else{
               // Toggle checked / unchecked
               record.set(this.dataIndex, !record.data[this.dataIndex]);
           }
    },

    
    selectAllChecked : function(c, e){
        if(this.locked) return;
         var count = this.grid.store.getCount();
        for(var i = 0, len = count; i < len; i++){
            if(c){
                if(i !== e){
                    this.toggleChecked(i, true);
                }
            }
            else{
                if(i !== e){
                    this.toggleChecked(i, false);
                }
            }
        }            
    },
    
    
    clearChecked : function(fast){
        if(this.locked) return;
        if(fast !== true){
            var count = this.grid.store.getCount();
            for(var i = 0, len = count; i < len; i++){
                var isSelected = this.isSelected(i);
                if(!isSelected){
                    this.toggleChecked(i, false);
                }
            }
        }
        else{
            // Quick and dirty method to uncheck everything
            this.selectAllChecked(false);
        }
        this.last = false;
    },    
    
    
    selectRangeChecked : function(startRow, endRow, keepExisting){
        if(this.locked) return;
        if(!keepExisting){
            if(!this.email || this.alwaysSelectOnCheck){ this.clearSelections(); }
            this.clearChecked();
        }    
        if(startRow <= endRow){
            for(var i = startRow; i <= endRow; i++){
                if(this.grid.store.getAt(i)){
                    this.toggleChecked(i, true);
                    if(!this.email || this.alwaysSelectOnCheck){ this.selectRow(i, true); }
                }
            }
        }
        else{
            for(var i = startRow; i >= endRow; i--){
                if(this.grid.store.getAt(i)){
                    this.toggleChecked(i, true);
                    if(!this.email || this.alwaysSelectOnCheck){ this.selectRow(i, true); }
                }
            }
        }    
    },
    
    selectPreviousChecked : function(keepExisting){
        if(this.hasPrevious()){
            // Select the next row
            this.selectRow(this.last-1, keepExisting);
            // Set the focus
            this.grid.getView().focusRow(this.last);
            if(!this.email){         
                // Check the current (selected) row
                this.toggleChecked(this.last, true);
                // Uncheck all other rows
                this.selectAllChecked(false, this.last);
            }
            return true;
        }
        return false;
    },
          
    selectNextChecked : function(keepExisting){
        if(this.hasNext()){
            // Select the next row
            if(!this.email){ this.selectRow(this.last+1, keepExisting); }
            // Set the focus
            this.grid.getView().focusRow(this.last);
            if(!this.email){      
                // Check the current (selected) row
                this.toggleChecked(this.last, true);
                // Uncheck all other rows
                this.selectAllChecked(false, this.last);
            }
            return true;
        }
        return false;
    },    
   
    
    handleMouseDown : function(g, rowIndex, e){
        var t = e.getTarget('.ux-row-action-item');
        if(!t) {
            if(e.button !== 0 || this.isLocked()){
                return;
            };
            var view = this.grid.getView();
            var record = this.grid.store.getAt(rowIndex);
            if(e.shiftKey && this.last !== false){
                var last = this.last;
                this.selectRange(last, rowIndex, e.ctrlKey);
                if(!this.email){ this.selectRangeChecked(last, rowIndex, e.ctrlKey); }
                this.last = last; // reset the last
                view.focusRow(rowIndex);
            }else{
                var isChecked = record.data[this.dataIndex];
                var isSelected = this.isSelected(rowIndex);
                
                if (isSelected){
                    this.deselectRow(rowIndex);
                    if(!this.email){ this.toggleChecked(rowIndex, false); }
                }else{
                    if(!this.excel){
                        this.selectRow(rowIndex, true);
                        if(!this.email){ 
                            this.toggleChecked(rowIndex, true);
                        }
                    }
                    else{
                        this.selectRow(rowIndex, e.ctrlKey);
                        if(!this.email){
                            this.selectRangeChecked(rowIndex, rowIndex, e.ctrlKey);
                        }
                    }
                    view.focusRow(rowIndex);
                }
            }
        }
    },
    
    onMouseDown : function(e, t){
        if(t.className && t.className.indexOf('x-grid3-cc-'+this.id) != -1){
            e.stopEvent();
            // Define variables
            var view = this.grid.getView();
            var rowIndex = view.findRowIndex(t);
            var record = this.grid.store.getAt(rowIndex);            
            var isSelected = this.isSelected(rowIndex);
            var isChecked = record.data[this.dataIndex];
            // Logic to select/de-select rows and the checkboxes
            if(!this.email || this.alwaysSelectOnCheck){
                if (isSelected){
                    if(!isChecked && this.alwaysSelectOnCheck){
                        this.toggleChecked(rowIndex, true);
                    }
                    else{
                        this.deselectRow(rowIndex);
                        this.toggleChecked(rowIndex, false);
                    }
                }
                else{
                    this.selectRow(rowIndex, true);
                    this.toggleChecked(rowIndex, true);
                    view.focusRow(rowIndex);
                }
            }
            else{
                if (isChecked){
                    this.toggleChecked(rowIndex, false);
                }
                else{
                    this.toggleChecked(rowIndex, true);
                }
            }
            view.focusRow(rowIndex);
        }
        // Load the state manager
           Ext.state.Manager.setProvider(new Ext.state.CookieProvider());            
           Ext.state.Manager.loaded = true;            
    },
    

    
    onHdMouseDown : function(e, t){
        if(t.className == 'x-grid3-hd-checker'){
            e.stopEvent();
            var hd = Ext.fly(t.parentNode);
            var isChecked = hd.hasClass('x-grid3-hd-checker-on');
            if(isChecked){
                hd.removeClass('x-grid3-hd-checker-on');
                if(!this.email || this.alwaysSelectOnCheck){ this.clearSelections(); }
                this.clearChecked(true); // the true param enables fast mode
            }else{
                hd.addClass('x-grid3-hd-checker-on');
                if(!this.email || this.alwaysSelectOnCheck){ this.selectAll(); }
                this.selectAllChecked(true);
            }
        }
        // Load the state manager
           Ext.state.Manager.setProvider(new Ext.state.CookieProvider());            
           Ext.state.Manager.loaded = true;            
    },
    
    
    renderer : function(v, p, record){
        p.css += ' x-grid3-check-col-td'; 
        return '<div class="x-grid3-check-col'+(v?'-on':'')+' x-grid3-cc-'+this.id+'"> </div>';
    }
}); 


Ext.grid.RadioSelectionModel = function(config) {

    // call parent
    Ext.grid.RadioSelectionModel.superclass.constructor.call(this, config);

    // force renderer to run in this scope
    this.renderer = function(v, p, record){
        var checked = record === this.selections.get(0);
        var retval = 
            '<div class="x-grid3-row-radio"><input type="radio" name="' + this.id + '"'
            + (checked ? 'checked="checked"' : '')
            + '></div>';
        return retval;
    }.createDelegate(this);

}; // end of constructor

Ext.extend(Ext.grid.RadioSelectionModel, Ext.grid.RowSelectionModel, {
     header:'<div> </div>'
    ,width:25
    ,sortable:false

    // private
    ,fixed:true
    ,dataIndex:''
    ,id:'radio'
    ,singleSelect:true

    ,selectRow:function(index) {
        // call parent
        Ext.grid.RadioSelectionModel.superclass.selectRow.apply(this, arguments);

        // check radio
        var row = Ext.fly(this.grid.view.getRow(index));
        if(row) {
            row.child('input[type=radio]').dom.checked = true;
        }
    } // eo function selectRow

}); // eo extend

// eof 



Ext.ux.Portal = Ext.extend(Ext.Panel, {
    layout: 'column',
    autoScroll:true,
    cls:'x-portal',
    defaultType: 'portalcolumn',

    initComponent : function(){
        Ext.ux.Portal.superclass.initComponent.call(this);
        this.addEvents({
            validatedrop:true,
            beforedragover:true,
            dragover:true,
            beforedrop:true,
            drop:true,
			dragout:true // Added support to dragout event to the original Ext sample
        });
    },

    initEvents : function(){
        Ext.ux.Portal.superclass.initEvents.call(this);
        this.dd = new Ext.ux.Portal.DropZone(this, this.dropConfig);
    }
});
Ext.reg('portal', Ext.ux.Portal);


Ext.ux.Portal.DropZone = function(portal, cfg){
    this.portal = portal;
    Ext.dd.ScrollManager.register(portal.body);
    Ext.ux.Portal.DropZone.superclass.constructor.call(this, portal.bwrap.dom, cfg);
    portal.body.ddScrollConfig = this.ddScrollConfig;
};

Ext.extend(Ext.ux.Portal.DropZone, Ext.dd.DropTarget, {
    ddScrollConfig : {
        vthresh: 50,
        hthresh: -1,
        animate: true,
        increment: 200
    },

    createEvent : function(dd, e, data, col, c, pos){
        return {
            portal: this.portal,
            panel: data.panel,
            columnIndex: col,
            column: c,
            position: pos,
            data: data,
            source: dd,
            rawEvent: e,
            status: this.dropAllowed
        };
    },

    notifyOver : function(dd, e, data){
        var xy = e.getXY(), portal = this.portal, px = dd.proxy;
        // case column widths
        if(!this.grid){
            this.grid = this.getGrid();
        }

        // handle case scroll where scrollbars appear during drag
        var cw = portal.body.dom.clientWidth;
        if(!this.lastCW){
            this.lastCW = cw;
        }else if(this.lastCW != cw){
            this.lastCW = cw;
            portal.doLayout();
            this.grid = this.getGrid();
        }

        // determine column
        var col = 0, xs = this.grid.columnX, cmatch = false;
        for(var len = xs.length; col < len; col++){
            if(xy[0] < (xs[col].x + xs[col].w)){
                cmatch = true;
                break;
            }
        }
        // no match, fix last index
        if(!cmatch){
            col--;
        }

        // find insert position
        var p, match = false, pos = 0,
            c = portal.items.itemAt(col),
            items = c.items.items;

       for(var len = items.length; pos < len; pos++){
            p = items[pos];
            var h = p.el.getHeight();
            if(h !== 0 && (p.el.getY()+(h/2)) > xy[1]){
                match = true;
                break;
            }
        }

        var overEvent = this.createEvent(dd, e, data, col, c, 
                match && p ? pos : c.items.getCount());

        if(portal.fireEvent('validatedrop', overEvent) !== false &&
           portal.fireEvent('beforedragover', overEvent) !== false){

            // make sure proxy width is fluid
            px.getProxy().setWidth('auto');

            if(p){
                px.moveProxy(p.el.dom.parentNode, match ? p.el.dom : null);
            }else{
                px.moveProxy(c.el.dom, null);
            }

            this.lastPos = {c: c, col: col, p: match && p ? pos : false};
            this.scrollPos = portal.body.getScroll();

            portal.fireEvent('dragover', overEvent);

            return overEvent.status;;
        }else{
            return overEvent.status;
        }

    },

    notifyOut : function(dd, e, data){
        delete this.grid;
        if(!this.lastPos){
            return;
        }
		var c = this.lastPos.c, col = this.lastPos.col, pos = this.lastPos.p;
		
		var outEvent = this.createEvent(dd, e, data, col, c, 
                pos !== false ? pos : c.items.getCount());
				
		this.portal.fireEvent('dragout', outEvent);
    },

    notifyDrop : function(dd, e, data){
        delete this.grid;
        if(!this.lastPos){
            return;
        }
        var c = this.lastPos.c, col = this.lastPos.col, pos = this.lastPos.p;

        var dropEvent = this.createEvent(dd, e, data, col, c, 
                pos !== false ? pos : c.items.getCount());

        if(this.portal.fireEvent('validatedrop', dropEvent) !== false &&
           this.portal.fireEvent('beforedrop', dropEvent) !== false){

            dd.proxy.getProxy().remove();
            dd.panel.el.dom.parentNode.removeChild(dd.panel.el.dom);
            if(pos !== false){
                c.insert(pos, dd.panel);
            }else{
                c.add(dd.panel);
            }
            if (dd.panel.resetPositioning){
				dd.panel.resetPositioning();// WA: Introduced te enable draggable panels
				dd.panel.setWidth('auto');//WA: Introduced te enable draggable panels
            }
            c.doLayout();

            this.portal.fireEvent('drop', dropEvent);
			
            // scroll position is lost on drop, fix it
            var st = this.scrollPos.top;
            if(st){
                var d = this.portal.body.dom;
                setTimeout(function(){
                    d.scrollTop = st;
                }, 10);
            }
        }
        delete this.lastPos;
    },

    // internal cache of body and column coords
    getGrid : function(){
        var box = this.portal.bwrap.getBox();
        box.columnX = [];
        this.portal.items.each(function(c){
             box.columnX.push({x: c.el.getX(), w: c.el.getWidth()});
        });
        return box;
    }
});



Ext.ux.PortalColumn = Ext.extend(Ext.Container, {
    layout: 'anchor',
    autoEl: 'div',
    defaultType: 'portlet',
    cls:'x-portal-column'
});
Ext.reg('portalcolumn', Ext.ux.PortalColumn);


Ext.ux.Portlet = Ext.extend(Ext.Panel, {
    anchor: '100%',
    frame:true,
    collapsible:true,
    draggable:true,
    cls:'x-portlet'
});
Ext.reg('portlet', Ext.ux.Portlet);
/// <reference path="..\VStudio\vswd-ext_2.2.js" />
// gxui namespace and user controls base class definition


gxui = function() {

	return {
		initialize: function() {

			// Initialize QuickTips
			Ext.QuickTips.init();

			// Define a namespace for extensions of Ext components
			Ext.namespace('gxui.ext');
			// Define a namespace for object properties management classes
			Ext.namespace('gxui.Properties');
			// Define a namespace for GX interop classes
			Ext.namespace('gxui.GX');
			// Define a namespace for GxUI user extensions
			Ext.namespace('gxui.ux');

			gx.fx.obs.addObserver('gx.onready', this, function() {
				if (gx) {
					if (gx.staticDirectory != "")
						this.StaticContent = gx.staticDirectory;
					else
						this.StaticContent = this.getCookie('StaticContent');

					Ext.BLANK_IMAGE_URL = gx.util.resourceUrl(gx.basePath + this.StaticContent + "Shared/gxflow_ext/resources/images/default/s.gif", true);
				}
			});

			// Default State provider
			Ext.state.Manager.setProvider(new Ext.state.CookieProvider({
				expires: new Date(new Date().getTime() + (1000 * 60 * 60 * 24 * 365)) //365 days
			}));

			//////////////////////////////////////////////////////////////////////////////////////////
			// This is a temporal fix for a problem with Chrome and FitLayout http://extjs.com/forum/showthread.php?p=312137#post312137
			Ext.override(Ext.layout.FitLayout, {
				onLayout: function(ct, target) {
					Ext.layout.FitLayout.superclass.onLayout.call(this, ct, target);
					if (!this.container.collapsed) {
						var size = !Ext.isChrome && target.dom != Ext.getBody().dom ? target.getStyleSize() : target.getViewSize();
						this.setItemSize(this.activeItem || ct.items.itemAt(0), size);
					}
				}
			});
			//////////////////////////////////////////////////////////////////////////////////////////
			// This is a temporal fix for a problem with insertBefore function in IE.
			Ext.override(Ext.dd.PanelProxy, {
				moveProxy: function(parentNode, before) {
					if (this.proxy) {
						if (Ext.isIE && before == undefined) {
							parentNode.insertBefore(this.proxy.dom);
							return;
						}
						parentNode.insertBefore(this.proxy.dom, before);
					}
				}
			});
			//////////////////////////////////////////////////////////////////////////////////////////
			// This is a temporal fix for a problem with blur when a TextField is used inside a TabPanel and the tab is changed.
			Ext.override(Ext.form.TextField, {
				onFocus: function() {
					Ext.form.TextField.superclass.onFocus.call(this);
					this.mimicing = true;
					Ext.get(Ext.isIE ? document.body : document).on("mousedown", this.mimicBlur, this, { delay: 10 });
				},
				mimicBlur: function(e) {
					if (this.el.dom != e.target) {
						this.mimicing = false;
						Ext.get(Ext.isIE ? document.body : document).un("mousedown", this.mimicBlur, this);
						this.onBlur();
					}
				},
				onDestroy: function() {
					if (this.mimicing) {
						Ext.get(Ext.isIE ? document.body : document).un("mousedown", this.mimicBlur, this);
					}
					Ext.form.TextField.superclass.onDestroy.call(this);
				}
			});

			// Set an initial z-index value below the one used by GX for popups, so windows will be shown behind the popups.
			Ext.WindowMgr.zseed = 800;

			if (gx.HTML5) {
				//////////////////////////////////////////////////////////////////////////////////////////
				// This is a temporal fix: getAttributeNS doesn't work in IE9.
				if (Ext.isIE && gx.util.browser.ieVersion() > 8) {
					Ext.override(Ext.Element, {
						getAttributeNS: function(ns, name) {
							var d = this.dom;
							return d.getAttributeNS(ns, name) || d.getAttribute(ns + ":" + name) || d.getAttribute(name) || d[name];
						}
					});
				}
				//////////////////////////////////////////////////////////////////////////////////////////

				Ext.get(document.documentElement).addClass('html5');
			}
		},

		
		CBoolean: function(str) {
			if (str) {
				if (typeof (str) == 'string')
					return (str.toLowerCase() == "true")
				return str;
			}
			else
				return false;
		},


		
		clone: function(obj) {
			if (obj instanceof Array)
				return gxui.copyArray(obj);
			if (typeof (obj) != 'object')
				return obj;
			if (obj == null)
				return obj;
			if (obj.clone)
				return obj.clone();
			var cloneObj = new Object();
			for (var i in obj)
				cloneObj[i] = gxui.clone(obj[i]);
			return cloneObj;
		},

		
		copyArray: function(arr) {
			var res = [];
			for (var i = 0; i < arr.length; i++)
				res.push(gxui.clone(arr[i]));
			return res;
		},

		getCookie: function(c_name) {
			if (document.cookie.length > 0) {
				c_start = document.cookie.indexOf(c_name + "=");
				if (c_start != -1) {
					c_start = c_start + c_name.length + 1;
					c_end = document.cookie.indexOf(";", c_start);
					if (c_end == -1) c_end = document.cookie.length;
					return unescape(document.cookie.substring(c_start, c_end));
				}
			}
			return "";
		},

		setCookie: function(name, value, days) {
			if (days) {
				var date = new Date();
				date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
				var expires = "; expires=" + date.toGMTString();
			}
			else expires = "";
			document.cookie = name + "=" + value + expires + "; path=/";
		},

		dateFormat: function() {
			var gxDF = gx.dateFormat;
			switch (gxDF) {
				case "MDY": return "m/d/y";
				case "MDY4": return "m/d/Y";
				case "YMD": return "y/m/d";
				case "Y4MD": return "Y/m/d";
				case "DMY": return "d/m/y";
				case "DMY4": return "d/m/Y";
			}
		},

		date: function(string) {
			return new Date.parseDate(string, this.dateFormat());
		},

		
		afterShow: function(fn, scope, options) {
			gxui.UserControlManager.afterShow(fn, scope, options);
		}
	};
} ();

gxui.initialize();
/// <reference path="..\VStudio\vswd-ext_2.2.js" />

gxui.UserControl = function(options) {
	this.setOptions(options)
	this.initialize();
};

Ext.extend(gxui.UserControl, Ext.util.Observable, {
	//private
	setOptions: function(options) {
		this.options = {
			register: true
		};

		for (property in (options || {})) {
			this.options[property] = options[property];
		}
	},

	//private
	initialize: function() {
		this.rendered = false;

		this.addEvents({
			
			"show": true,
			
			"destroy": true
		});

		if (this.options.register)
			this.register();
	},

	
	show: function() {
		try {
			if (!this.rendered) {
				this.rendered = true;
				this.onRender();
			}
			else {
				if (this.onRefresh)
					this.onRefresh();
			}
		}
		catch (e) {
			gx.dbg.logEx(e, 'gxui.js', 'show');
		}
		finally {
			this.fireEvent("show", this);
		}
	},

	
	forceRendering: function() {
		this.rendered = false;
	},

	
	destroy: function() {
		try {
			this.onDestroy();
		}
		catch (e) {
			gx.dbg.logEx(e, 'gxui.js', 'destroy');
		}

		this.fireEvent("destroy", this);
	},

	
	onRender: Ext.emptyFn,

	
	onRefresh: Ext.emptyFn,

	
	onDestroy: function() {
		var c = this.getUnderlyingControl();
		if (c) {
			var ct = c.ownerCt;
			if (ct) {
				if (ct.remove) {
					ct.remove(c);
				}
			}
			else {
				if (c.destroy) {
					c.destroy();
				}
			}
		}
	},

	
	getUnderlyingControl: Ext.emptyFn,

	//private
	
	register: function() {
		gxui.UserControlManager.register(this);
	},

	//private
	
	unregister: function() {
		gxui.UserControlManager.unregister(this);
	},

	//private
	
	registerCt: function(el, addFn, doLayoutFn, scope) {
		gxui.UserControlManager.registerContainer(this, el, addFn, doLayoutFn, scope);
	},

	//private
	
	unregisterCt: function(toRem) {
		gxui.UserControlManager.unregisterContainer(toRem);
	},

	//private
	
	addToParentContainer: function(uc) {
		gxui.afterShow(function() {
			try {
				var el = Ext.get(this.getContainerControl());
				this.checkIfInline(el);
				for (var el = Ext.get(this.getContainerControl()); el; el = el.parent("div")) {
					var ct = gxui.UserControlManager.isRegisteredContainer(el.dom)
					this.checkIfInline(el);
					if (ct) {
						if (ct.addFn) {
							ct.addFn.createDelegate(ct.scope)(uc);
							if (ct.doLayoutFn)
								ct.doLayoutFn.createDelegate(ct.scope);
						}
						return;
					}
				}
			}
			catch (e) {
				gx.dbg.logEx(e, 'gxui.js', 'afterShowHandler->' + this.getUniqueId());
			}
		}, this);
	},

	checkIfInline: function(el) {
		if (el.id.indexOf("gxHTMLWrp") >= 0 || el.hasClass("gx_usercontrol") || el.hasClass("gxui-uc-container"))
			el.setStyle("display", "inline");
	},

	getUniqueId: function() {
		return "gxui-" + (this.ParentObject ? this.ParentObject.CmpContext || "" + "-" + this.ParentObject.ServerClass || "" : "") + "-" + this.ControlName;
	}
});


gxui.UserControlManager = function() {
	var ucList = [];
	var ctList = [];

	var afterShowEvent;

	var initAfterShow = function() {
		afterShowEvent = new Ext.util.Event();
	};

	var ucShowListener = function(uc) {
		try {
			var ucListItem = this.isRegisteredUC(uc)
			if (ucListItem) {
				ucListItem.shown = true;
			}

			var allShown = true;
			Ext.each(ucList, function(item) {
				return allShown = item.shown && allShown;
			}, this);

			if (allShown && afterShowEvent) {
				afterShowEvent.fire();
				Ext.each(ucList, function(item) {
					// Fire doLayout function in those controls that don't have a parent control.
					var extUC = item.uc.getUnderlyingControl();
					if (extUC && !extUC.ownerCt && extUC.doLayout) {
						extUC.doLayout();
					}
					item.shown = false;
				}, this);
			}
		}
		catch (e) {
			gx.dbg.logEx(e, 'gxui.js', 'ucShowListener');
		}
	};

	return {
		getUCList: function() {
			var l = [];
			Ext.each(ucList, function(item) {
				l.push(item.uc);
			});
			return l;
		},

		getContainersList: function() {
			return ctList;
		},

		register: function(uc) {
			ucList.push({
				uc: uc,
				shown: false
			});

			uc.on("show", ucShowListener, this);

			uc.on("destroy", function(uc) {
				this.unregister(uc);
				this.unregisterContainer(uc);
				if (uc.afterShowHandler)
					afterShowEvent.removeListener(uc.afterShowHandler, uc);
			}, this);
		},

		unregister: function(uc) {
			var toRem = this.isRegisteredUC(uc);
			if (toRem)
				ucList.remove(toRem);
		},

		registerContainer: function(uc, el, addFn, doLayoutFn, scope) {
			ctList.push({
				uc: uc,
				el: el,
				addFn: addFn,
				doLayoutFn: doLayoutFn,
				scope: scope
			});
		},

		unregisterContainer: function(obj) {
			toRem = this.isRegisteredContainer(obj);
			if (toRem)
				ctList.remove(toRem);
		},

		isRegisteredUC: function(uc) {
			var obj = null;

			Ext.each(ucList, function(item) {
				if (uc == item.uc) {
					obj = item;
					return false;
				}
			}, this);

			return obj;
		},

		isRegisteredContainer: function(el) {
			var ct = null;

			if (el.layout) {
				Ext.each(ctList, function(item) {
					if (el == item.scope) {
						ct = item;
						return false;
					}
				}, this);
			}
			else
				if (el.tagName) { // If el argument is a HTMLElement
				Ext.each(ctList, function(item) {
					if (el == item.el) {
						ct = item;
						return false;
					}
				}, this);
			}
			else { // If el argument is a gxui.UserControl
				uc = el;
				Ext.each(ctList, function(item) {
					if (uc == item.uc) {
						ct = item;
						return false;
					}
				}, this);
			}

			return ct;
		},

		
		afterShow: function(fn, scope, options) {
			if (!afterShowEvent)
				initAfterShow();

			scope.afterShowHandler = fn;
			afterShowEvent.addListener(fn, scope, options)
		}
	};
} ();

////////////////////////////////////////////
//// gxui.ext.Portal
////////////////////////////////////////////
gxui.ext.Portal = Ext.extend(Ext.ux.Portal, {
	defaultType: 'gxuiportalcolumn',
	
	initComponent: function(){
		gxui.ext.Portal.superclass.initComponent.apply(this);
		this.addEvents({
			dragout: true
		});
	},
	initEvents: function(){
		gxui.ext.Portal.superclass.initEvents.call(this);
		this.dd = new gxui.ext.Portal.DropZone(this, this.dropConfig);
	}
});
Ext.reg('gxuiportal', gxui.ext.Portal);

////////////////////////////////////////////
//// gxui.ext.Portal.DropZone
////////////////////////////////////////////
gxui.ext.Portal.DropZone = function(portal, cfg){
    gxui.ext.Portal.DropZone.superclass.constructor.call(this, portal, cfg);
};

Ext.extend(gxui.ext.Portal.DropZone, Ext.ux.Portal.DropZone, {
    notifyOut : function(dd, e, data){
        delete this.grid;
        if(!this.lastPos){
            return;
        }
		var c = this.lastPos.c, col = this.lastPos.col, pos = this.lastPos.p;
		
		var outEvent = this.createEvent(dd, e, data, col, c, 
                pos !== false ? pos : c.items.getCount());
				
		this.portal.fireEvent('dragout', outEvent);
    }
});

////////////////////////////////////////////
//// gxui.ext.PortalColumn
////////////////////////////////////////////
gxui.ext.PortalColumn = Ext.extend(Ext.ux.PortalColumn, {
	    defaultType: 'gxuiportlet'
});
Ext.reg('gxuiportalcolumn', gxui.ext.PortalColumn);

////////////////////////////////////////////
//// gxui.ext.Portlet
////////////////////////////////////////////
gxui.ext.Portlet = Ext.extend(Ext.ux.Portlet, {
    collapsible:true,
	resizable:true,
	resizeHandles: 'all',
	autoScroll: true,
	stateEvents: ['collapse', 'expand'],

	initComponent: function(){
		gxui.ext.Portlet.superclass.initComponent.apply(this);
		this.on('beforecollapse', function(){
			this.expandedHeight = this.getBox().height;
		}, this);
		var ownerCtDoLayout = function(){
			gxui.ext.LayoutManager.forceDoLayout(this.ownerCt);
			if (this.ownerCt && this.ownerCt.ownerCt)
				gxui.ext.LayoutManager.forceDoLayout(this.ownerCt.ownerCt);
		};
		this.on('collapse', ownerCtDoLayout, this);
		this.on('expand', ownerCtDoLayout, this);
		this.on('resize', ownerCtDoLayout, this);
	},
    initEvents : function(){
        gxui.ext.Portlet.superclass.initEvents.call(this);
		
        this.el.on("mousedown", this.toFront, this);
        this.manager = gxui.ext.PortletManager;
        this.manager.register(this);
    },
	initDraggable: function(){
        this.dd = new gxui.ext.Portlet.DD(this, this.dropConfig);
	},
	render: function(){
		gxui.ext.Portlet.superclass.render.apply(this, arguments);
		if (this.st) {
			if (this.st.column) {
				if (this.st.elPositioning) 
					this.getEl().setPositioning(this.st.elPositioning);
				
				var col = Ext.getCmp(this.st.column);
				if (col) {
					var xt = col.getXType();
					
					if (xt == "gxuiportalcolumn") {
						this.getEl().dom.parentNode.removeChild(this.getEl().dom);
						if (this.st.columnPos != undefined) 
							col.insert(this.st.columnPos, this);
						else 
							col.add(this);
						col.doLayout();
						//col.ownerCt.doLayout();
					}
					
					if (xt == "panel") {
						if (this.expandedHeight)
							this.setHeight(this.expandedHeight);
						col.add(this);
						//gxui.ext.LayoutManager.forceDoLayout();
						//col.doLayout();
					}
				}
			}
		}
		this.createResizer();
	},
	doFloat : function(width, x, y){
		this.resetPositioning();
		this.getEl().setStyle('position', 'absolute');
		this.setWidth(width);
		
		var points = this.getEl().parent().translatePoints(x, y);

		this.getEl().setLeftTop(points.left, points.top);
	},
	undoFloat : function(){
		this.resetPositioning();
		this.setWidth('auto');
	},
	resetPositioning : function(){
		this.getEl().setPositioning({
			'position' : "static",
			'left' : "auto",
			'top' : "auto",
			'bottom' : "",
			'right' : ""
		});
	},				
	getState : function(){
		return Ext.apply(Ext.apply(gxui.ext.Portlet.superclass.getState.call(this) || {}, this.getBox()), {
			st: {
				column: (this.ownerCt) ? this.ownerCt.id : null,
				columnPos: (this.ownerCt) ? this.ownerCt.items.indexOf(this) : null,
				elPositioning: this.getEl().getPositioning(),
				expandedHeight: this.expandedHeight
			},
			collapsed: this.collapsed,
			resizeHandles: this.resizeHandles
		});
	},
	createResizer : function(resizeHandles){
		this.destroyResizer();
        if(this.resizable && !this.resizer){
			var overrideCreateProxy = (this.ownerCt && this.ownerCt.getXType() == "gxuiportalcolumn");
			 
			var createProxyProtoType = Ext.Element.prototype.createProxy;
			if (overrideCreateProxy) {
				resizeHandles = 's';
				Ext.Element.prototype.createProxy = function(config){
					return Ext.DomHelper.append(this.dom, config, true);
				};
			}
			
			var resConfig = {
				minWidth: this.minWidth || 200,
				minHeight: this.minHeight || 100,
				handles: resizeHandles || this.resizeHandles || "all",
				transparent: true,
				pinned: this.pinned,
				resizeElement: this.resizerAction
			};
			
			if (this.maxWidth)
				resConfig.maxWidth = this.maxWidth;
			if (this.maxHeight)
				resConfig.maxHeight = this.maxHeight;

			this.resizer = new Ext.Resizable(this.el, resConfig);
			this.resizer.window = this;
			this.resizer.on('resize', this.onResizer, this);
			this.resizer.on("beforeresize", this.beforeResize, this);
			
			if (overrideCreateProxy) {
				resizeHandles = 's';
				Ext.Element.prototype.createProxy = createProxyProtoType;
			}
			
        }
	},
	destroyResizer : function(){
		if (this.resizer){
			this.resizer.destroy()
			delete this.resizer;
			
			this.un('beforeresize', this.beforeResize, this);
			this.un('resize', this.onResizer, this);
		}
	},
    onResizer : function(oResizable, iWidth, iHeight, e) {
        this.setHeight(iHeight);
    },
    onCollapse : function(doAnim, animArg) {
        this.el.setHeight('');  
        Ext.ux.Portlet.superclass.onCollapse.call(this, doAnim, animArg);
    },
    toFront : function(){
        this.manager.bringToFront(this)
        return this;
    },
    setZIndex : function(index){
        this.el.setStyle("z-index", ++index);
        index += 5;

        if(this.resizer){
            this.resizer.proxy.setStyle("z-index", ++index);
        }

		this.saveState();
        this.lastZIndex = index;
    },
	resizerAction : Ext.Window.prototype.resizerAction,
    beforeResize : function(){
        this.resizeBox = this.el.getBox();
    },
    handleResize : Ext.Window.prototype.handleResize,
    updateHandles : Ext.Window.prototype.updateHandles,
    onDestroy : function(){
        if(this.manager){
            this.manager.unregister(this);
        }
        gxui.ext.Portlet.superclass.onDestroy.call(this);
    }
});
Ext.reg('gxuiportlet', gxui.ext.Portlet);

////////////////////////////////////////////
//// gxui.ext.Portlet.DD
////////////////////////////////////////////
gxui.ext.Portlet.DD = function(portlet, cfg){
    this.portlet = portlet;
    gxui.ext.Portlet.DD.superclass.constructor.call(this, portlet, cfg);
};

Ext.extend(gxui.ext.Portlet.DD, Ext.Panel.DD, {
	startDrag: function(){
		this.proxy.getProxy().remove();
	},
    onDragOut: function(e){
		this.proxy.getProxy().remove();
	},
    endDrag : function(e){
        this.proxy.hide();
        this.panel.saveState();
    }
});

////////////////////////////////////////////
//// gxui.ext.PortletManager
////////////////////////////////////////////
gxui.ext.PortletManager = function(){
	var list = {};
    var accessList = [];
    var front = null;
	
    var sortPortlets = function(d1, d2){
        return (!d1._lastAccess || d1._lastAccess < d2._lastAccess) ? -1 : 1;
    };
	
    var orderPortlets = function(){
        var a = accessList, len = a.length;
        if(len > 0){
            a.sort(sortPortlets);
            var seed = a[0].manager.zseed;
            for(var i = 0; i < len; i++){
                var portlet = a[i];
                if(portlet && !portlet.hidden){
                    portlet.setZIndex(seed + (i*10));
                }
            }
        }
    };
	
	return {
        zseed : 9000,

        register : function(portlet){
            list[portlet.id] = portlet;
			accessList.push(portlet);
        },

        unregister : function(portlet){
            delete list[portlet.id];
			accessList.remove(portlet);
        },
		
        get : function(pid){
            return typeof pid == "object" ? pid : list[pid];
        },
		
		bringToFront : function(portlet){
            portlet = this.get(portlet);
            if(portlet != front){
                portlet._lastAccess = new Date().getTime();
                orderPortlets();
            }
		}
	};
}();
////////////////////////////////////////////
//// gxui.ext.FloatingDropTarget
////////////////////////////////////////////
gxui.ext.FloatingDropTarget = function(area, cfg){
	this.area = area;
	gxui.ext.FloatingDropTarget.superclass.constructor.call(this, area.bwrap.dom, cfg);
};

Ext.extend(gxui.ext.FloatingDropTarget, Ext.dd.DropTarget, {
	notifyDrop : function(s, e, d){
        var lel = s.panel.getEl();
        var del = s.proxy.getEl();
		if (del) {
			if (s.proxy.getProxy()) 
				s.proxy.getProxy().remove();
			s.panel.getEl().dom.parentNode.removeChild(s.panel.getEl().dom);
			this.area.add(s.panel);
			this.area.doLayout();
			s.panel.doFloat(del.getWidth(), del.getX(), del.getY());
			s.panel.createResizer();
			return true;
		}
		return false;
	},
	notifyOver : function(s, e, d){
		s.proxy.getProxy().remove();
	}
});

////////////////////////////////////////////
//// gxui.ext.LayoutManager
////////////////////////////////////////////
gxui.ext.LayoutManager = function(){
	var list = [];
	
	dropHandler = function(e){
		e.panel.createResizer("s");
		this.forceDoLayout();
		e.panel.ownerCt.items.each(function(p){
			p.saveState();
		});
	};
	
	beforeDropHandler = function(e){
		e.panel.undoFloat();
	};

	return {
		register: function(layout){
			list.push(layout);
			var xt = layout.getXType();
			if (xt == "gxuiportal"){
				layout.on('drop', dropHandler, this);
				layout.on('dragout', function(){
					this.forceDoLayout();
				}, this);
				layout.on('beforedrop', beforeDropHandler, this);
				return true;
			}
			
			if (xt == "panel"){
				layout.on('add', function(){
					this.forceDoLayout();
				}, this);
				return true;
			}
			
			return false;
		},
		
		unregister: function(layout){
			list.remove(layout);
		},
		
		forceDoLayout: function(l){
            setTimeout(function(){
				if (l) 
					l.doLayout();
				else {
					for (var i = 0; i < list.length; i++) {
						var layout = list[i];
						if (layout) {
							layout.doLayout();
						}
					}
				}
            }, 100);
		}
	};
}();
gxui.SimpleCache = function(options){
    Ext.apply(this, options);
    
    
	this.expireTime = -1;
	this.elements = {};
};

gxui.SimpleCache.prototype = {
    //private
    
	elementHasExpired: function(el){
		return (this.expireTime < 0) ? false : el.timeStamp + this.expireTime < (new Date()).getTime();
	},
	
    
	add: function(key, obj){
		this.elements[key] = {
			obj: obj,
			timeStamp: (new Date()).getTime()
		};
	},

    
	get: function(key){
		var el = this.elements[key];
		if (el && !this.elementHasExpired(el)){
			return el.obj;
		}
		return null;
	},
	
    
	exists: function(key){
		return this.elements[key] ? true : false;
	},
	
    
	existsObject: function(obj){
		for (key in this.elements){
			var el = this.get(key)
			if (el === obj){
				return true;
			}
		}
		return false;
	},
	
    
	remove: function(key){
		this.elements[key] = undefined;
	},
	
    
	restart: function(){
		this.elements = {};
	}
};

gxui.Properties.Object = function(objId, options){
	this.objId = objId;
	
	Ext.apply(this, options);
    
	this.root = this.root || this.repository.root ;
	this.fields = this.fields || this.repository.fields;
	this.url = this. url || this.repository.url;
    
    this.initialize();
};

gxui.Properties.Object.prototype = {
	initialize: function() {
		this.store = new Ext.data.JsonStore({
			baseParams: {
				id: this.objId
			},
			root: this.root,
			fields: this.fields,
			url: this.url
		});
	},

	getProperties: function(options) {
		this.store.load({
			params: options.params,
			callback: function(r, o, success) {
				if (success) {
					this.jsonData = this.store.reader.jsonData;
					this.Id = this.jsonData.Id;
					this.ObjectClass = this.jsonData.ObjectClass;
					this.Name = this.jsonData.Name;
				}
				options.callback.call(options.scope, this, this.store, r, success);
			},
			scope: this
		});
	}
};
gxui.Properties.ObjectsRepository = function(){
	var objects;
	
	return {
		
		
		root: "Properties",
		
		fields: ["Name", "Value", "IsDefault", "IsReadonly"],
		
		
		init: function(options){
			Ext.apply(this, options);
			
			objects = new gxui.SimpleCache();
		},
		
		
		getProperties: function(objId, category, callback, scope){
			var obj = objects.get(objId);
			if (!obj){
				obj = new gxui.Properties.Object(objId, {
					repository: this
				});
				
				objects.add(objId, obj);
			}
							
			obj.getProperties({
				callback: callback,
				scope: scope,
				params: category ? {category: category} : undefined
			});
		}
	};
}();
gxui.Properties.ObjectDefsRepository = function(){
	var definitions;
	var store;
	
	return {
		
		
		root: "Properties",
		
		fields: ["Name", "DisplayName", "Category", "Type", "Editor"],
		
		init: function(options){
			Ext.apply(this, options);
			
			definitions = new gxui.SimpleCache();
			
			store = new Ext.data.JsonStore({
				root: this.root,
				fields: this.fields,
				url: this.url
			});
		},
		
		
		getDefinition: function(objClass, callback, scope){
			var def = definitions.get(objClass);
			if (def){
				callback.defer(1, scope, [def, true]);
			}
			else{
				store.load({
					params: {
						objClass: objClass
					},
					callback: function(r, options, success){
						if (success){
							def = store.reader.jsonData[this.root];
							definitions.add(objClass, def);
						}
						callback.call(scope, def, success);
					}
				});
			}
		}
	};
}();
gxui.Layout = Ext.extend(gxui.UserControl, {
	// Private members
	m_layout: null,

	initialize: function() {
		gxui.Layout.superclass.initialize.call(this);

		this.NorthTitleBar;
		this.NorthTitle;
		this.NorthHeight;
		this.NorthMinHeight;
		this.NorthMaxHeight;
		this.NorthMargins;
		this.NorthBorder;
		this.NorthDragDropMode;
		this.NorthCollapsible;
		this.NorthCollapseMode;
		this.NorthCollapsed;
		this.NorthCollapsedMargins;
		this.NorthFloatable;
		this.NorthAutoHide;
		this.NorthAnimate;
		this.NorthDuration;
		this.NorthHidden;
		this.NorthAutoScroll;
		this.SouthTitleBar;
		this.SouthTitle;
		this.SouthHeight;
		this.SouthMinHeight;
		this.SouthMaxHeight;
		this.SouthMargins;
		this.SouthBorder;
		this.SouthDragDropMode
		this.SouthCollapsible;
		this.SouthCollapseMode;
		this.SouthCollapsed;
		this.SouthCollapsedMargins;
		this.SouthFloatable;
		this.SouthAutoHide;
		this.SouthAnimate;
		this.SouthDuration;
		this.SouthHidden;
		this.SouthAutoScroll;
		this.WestTitleBar;
		this.WestTitle;
		this.WestWidth;
		this.WestMinWidth;
		this.WestMaxWidth;
		this.WestMargins;
		this.WestBorder;
		this.WestDragDropMode
		this.WestCollapsible;
		this.WestCollapseMode;
		this.WestCollapsed;
		this.WestCollapsedMargins;
		this.WestFloatable;
		this.WestAutoHide;
		this.WestAnimate;
		this.WestDuration;
		this.WestHidden;
		this.WestAutoScroll;
		this.CenterTitleBar;
		this.CenterTitle;
		this.CenterWidth;
		this.CenterMinWidth;
		this.CenterMaxWidth;
		this.CenterMargins;
		this.CenterBorder;
		this.CenterDragDropMode;
		this.CenterCollapsedMargins;
		this.CenterCollapsible;
		this.CenterCollapseMode;
		this.CenterCollapsed;
		this.CenterCollapsedMargins;
		this.CenterFloatable;
		this.CenterAutoHide;
		this.CenterAnimate;
		this.CenterDuration;
		this.CenterHidden;
		this.CenterAutoScroll;
		this.EastTitleBar;
		this.EastTitle;
		this.EastWidth;
		this.EastMinWidth;
		this.EastMaxWidth;
		this.EastMargins;
		this.EastBorder;
		this.EastDragDropMode
		this.EastCollapsible;
		this.EastCollapseMode;
		this.EastCollapsed;
		this.EastCollapsedMargins;
		this.EastFloatable;
		this.EastAutoHide;
		this.EastAnimate;
		this.EastDuration;
		this.EastHidden;
		this.EastAutoScroll;
		this.Width;
		this.Height;
		this.Nested;
		this.Stateful;
		this.StateId;
	},

	getMargins: function(regionKey, str) {
		var margins = (this[regionKey + "Margins"]) ? this[regionKey + "Margins"].split(",") : ["0", "0", "0", "0"];
		return { top: parseInt(margins[0]), left: parseInt(margins[3]), right: parseInt(margins[1]), bottom: parseInt(margins[2]) };
	},

	onRender: function() {
		var regions = new Array();

		this.addRegion(regions, "North");
		this.addRegion(regions, "South");
		this.addRegion(regions, "West");
		this.addRegion(regions, "East");
		this.addRegion(regions, "Center");

		if (gxui.CBoolean(this.Nested)) {
			this.m_layout = new Ext.Panel({
				id: this.getUniqueId(),
				renderTo: this.getContainerControl(),
				border: false,
				items: regions,
				layout: 'border',
				width: this.Width != 0 ? this.Width : 'auto',
				height: this.Height != 0 ? this.Height : 'auto',
				stateful: gxui.CBoolean(this.Stateful),
				stateid: (this.StateId != "") ? this.StateId : undefined
			});
		}
		else {
			this.m_layout = new Ext.ux.NestedViewport({
				id: this.getUniqueId(),
				items: regions,
				layout: 'border',
				renderTo: 'MAINFORM',
				stateful: gxui.CBoolean(this.Stateful),
				stateid: (this.StateId != "") ? this.StateId : undefined
			});
		}

		// Register this User Control as a container. Each region of the layout is registered
		// as an individual container.
		this.registerAsContainer();

		if (gxui.CBoolean(this.Nested)) {
			// Add to parent UC container
			this.addToParentContainer(this.m_layout);
		}

		this.displayRegions();
	},

	getUnderlyingControl: function() {
		return this.m_layout;
	},

	getProperty: function(regionKey, propName) {
		var prop = this[regionKey + propName];
		if (prop == "true" || prop == "false")
			return gxui.CBoolean(prop);
		else
			if (propName.indexOf("Margins") >= 0) {
			return this.getMargins(regionKey, prop);
		}
		else if (propName == "CollapseMode") {
			return prop == "mini" ? "mini" : undefined;
		}
		else if (propName == "Layout") {
			return prop == "default" ? undefined : prop;
		}
		else
			return prop;
	},

	setRegionProperty: function(regionKey, propName, value) {
		if (regionKey) {
			var r = regionKey.toLowerCase();
			r = r.charAt(0).toUpperCase() + r.substr(1);
			if (this[r + propName]) {
				this[r + propName] = value;
			}
		}
	},

	createConfig: function(regionKey) {
		var lstnrs = {
			'render': {
				fn: function(r) {
					gxui.ext.LayoutManager.register(r);
					if (this.getProperty(regionKey, "DragDropMode") == "floating") {
						r.dt = new gxui.ext.FloatingDropTarget(r);
						if (r.region == 'north')
							r.getEl().setStyle({ "z-index": 1 });
					}
				},
				scope: this
			}
		};

		return {
			id: this.getUniqueId() + "-" + regionKey,
			region: regionKey.toLowerCase(),
			contentEl: this.getChildContainer(regionKey),
			hidden: this.getProperty(regionKey, "Hidden"),
			split: this.getProperty(regionKey, "Split"),
			autoScroll: (this.getProperty(regionKey, "DragDropMode") == "portal" || this.getProperty(regionKey, "Layout") != "fit") ? this.getProperty(regionKey, "AutoScroll") : false,
			header: this.getProperty(regionKey, "TitleBar"),
			title: this.getProperty(regionKey, "Title"),
			width: this.getProperty(regionKey, "Width"),
			height: this.getProperty(regionKey, "Height"),
			minWidth: this.getProperty(regionKey, "MinWidth") || 0,
			minHeight: this.getProperty(regionKey, "MinHeight") || 0,
			maxWidth: this.getProperty(regionKey, "MaxWidth") || 0,
			maxHeight: this.getProperty(regionKey, "MaxHeight") || 0,
			margins: this.getProperty(regionKey, "Margins"),
			collapsible: this.getProperty(regionKey, "Collapsible"),
			collapseMode: this.getProperty(regionKey, "CollapseMode"),
			collapsed: this.getProperty(regionKey, "Collapsed"),
			cmargins: this.getProperty(regionKey, "CollapsedMargins"),
			cls: "x-region-" + regionKey.toLowerCase(),
			floatable: this.getProperty(regionKey, "Floatable"),
			autoHide: this.getProperty(regionKey, "AutoHide"),
			animate: this.getProperty(regionKey, "Animate"),
			animFloat: this.getProperty(regionKey, "Animate"),
			duration: this.getProperty(regionKey, "Duration") / 1000,
			xtype: (this.getProperty(regionKey, "DragDropMode") == "portal") ? "gxuiportal" : undefined,
			items: (this.getProperty(regionKey, "DragDropMode") == "portal") ? [{ columnWidth: 1}] : undefined,
			layout: (this.getProperty(regionKey, "DragDropMode") == "portal") ? "column" : this.getProperty(regionKey, "Layout"),
			border: this.getProperty(regionKey, "Border"),
			//stateful: gxui.CBoolean(this.Stateful),
			//stateId: (this.StateId != "") ? this.StateId + "-" + regionKey : undefined,			
			listeners: lstnrs
		};
	},

	addRegion: function(items, regionKey) {
		items.push(this.createConfig(regionKey));
	},

	displayRegions: function() {
		Ext.each(this.m_layout.items.items,
				function(region, index, allRegions) {
					Ext.get(region.contentEl).setDisplayed(true);
				},
				this);
	},

	registerAsContainer: function() {
		Ext.each(this.m_layout.items.items,
				function(region, index, allRegions) {
					if (region.getXType() == 'gxuiportal')
						Ext.each(region.items.items,
								function(col, colIdx, allCols) {
									this.registerCt(region.contentEl, col.add, col.doLayout, col);
								},
								this);
					else
						this.registerCt(region.contentEl, region.add, region.doLayout, region);
				},
				this);
	},

	getRegion: function(regionKey) {
		if (regionKey) {
			if (this.m_layout.layout[regionKey.toLowerCase()]) {
				return this.m_layout.layout[regionKey.toLowerCase()].panel;
			}
		}
		return undefined;
	},

	// Methods
	collapseRegion: function(regionKey, animate) {
		var region = this.getRegion(regionKey);

		if (region) {
			region.collapse(animate);
			this.setRegionProperty(regionKey, "Collapsed", "true");
		}
	},

	expandRegion: function(regionKey, animate) {
		var region = this.getRegion(regionKey);

		if (region) {
			region.expand(animate);
			this.setRegionProperty(regionKey, "Collapsed", "false");
		}
	}
});

gxui.TabPanel = Ext.extend(gxui.UserControl, {
	//Private members
	m_tabPanel: null,
	m_designTabs: [],
	m_activeTab: 0,

	initialize: function() {
		gxui.TabPanel.superclass.initialize.call(this);

		this.Width;
		this.Height;
		this.AutoWidth;
		this.AutoHeight;
		this.Cls;
		this.TabCls;
		this.Layout;
		this.MinTabWidth;
		this.EnableTabScroll;
		this.RunTimeTabs;
		this.DesignTimeTabs;
		this.RunTimeWebComponent;
		this.AddToParentGxUIControl;
		this.ClosedTabId;
		this.HandleUniqueId = true;
	},

	// Databinding for property Data
	SetRunTimeTabs: function(data) {
		this.RunTimeTabs = data;
	},

	// Databinding for property Data
	GetRunTimeTabs: function() {
		return this.RunTimeTabs;
	},

	onRender: function() {
		if (this.RunTimeTabs)
			Ext.each(this.RunTimeTabs, function(tab, index, allTabs) {
				tab.InternalName = '';
			}, this);

		this.m_designTabs = Ext.util.JSON.decode(this.DesignTimeTabs);

		var tabCount = 0;
		if (this.m_designTabs != undefined && this.m_designTabs.length != undefined)
			tabCount += this.m_designTabs.length;
		if (this.RunTimeTabs != undefined && this.RunTimeTabs.length != undefined)
			tabCount += this.RunTimeTabs.length;

		if (tabCount > 0) {
			this.m_tabPanel = new Ext.TabPanel(this.getConfig());

			this.m_tabPanel.setActiveTab(this.m_activeTab);
			this.m_tabPanel.on('tabchange', this.handlers.tabChanged, this);

			// Register this User Control as a container. Each tab of the tabpanel control is registered
			// as an individual container.
			this.registerAsContainer();

			// Add to parent UC container
			if (gxui.CBoolean(this.AddToParentGxUIControl)) {
				this.addToParentContainer(this.m_tabPanel);
			}

			this.displayTabPanels();
		}
		window.m_tab = this;
	},

	onRefresh: function() {
		var setActiveTab = false;
		Ext.each(this.getTabPanelsList(), function(tab, index, allTabs) {
			this.m_tabPanel.add(tab);
			this.registerAsContainer(tab);
			setActiveTab = true;
		}, this);

		if (setActiveTab) {
			this.m_tabPanel.setActiveTab(this.m_activeTab);
		}
	},

	onDestroy: function() {
		this.m_tabPanel.items.each(function(tab) {
			this.unregisterCt(tab);
		}, this);

		gxui.TabPanel.superclass.onDestroy.call(this);
	},

	getUnderlyingControl: function() {
		return this.m_tabPanel;
	},

	getConfig: function() {
		var config = {
			id: this.getUniqueId(),
			renderTo: this.getContainerControl(),
			tabPosition: this.TabPosition || "top",
			deferredRender: false,
			//autoWidth: gxui.CBoolean(this.AutoWidth),
			//autoHeight: gxui.CBoolean(this.AutoHeight),
			enableTabScroll: (this.TabPosition == "top") ? gxui.CBoolean(this.EnableTabScroll) : false,
			//autoScroll: true,
			minTabWidth: this.MinTabWidth,
			items: this.getTabPanelsList(),
			listeners: {
				activate: this.handlers.tabItemActivated,
				deactivate: this.handlers.tabItemDeactivated,
				remove: this.handlers.tabItemClosed,
				scope: this
			}
		};

		if (!gxui.CBoolean(this.AutoWidth))
			config.width = this.Width;
		if (!gxui.CBoolean(this.AutoHeight))
			config.height = this.Height;
		if (this.Cls)
			config.cls = this.Cls;

		return config;
	},

	getTabPanelsList: function() {
		var rawTabs = (this.RunTimeTabs && this.RunTimeTabs.length) ? this.m_designTabs.concat(this.RunTimeTabs) : this.m_designTabs;
		var tabPanels = [];
		Ext.each(rawTabs, function(tab, index, allTabs) {
			var panel;
			if (index >= this.m_designTabs.length)
				tab.isRuntimeTab = true;

			if (!tab.rendered) {
				var webcomEl;
				if (!tab.isRuntimeTab) {
					var titleEl = Ext.get(this.getChildContainer("Title" + tab.id));
					if (titleEl) {
						tab.Name = titleEl.dom.innerHTML;
						titleEl.dom.parentNode.removeChild(titleEl.dom);
					}
				}
				else
					webcomEl = this.getWebComEl(index);

				if (tab.isRuntimeTab) {
					if (!tab.HTML) {
						tab.InternalName = (webcomEl) ? webcomEl.id : null;
					}
				}
				else {
					tab.InternalName = tab.id;
				}

				if (tab.InternalName) {
					var layout = tab.layout || this.Layout;
					var config = {
						id: this.getTabUniqueId(tab.InternalName),
						layout: layout == "default" ? undefined : layout,
						contentEl: !tab.HTML ? (tab.isRuntimeTab ? webcomEl : this.getChildContainer(tab.id)) : undefined,
						html: tab.HTML,
						title: tab.Name,
						closable: (tab.isRuntimeTab) ? true : gxui.CBoolean(tab.closable),
						autoScroll: tab.autoScroll || (layout == 'fit' ? false : true),
						listeners: {
							activate: this.handlers.tabItemActivated,
							deactivate: this.handlers.tabItemDeactivated,
							scope: this
						}
					};

					if (this.TabCls)
						config.cls = this.TabCls;

					panel = new Ext.Panel(config);
					tab.rendered = true;
					tabPanels.push(panel);
				}
				else
					return;
			}
			else {
				panel = this.m_tabPanel.items.items[index];
				if (tab.isRuntimeTab && !tab.HTML) {
					var webcomEl = this.getWebComEl(index);
					tab.InternalName = webcomEl.id;
					panel.contentEl = webcomEl.dom; //Ext.get(tab.InternalName).dom;
					var panelDom = panel.body.dom;
					if (panelDom.firstChild)
						panelDom.removeChild(panelDom.firstChild);
					panelDom.appendChild(panel.contentEl);
				}
			}

			if (gxui.CBoolean(tab.selected) || gxui.CBoolean(tab.Selected))
				this.m_activeTab = panel;

		}, this);

		return tabPanels;
	},

	getWebComEl: function(index) {
		var Prefix = this.ParentObject.getComponentPrefix(this.RunTimeWebComponent);
		webcomEl = Ext.get(this.ParentObject.CmpContext + 'gxHTMLWrp' + Prefix + String(index - this.m_designTabs.length + 1 + 10000).substr(1));
		return webcomEl;
	},

	displayTabPanels: function() {
		Ext.each(this.m_designTabs, function(tab, index, allTabs) {
			Ext.get(this.getChildContainer(tab.id)).setDisplayed(true)
		}, this);
	},

	registerAsContainer: function(t) {
		if (t) {
			this.registerCt(Ext.get(t.contentEl || t.body).dom, t.add, t.doLayout, t);
		}
		else {
			Ext.each(this.m_tabPanel.items.items,
				function(tab, index, allTabs) {
					this.registerCt(Ext.get(tab.contentEl || tab.body).dom, tab.add, tab.doLayout, tab);
				},
			this);
		}
	},

	handlers: {
		tabChanged: function(tab, tabItem) {
			if (this.TabChanged) {
				this.TabChanged();
			}
		},

		tabItemActivated: function(tabItem) {
			this.ActiveTabId = tabItem.id;
			if (this.RunTimeTabs)
				Ext.each(this.RunTimeTabs, function(item, index, allItems) {
					if (this.getTabUniqueId(item.InternalName) == tabItem.id) {
						item.Selected = true;
						return false;
					}
				}, this);
		},

		tabItemDeactivated: function(tabItem) {
			if (this.RunTimeTabs)
				Ext.each(this.RunTimeTabs, function(item, index, allItems) {
					if (this.getTabUniqueId(item.InternalName) == tabItem.id) {
						item.Selected = false;
						return false;
					}
				}, this);
		},

		tabItemClosed: function(tabpanel, tabItem) {
			if (this.RunTimeTabs) {
				var rtt = new Array();
				Ext.each(this.RunTimeTabs, function(tab, index, allTabs) {
					if (this.getTabUniqueId(tab.InternalName) != tabItem.id) {
						rtt.push(tab);
					}
					else {
						if (!tab.HTML) {
							this.deleteWebComponent(tabItem.contentEl.id);
						}
					}
				}, this);
				this.RunTimeTabs = rtt;
			}
			if (this.TabClosed) {
				this.ClosedTabId = tabItem.id;
				this.TabClosed();
			}
		}
	},

	getTabUniqueId: function(tabId) {
		if (gxui.CBoolean(this.HandleUniqueId))
			return this.getUniqueId() + "_tab_" + tabId;
		else
			return tabId;
	},

	// Methods
	OpenTab: function(tabId, title, tabHTMLContent) {
		if (this.IsTabOpen(tabId)) {
			this.m_activeTab = this.getTabUniqueId(tabId);
		}
		else {
			this.RunTimeTabs.push({
				Name: title,
				InternalName: tabId,
				HTML: tabHTMLContent,
				Selected: true
			});

			Ext.each(this.getTabPanelsList(), function(tab, index, allTabs) {
				this.m_tabPanel.add(tab);
				this.m_tabPanel.doLayout();
				this.registerAsContainer(tab);
			}, this);
		}

		this.m_tabPanel.setActiveTab(this.m_activeTab);
	},

	SelectTab: function(tabId) {
		this.m_activeTab = this.getTabUniqueId(tabId);
		this.m_tabPanel.setActiveTab(this.m_activeTab);
	},

	IsTabOpen: function(tabId) {
		var tab = this.m_tabPanel.findById(this.getTabUniqueId(tabId));
		return (tab) ? true : false;
	}
});
/// <reference path="..\VStudio\vswd-ext_2.2.js" />
gxui.Toolbar = Ext.extend(gxui.UserControl, {
	m_toolbar: null,
	initialize: function() {
		gxui.Toolbar.superclass.initialize.call(this);

		this.Width;
		this.Height;
		this.Data;
		this.ButtonPressedId = "";
		this.EditFieldValue = "";

		this.addEvents({
			
			"beforebuttonpressed": true,
			
			"buttonpressed": true,
			
			"editfieldkeypress": true,
			
			"editfieldblur": true
		});
	},

	SetData: function(data) {
		this.Data = data;
	},

	GetData: function(data) {
		return this.Data;
	},

	GetToolbar: function(add) {
		return this.m_toolbar;
	},

	onRender: function() {
		this.CreateToolbar().render(this.getContainerControl());
	},

	onRefresh: function() {
		this.refreshButtons(this.Data.Buttons, this.m_toolbar.items);
	},

	getUnderlyingControl: function() {
		return this.m_toolbar;
	},

	CreateToolbar: function(options) {
		if (options) {
			if (options.id) {
				this.getUniqueId = function() {
					return options.id;
				};
			}

			if (options.data) {
				this.SetData(options.data);
			}

			if (options.container) {
				options.container.ButtonActionHandler = this.ButtonActionHandler;
				options.container.EditActionHandler = this.EditActionHandler;

				this.ButtonActionHandler = this.ButtonActionHandler.createDelegate(options.container);
				this.EditActionHandler = this.EditActionHandler.createDelegate(options.container);
			}

			if (options.on) {
				this.on(options.on);
			}
		}

		this.m_toolbar = new Ext.Toolbar({
			id: this.getUniqueId(),
			stateful: false,
			buttons: this.CreateButtons()
		});

		return this.m_toolbar;
	},

	CreateButtons: function() {
		var toolbarItems = new Array();
		if (this.Data && this.Data.Buttons) {
			Ext.each(this.Data.Buttons, function(item, index, allItems) {
				if (!item.Type) {
					item.Type = gxui.Toolbar.ItemType.Button;
				}
				toolbarItems.push(this.GetConfig(item));
				if (this.SeparateAll && allItems[index + 1])
					toolbarItems.push('-');
			}, this);
		}
		return toolbarItems;
	},

	ButtonClickHandler: function(btn, e) {
		if (this.fireEvent("beforebuttonpressed", this, btn, e) !== false) {
			if (btn.gxConfirmation) {
				var processResult = function(option, text) {
					if (option == 'ok')
						this.ButtonActionHandler(btn, e);
				};

				// Put focus on Cancel button by default.
				Ext.Msg.getDialog().defaultButton = 3;

				var msgBox = Ext.Msg.show({
					title: btn.gxConfirmation.Title,
					msg: btn.gxConfirmation.Message,
					buttons: {
						ok: btn.gxConfirmation.OKButtonText,
						cancel: btn.gxConfirmation.CancelButtonText
					},
					fn: processResult,
					scope: this,
					animEl: btn.getEl(),
					icon: Ext.MessageBox.QUESTION
				});

				// Restore Ext.MessageBox defaultButton value to avoid affecting other places where it might be used
				setTimeout(function() {
					Ext.Msg.getDialog().defaultButton = 0;
				}, 500);
			}
			else {
				this.ButtonActionHandler(btn, e);
			}
			this.fireEvent("buttonpressed", this, btn, e);
		}
	},

	ButtonActionHandler: function(btn, e) {
		if (this.ButtonPressed) {
			this.ButtonPressedId = btn.gxid;
 
			if (this.ToolbarData && this.ToolbarData.Buttons){
				for (i = 0; i < this.ToolbarData.Buttons.length; i++) { 
					button = this.ToolbarData.Buttons[i];
					if (button.Type == gxui.Toolbar.ItemType.Edit) {
						try {
							var renderedBtn = this.m_toolbar.items.items[i];
							button.Text = renderedBtn.el.dom.value;
						}
						catch(err) {}
					}
				}
			}
			
			this.ButtonPressed(btn);
		}
	},	

	EditActionHandler: function(field) {
		this.EditFieldValue = field.getValue();
		this.ButtonActionHandler(field);
	},

	GetConfig: function(button) {

		var getBtnCls = function(btn) {
			if (!btn.Cls) {
				if (btn.Icon) {
					return (btn.Text) ? "x-btn-text-icon" : "x-btn-icon";
				}
				else {
					return "x-btn-text";
				}
			}
			return btn.Cls;
		};

		var config;

		if (button.id && button.id.indexOf("ext") == 0)
			return button;

		if (!button.Type || button.Type == gxui.Toolbar.ItemType.Button) {
			config = {
				id: this.getUniqueButtonId(button.Id),
				gxid: button.Id,
				gxConfirmation: gxui.CBoolean(button.AskConfirmation) ? button.Confirmation : false,
				text: button.Text,
				tooltip: button.Tooltip,
				icon: button.Icon,
				iconCls: button.IconCls,
				cls: getBtnCls(button),
				enableToggle: gxui.CBoolean(button.EnableToggle),
				pressed: gxui.CBoolean(button.Pressed),
				disabled: gxui.CBoolean(button.Disabled),
				hidden: gxui.CBoolean(button.Hidden),
				handler: this.ButtonClickHandler,
				isDropTarget: gxui.CBoolean(button.IsDropTarget),
				scope: this,
				RefreshData: gxui.CBoolean(button.RefreshData)
			};
		}
		else {
			if (button.Type == gxui.Toolbar.ItemType.Text) {
				config = button.Text;
			}
			else {
				if (button.Type == gxui.Toolbar.ItemType.Edit) {
					config = new Ext.form.TextField({
						id: this.getUniqueButtonId(button.Id),
						cls: button.Cls,
						width: 180,
						disabled: gxui.CBoolean(button.Disabled),
						hidden: gxui.CBoolean(button.Hidden),
						enableKeyEvents: true
					});
					if (button.Text != '')
						config.emptyText = button.Text;

					config.on({
						"keypress": {
							fn: function(field, e) {
								this.fireEvent("editfieldkeypress", this, field, e);
								if (e.getKey() == Ext.EventObject.ENTER) {
									e.stopEvent();
									this.EditActionHandler(field);
								}
							},
							scope: this
						},
						"blur": {
							fn: function(field) {
								this.fireEvent("editfieldblur", this, field);
								this.EditActionHandler(field);
							},
							scope: this
						}
					});
					config.gxid = button.Id;
				}
				else {
					if (button.Type == gxui.Toolbar.ItemType.Fill) {
						config = new Ext.Toolbar.Fill();
					}
					else {
						if (button.Type == gxui.Toolbar.ItemType.Separator) {
							config = "-";
						}
						else {
							if (button.Type == gxui.Toolbar.ItemType.Menu || button.Type == gxui.Toolbar.ItemType.SplitButton) {
								var menuItems = new Array();

								Ext.each(button.Items, function(item, index, allItems) {
									menuItems.push(this.GetConfig(item));
								}, this);

								config = {
									text: button.Text,
									tooltip: button.Tooltip,
									disabled: gxui.CBoolean(button.Disabled),
									hidden: gxui.CBoolean(button.Hidden),
									tooltip: button.Tooltip,
									icon: button.Icon,
									iconCls: button.IconCls,
									menu: menuItems,
									cls: getBtnCls(button),
									disabled: gxui.CBoolean(button.Disabled)
								};

								if (button.Type == gxui.Toolbar.ItemType.SplitButton) {
									config.gxid = button.Id;
									config.gxConfirmation = gxui.CBoolean(button.AskConfirmation) ? button.Confirmation : false;
									config.xtype = 'tbsplit';
									config.enableToggle = gxui.CBoolean(button.EnableToggle);
									config.pressed = gxui.CBoolean(button.Pressed);
									if (gxui.CBoolean(button.EnableToggle)) {
										config.toggleHandler = this.ButtonClickHandler;
									}
									else {
										config.handler = this.ButtonClickHandler;
									}
									config.scope = this;
								}
							}
							else {
								if (button.Type == "Search") {
									config = new Ext.app.SearchField({
										store: button.Store,
										width: button.Width,
										selectOnFocus: true,
										enableKeyEvents: gxui.CBoolean(button.AutoRefresh),
										listeners: {
											'keydown': {
												fn: function(field, e) {
													if (e.getKey() != e.TAB) {
														this.onTrigger2Click();
													}
												},
												buffer: button.AutoRefreshTimeout || 350
											}
										}
									});
									config.on('resize', function(field) {
										field.getEl().setWidth(button.Width - 17);
										field.getEl().parent().setWidth(button.Width);
									});
									button.Store = 'undefined';
								}
							}
						}
					}
				}
			}
		}
		return config;
	},

	defineBtnsDropTarget: function() {
		this.m_toolbar.items.each(function(item, pos) {
			if (item.type == "button" && item.isDropTarget) {
				var dt = new Ext.dd.DropTarget(item.getEl(), { ddGroup: 'GridDD' });
				dt._btn = item;
				dt._scope = this;
				dt.notifyOver = function(source, e, data) {
					if (data.grid) {
						return 'x-dd-drop-ok';
					}
					return 'x-dd-drop-nodrop';
				};
				dt.notifyDrop = function(source, e, data) {
					if (data.grid) {
						this._scope.ButtonActionHandler(this._btn);
						return true;
					}
					return false;
				};
				dt.notifyEnter = function(source, e, data) {
					if (data.grid) {
						return 'x-dd-drop-ok';
					}
					return 'x-dd-drop-nodrop';
				};
			}
		},
		this);
	},

	refreshButtons: function(buttons, renderedButtons) {
		var i = 0;
		var ItemType = gxui.Toolbar.ItemType;
		renderedButtons.each(function(renderedBtn) {
			var button = buttons[i];
			if (button) {
				if (button.Type == ItemType.Button || button.Type == ItemType.Edit || button.Type == ItemType.Menu || button.Type == ItemType.SplitButton) {
					if (!gxui.CBoolean(button.Disabled) && renderedBtn.disabled) {
						renderedBtn.enable();
					}
					else {
						if (gxui.CBoolean(button.Disabled) && !renderedBtn.disabled) {
							renderedBtn.disable();
						}
					}
					if (gxui.CBoolean(button.Hidden) && !renderedBtn.hidden) {
						renderedBtn.hide();
					}
					else {
						if (!gxui.CBoolean(button.Hidden) && renderedBtn.hidden) {
							renderedBtn.show();
						}
					}
				}
				if ((button.Type == ItemType.Menu || button.type == ItemType.SplitButton) && button.Items) {
					this.refreshButtons(button.Items, renderedBtn.menu.items);
				}
			}
			i += 1;
		}, this)
	},

	getUniqueButtonId: function(btnId) {
		return this.getUniqueId() + "_btn_" + btnId;
	},

	findItem: function(id, items) {
		var ItemType = gxui.Toolbar.ItemType;
		var searchedItem;
		Ext.each(items, function(item) {
			if (item.Id == id) {
				searchedItem = item;
			}
			else {
				if ((item.Type == ItemType.Menu || item.type == ItemType.SplitButton) && item.Items) {
					searchedItem = this.findItem(id, item.Items);
				}
			}

			if (searchedItem) {
				return false;
			}
		}, this);
		return searchedItem;
	},

	changeItemPropertyValue: function(itemId, propertyId, propertyValue) {
		var item = this.findItem(itemId, this.Data.Buttons);
		if (item) {
			item[propertyId] = propertyValue;
		}
		return item;
	},

	// Methods
	ChangeToolbar: function(toolbarData, id, container) {
		var ownerCt = this.m_toolbar.ownerCt;
		this.m_toolbar.destroy();

		this.CreateToolbar({
			data: toolbarData,
			id: id,
			container: container
		});

		var ct;
		if (ownerCt) {
			ownerCt.topToolbar = this.m_toolbar;
			this.m_toolbar.ownerCt = ownerCt;
			ct = ownerCt.tbar;
		}
		else {
			ct = this.getContainerControl();
		}
		this.m_toolbar.render(ct);

		return this.m_toolbar;
	},

	DisableItem: function(itemId) {
		this.changeItemPropertyValue(itemId, "Disabled", true);
		this.refreshButtons(this.Data.Buttons, this.m_toolbar.items);
	},

	EnableItem: function(itemId) {
		this.changeItemPropertyValue(itemId, "Disabled", false);
		this.refreshButtons(this.Data.Buttons, this.m_toolbar.items);
	},

	HideItem: function(itemId) {
		this.changeItemPropertyValue(itemId, "Hidden", true);
		this.refreshButtons(this.Data.Buttons, this.m_toolbar.items);
	},

	ShowItem: function(itemId) {
		this.changeItemPropertyValue(itemId, "Hidden", false);
		this.refreshButtons(this.Data.Buttons, this.m_toolbar.items);
	}
});

// Supported item types
gxui.Toolbar.ItemType = {
	Button: "Button",
	Text: "Text",
	Edit: "Edit",
	Fill: "Fill",
	Separator: "Separator",
	Menu: "Menu",
	SplitButton: "SplitButton"
};

/// <reference path="..\VStudio\vswd-ext_2.2.js" />

gxui.Grid = Ext.extend(gxui.UserControl, {
	// Private members
	m_colModel: null,
	m_record: null,
	m_dataStore: null,
	m_grid: null,
	m_view: null,
	m_selModel: null,
	m_pagingTb: null,
	m_toolbar: null,
	m_gxTbar: null,
	m_filters: null,

	initialize: function() {
		gxui.Grid.superclass.initialize.call(this);

		if (!gxui.Grid.Overrided) {
			Ext.override(Ext.grid.GridView, { fitColumns: this.fitColumns });
			Ext.override(Ext.grid.GridPanel, { applyState: this.applyState, getState: this.getState });
			gxui.Grid.Overrided = true;
		}

		if (!gxui.Grid.HttpProxyOverrided) {
			Ext.override(Ext.data.HttpProxy, { loadResponse: this.httpProxyLoadResponse });
			gxui.Grid.HttpProxyOverrided = true;
		}

		this.Width;
		this.Height;
		this.DataStoreURL;
		this.DataStoreParms;
		this.Data;
		this.ColumnModelData;
		this.Identifier;
		this.Record;
		this.Total;
		this.Paging;
		this.PageSize;
		this.DisplayInfo;
		this.DisplayMsg;
		this.EmptyMsg;
		this.EnableDragDrop;
		this.EnableColumnHide;
		this.EnableColumnMove;
		this.LoadingIndicator;
		this.LoadingMsg;
		this.DefaultSortable;
		this.DefaultResizable;
		this.TrackMouseOver;
		this.SelectionModel;
		this.SingleSelect;
		this.StripeRows;
		this.AutoWidth;
		this.AutoSizeColumns;
		this.MinColumnWidth;
		this.DefaultWidth;
		this.AutoHeight;
		this.Resizable;
		this.MinWidth;
		this.MaxWidth;
		this.MinHeight;
		this.MaxHeight;
		this.Wrap;
		this.Handles;
		this.Pinned;
		this.RemoteSort;
		this.DefaultSortField;
		this.DefaultSortDirection;
		this.SelectedRowData;
		this.UseToolbar;
		this.ToolbarData;
		this.ButtonPressedId;

		this.UserFilters;
		this.FiltersMode;
		this.AddSearchField;
		this.SearchFieldWidth;

		this.Cls;
		this.IconCls;
		this.Title;
		this.Collapsible;
		this.AnimateCollapse;
		this.Frame;
		this.ForceFit;
		this.Grouping;
		this.GroupField;
		this.GroupTemplate;
		this.HideGroupedField;

		this.Stateful;
		this.StateId;
		
		this.TreeMode;
		this.TreeParentField;
		this.TreeIsLeafField;
		this.TreeMasterColumn;
		this.TreeRootTitle;
		this.AutoExpandColumn;
		
	},
		

	// Databinding for property ColumnModel
	SetColumnModel: function(columnModel) {
		if (this.ColumnModelData && (Ext.util.JSON.encode(this.ColumnModelData) != Ext.util.JSON.encode(columnModel))) {
			this.destroy();
			this.forceRendering();
		}
		this.ColumnModelData = columnModel;
	},

	// Databinding for property ColumnModel
	GetColumnModel: function(columnModel) {
		return this.ColumnModelData;
	},

	// Databinding for property Data
	SetData: function(data) {
		this.Data = data;
		//this.initializeDataStore();
	},

	// Databinding for property Data
	GetData: function(data) {
		return this.Data;
	},

	// Databinding for property DataStoreParms
	SetDataStoreParms: function(data) {
		this.DataStoreParms = data;
	},

	// Databinding for property DataStoreParms
	GetDataStoreParams: function() {
		return this.DataStoreParms;
	},

	// Databinding for property SelectedRowData
	SetSelectedRowData: function(data) {
		this.SelectedRowData = data;
	},

	// Databinding for property DragDropData
	GetSelectedRowData: function(data) {
		return this.SelectedRowData;
	},

	// Databinding for property Data
	SetToolbarData: function(data) {
		this.ToolbarData = data;
	},

	// Databinding for property Data
	GetToolbarData: function(data) {
		return this.ToolbarData;
	},

	onRender: function() {
		this.initializeSelectionModel();
		this.initializeColumnModel();
		this.initializeFilters();
		this.initializeDataStore();
		this.initializeGrid();
		this.addListeners();

		this.refreshGrid();

		if (this.m_gxTbar)
			this.m_gxTbar.defineBtnsDropTarget();

		// Add to parent UC container
		this.addToParentContainer(this.m_grid);
	},

	onRefresh: function() {
		if (this.forceRefresh) {
			this.forceRefresh = false;
			this.Refresh();
		}

		if (gxui.CBoolean(this.UseToolbar)) {
			this.m_gxTbar.onRefresh();
		}
	},
	
	onDestroy: function() {
		if(typeof this.m_autoRefreshTask !== "undefined"){
			Ext.TaskMgr.stop(this.m_autoRefreshTask);
			delete this.m_autoRefreshTask;
		}
		gxui.Grid.superclass.onDestroy.call(this);
	},

	getUnderlyingControl: function() {
		return this.m_grid;
	},

	initializeSelectionModel: function() {
		if (this.SelectionModel == "CheckBoxSelectionModel")
			this.m_selModel = new Ext.grid.CheckboxSelectionModel({ singleSelect: gxui.CBoolean(this.SingleSelect) });
		else if (this.SelectionModel == "SmartCheckBoxSelectionModel")
			this.m_selModel = new Ext.grid.SmartCheckboxSelectionModel({ excel: false, singleSelect: gxui.CBoolean(this.SingleSelect), dataIndex: 'checked' });
		else if (this.SelectionModel == "RadioSelectionModel")
			this.m_selModel = new Ext.grid.RadioSelectionModel({ dataIndex: 'checked' });
		else
			this.m_selModel = new Ext.grid.RowSelectionModel({ singleSelect: gxui.CBoolean(this.SingleSelect) });

		this.m_selModel.on("selectionchange", this.updateSelection, this);

		if (gxui.CBoolean(this.LockSelections))
			this.m_selModel.lock();
	},

	initializeColumnModel: function() {

		var cmData = this.ColumnModelData;
		if (cmData && cmData.Columns) {

			var cmDataCols = cmData.Columns;
			var cmconf;

			if (this.SelectionModel == "RowSelectionModel")
				cmconf = this.GetColumnModelConfig(cmDataCols);
			else
				cmconf = [this.m_selModel].concat(this.GetColumnModelConfig(cmDataCols));

			this.colModel = new Ext.grid.ColumnModel(cmconf);
			//this.colModel.defaultSortable = gxui.CBoolean(this.DefaultSortable);
			this.colModel.defaultWidth = ((cmData.DefaultWidth > 0) ? cmData.DefaultWidth : 100);
			var mdata = new Array();
			for (var i = 0; i < cmDataCols.length; i++) {
				var c = cmDataCols[i];
				mdata.push({
					name: c.dataIndex,
					type: c.dataType,
					dateFormat: c.format
				});
			}

			if (gxui.CBoolean(this.TreeMode)) {
				mdata.push({ name: this.TreeParentField, type: 'auto' });
				mdata.push({ name: this.TreeIsLeafField, type: 'bool' });
			}

			this.m_record = Ext.data.Record.create(mdata);
		}
	},

	initializeFilters: function() {

		if (gxui.CBoolean(this.UseFilters) && this.ColumnModelData && this.ColumnModelData.Columns) {

			var filters = new Array();

			var cmDataCols = this.ColumnModelData.Columns;
			for (var i = 0; i < cmDataCols.length; i++) {

				var c = cmDataCols[i];

				if (gxui.CBoolean(c.filter)) {

					f = c.filterData;

					var cfg = {
						dataIndex: c.dataIndex,
						type: f.type,
						active: gxui.CBoolean(f.active),
						single: gxui.CBoolean(f.single),
						value: {}
					};

					switch (f.type) {

						case "date":
							cfg.dateFormat = gxui.dateFormat();
							if (f.values && (f.values.length > 0)) {
								for (var v = 0; v < f.values.length; v++) {
									var fv = f.values[v];
									var date = gxui.date(fv.value);
									if (fv.comparison == "after")
										cfg.value.after = date;
									else if (fv.comparison == "before")
										cfg.value.before = date;
									else
										cfg.value.on = date;
								}
							}
							break;

						case "numeric":
							if (f.values && (f.values.length > 0)) {
								for (var v = 0; v < f.values.length; v++) {
									var fv = f.values[v];
									if (fv.comparison == "gt")
										cfg.value.gt = fv.value;
									else if (fv.comparison == "lt")
										cfg.value.lt = fv.value;
									else
										cfg.value.eq = fv.value;
								}
							}
							break;

						case "boolean":
							cfg.defaultValue = f.value;
							break;

						case "list":
							cfg.options = f.options;
							cfg.value = f.value;

						default:
							cfg.value = f.value;
					}

					filters.push(cfg);
				}
			}

			this.m_filters = new Ext.grid.GridFilters({
				filters: filters
			});

			Ext.grid.GridFilters.prototype.menuFilterText = this.FiltersText;
			Ext.grid.filter.BooleanFilter.prototype.yesText = this.YesText;
			Ext.grid.filter.BooleanFilter.prototype.noText = this.NoText;
			Ext.grid.filter.DateFilter.prototype.beforeText = this.BeforeText;
			Ext.grid.filter.DateFilter.prototype.afterText = this.AfterText;
			Ext.grid.filter.DateFilter.prototype.onText = this.OnText;

		}
	},

	initializeDataStore: function() {
		var storeConfig;
		if (this.DataStoreURL != "") {
			storeConfig = {
				proxy: new Ext.data.HttpProxy({ url: this.DataStoreURL }),
				reader: new Ext.data.XmlReader({
					id: this.Identifier,
					record: this.Record,
					totalRecords: this.Total,
					success: '@success'
				}, this.m_record),
				remoteSort: gxui.CBoolean(this.RemoteSort),
				baseParams: { limit: parseInt(this.PageSize) }, //si bien en la paging toolbar ya se configura el pagesize, al usar el search filter no se toma en cuenta por eso se agrega en el store
				listeners: {
					'loadexception': {
						fn: function(proxy, options, response) {
							var error = Ext.DomQuery.selectValue('error', this.m_dataStore.reader.xmlData);
							this.LoadExceptionError = error;
							if (this.LoadException)
								this.LoadException();
						},
						scope: this
					}
				}
			};
		}
		else {
			if (this.Data) {
				storeConfig = {
					proxy: new Ext.data.MemoryProxy(this.Data),
					reader: new Ext.data.JsonReader({
						id: this.Identifier,
						root: this.Root,
						totalProperty: this.Total
					}, this.m_record)
				};
			}
		}

		if (gxui.CBoolean(this.TreeMode)) {
			storeConfig.autoLoad = true;
			storeConfig.parent_id_field_name = this.TreeParentField;			
			storeConfig.leaf_field_name = this.TreeIsLeafField;
			this.m_dataStore = new Ext.ux.maximgb.treegrid.AdjacencyListStore(storeConfig);
		}
		else if (gxui.CBoolean(this.Grouping)) {
			storeConfig.groupField = this.GroupField;
			this.m_dataStore = new Ext.data.GroupingStore(storeConfig);
		}
		else
			this.m_dataStore = new Ext.data.Store(storeConfig);

		if (this.DefaultSortField)
			this.m_dataStore.setDefaultSort(this.DefaultSortField, this.DefaultSortDir || 'ASC');
	},

	initializeGrid: function() {

		if (gxui.CBoolean(this.Paging)) {

			var pagingConfig = {
				store: this.m_dataStore,
				pageSize: parseInt(this.PageSize),
				plugins: this.m_filters,
				displayInfo: this.DisplayInfo,
				displayMsg: this.DisplayMsg, //'Displaying results {0} - {1} of {2}',
				emptyMsg: this.EmptyMsg // "No results to display"
			};

			if (gxui.CBoolean(this.TreeMode))
				this.m_pagingTb = new Ext.ux.maximgb.treegrid.PagingToolbar(pagingConfig);
			else
				this.m_pagingTb = new Ext.PagingToolbar(pagingConfig);

			this.m_pagingTb.firstText = this.FirstText;
			this.m_pagingTb.lastText = this.LastText;
			this.m_pagingTb.nextText = this.NextText;
			this.m_pagingTb.prevText = this.PreviousText;
			this.m_pagingTb.refreshText = this.RefreshText;
			this.m_pagingTb.afterPageText = this.AfterPageText;
			this.m_pagingTb.beforePageText = this.BeforePageText;
		}

		if (gxui.CBoolean(this.UseToolbar))
			this.initializeToolbar();

		var loadMask = (gxui.CBoolean(this.LoadingIndicator) && this.LoadingMsg) ? { msg: this.LoadingMsg} : gxui.CBoolean(this.LoadingIndicator);

		var viewConfig = {
			autoFill: gxui.CBoolean(this.AutoSizeColumns),
			forceFit: gxui.CBoolean(this.ForceFit),
			sortAscText: gx.getMessage("GXWF_SORT_ASCENDING"),
			sortDescText: gx.getMessage("GXWF_SORT_DESCENDING"),
			columnsText: gx.getMessage("GXWF_COLUMNS"),
			groupByText: gx.getMessage("GXWF_GROUP_BY_THIS_FIELD"),
			showGroupsText: gx.getMessage("GXWF_SHOW_IN_GROUPS")
		};

		if (gxui.CBoolean(this.TreeMode))
			this.m_view = new Ext.ux.maximgb.treegrid.GridView(viewConfig);

		else if (gxui.CBoolean(this.Grouping)) {
			viewConfig.hideGroupedColumn = gxui.CBoolean(this.HideGroupedField);
			viewConfig.groupTextTpl = (this.GroupTemplate != "") ? this.GroupTemplate : "{text}";
			this.m_view = new Ext.grid.GroupingView(viewConfig);
		}
		else
			this.m_view = new Ext.grid.GridView(viewConfig);

		this.Width = parseInt(this.Width);
		this.Height = parseInt(this.Height);

		var gridConfig = {
			id: this.getUniqueId(),
			renderTo: this.getContainerControl(),
			store: this.m_dataStore,
			cm: this.colModel,
			sm: this.m_selModel,
			trackMouseOver: gxui.CBoolean(this.TrackMouseOver),
			loadMask: loadMask,
			view: this.m_view,
			enableColumnHide: gxui.CBoolean(this.EnableColumnHide),
			enableColumnMove: gxui.CBoolean(this.EnableColumnMove),
			minColumnWidth: this.MinColumnWidth,
			autoHeight: gxui.CBoolean(this.AutoHeight),
			autoWidth: gxui.CBoolean(this.AutoWidth),
			width: (this.Width != 100) ? this.Width : undefined,
			height: (this.Height != 100) ? this.Height : undefined,
			autoExpandColumn: (this.AutoExpandColumn != "") ? this.AutoExpandColumn : undefined,
			collapsible: gxui.CBoolean(this.Collapsible),
			animCollapse: gxui.CBoolean(this.AnimateCollapse),
			title: this.Title,
			cls: this.Cls,
			iconCls: this.IconCls,
			frame: gxui.CBoolean(this.Frame),
			enableDragDrop: gxui.CBoolean(this.EnableDragDrop),
			stripeRows: gxui.CBoolean(this.StripeRows),
			stateful: gxui.CBoolean(this.Stateful),
			stateId: (this.StateId != "") ? this.StateId : undefined,
			bbar: this.m_pagingTb,
			tbar: this.m_toolbar,
			plugins: this.m_filters
		};

		if (gxui.CBoolean(this.TreeMode)) {
			gridConfig.master_column_id = this.TreeMasterColumn;
			gridConfig.root_title = this.TreeRootTitle;
			this.m_grid = new Ext.ux.maximgb.treegrid.GridPanel(gridConfig);
		}
		else
			this.m_grid = new Ext.grid.GridPanel(gridConfig);

		this.m_dataStore = this.m_grid.store;

		if (gxui.CBoolean(this.Resizable)) {
			var rz = new Ext.Resizable(this.m_grid.getEl(), {
				wrap: this.Wrap,
				minWidth: this.MinWidth,
				maxWidth: this.MaxWidth,
				minHeight: this.MinHeight,
				maxHeight: this.MaxHeight,
				pinned: this.Pinned,
				handles: this.Handles
			});

			rz.on('resize', this.m_grid.doLayout, this.m_grid);
		}
		
		if(gxui.CBoolean(this.AutoRefresh))
			this.m_autoRefreshTask = Ext.TaskMgr.start({
				run: function(count) {if (count > 1) this.refreshGrid();},
				scope: this,
				interval: parseInt(this.RefreshTimeout)*1000
			});
	},
	
	initializeToolbar: function() {	
	
		this.addToolbarSearchField();
		
		this.m_gxTbar = new gxui.Toolbar({ register: false });
		
		this.m_toolbar = this.m_gxTbar.CreateToolbar({
			id: this.getUniqueId() + "_Toolbar",
			data: this.ToolbarData,
			container: this,
			on: {
				'beforebuttonpressed': {
					fn: function(uc, btn, e) {
						this.updateSelection();
						if (btn.RefreshData)
							this.forceRefresh = true; // Esto hace que cuando se ejecute el onRefresh, se fuerce un refresh del grid.
					},
					scope: this
				}
			}
		});		
		
	},	
	
	addToolbarSearchField: function() {	
	
		if (gxui.CBoolean(this.AddSearchField)) {			
			if (!this.ToolbarData.Buttons) {
				this.ToolbarData.Buttons = [];
			}	
			this.ToolbarData.Buttons.push({ Type: 'Fill' });
			this.ToolbarData.Buttons.push({
				Type: 'Search',
				Store: this.m_dataStore,
				Width: this.SearchFieldWidth,
				AutoRefresh: this.SearchFieldAutoRefresh,
				AutoRefreshTimeout: this.SearchFieldAutoRefreshTimeout
			});			
		}		
	},	

	refreshGrid: function() {
		if (this.DataStoreURL != "") {
			if (gxui.CBoolean(this.Paging))
				this.m_grid.store.load({ params: Ext.apply({ start: 0, limit: parseInt(this.PageSize) }, this.DataStoreParms) });
			else
				this.m_grid.store.load({ params: this.DataStoreParms });
		}
		else {
			if (this.Data) {
				this.m_grid.store.loadData(this.Data);
			}
		}
	},

	updateSelection: function() {
		this.SelectedRowData = new Array();
		var selRows = this.m_grid.getSelectionModel().getSelections();
		if (selRows)
			Ext.each(selRows,
					function(item, index, allItems) {
						this.SelectedRowData.push(item.data);
					},
					this);
	},

	addListeners: function() {

		this.m_grid.addListener('rowclick', function(grid, rowIndex, e) {
			this.updateSelection();
			if (this.RowClick)
				this.RowClick();
		}, this);

		this.m_grid.addListener('rowdblclick', function(grid, rowIndex, e) {
			this.updateSelection();
			if (this.RowDoubleClick)
				this.RowDoubleClick();
		}
		, this);

		this.m_grid.addListener('cellclick', function(grid, rowIndex, columnIndex, e) {
			this.updateSelection();
			this.SelectedColumn = columnIndex;
			if (this.CellClick)
				this.CellClick();
		}
		, this);

		this.m_grid.addListener('celldblclick', function(grid, rowIndex, columnIndex, e) {
			this.updateSelection();
			this.SelectedColumn = columnIndex;
			if (this.CellDoubleClick)
				this.CellDoubleClick();
		}
		, this);
	},

	GetColumnModelConfig: function(cols) {
		var config = new Array();

		for (var i = 0; i < cols.length; i++) {
			var col = cols[i];
			config.push({
				id: (col.id != "") ? col.id : undefined,
				header: col.header,
				dataIndex: col.dataIndex,
				width: (col.width != 0) ? col.width : undefined,
				hidden: gxui.CBoolean(col.hidden),
				hideable: (col.hideable != "") ? gxui.CBoolean(col.hideable) : undefined,
				sortable: (col.sortable != "") ? gxui.CBoolean(col.sortable) : gxui.CBoolean(this.DefaultSortable),
				resizable: (col.resizable != "") ? gxui.CBoolean(col.resizable) : gxui.CBoolean(this.DefaultResizable),
				fixed: (col.fixed != "") ? gxui.CBoolean(col.fixed) : undefined,
				menuDisabled: gxui.CBoolean(col.menuDisabled),
				align: (col.align != "") ? col.align : undefined,
				renderer: (col.renderer != "") ? col.renderer : undefined,
				css: (col.css != "") ? col.css : undefined
			});
		}
		return config;
	},

	fitColumns: function(preventRefresh, onlyExpand, omitColumn) {

		var cm = this.cm, leftOver, dist, i;
		var tw = cm.getTotalWidth(false);
		var aw = this.grid.getGridEl().getWidth(true) - this.scrollOffset;

		if (aw < 100) {
			return;
		}
		var extra = aw - tw;

		if (extra === 0) {
			return false;
		}

		var vc = cm.getColumnCount(true);
		var ac = vc - (typeof omitColumn == 'number' ? 1 : 0);
		if (ac === 0) {
			ac = 1;
			omitColumn = undefined;
		}
		var colCount = cm.getColumnCount();
		var cols = [];
		var extraCol = 0;
		var width = 0;
		var w;
		for (i = 0; i < colCount; i++) {
			if (!cm.isHidden(i) && !cm.isFixed(i) && i !== omitColumn && cm.isResizable(i)) {
				w = cm.getColumnWidth(i);
				cols.push(i);
				extraCol = i;
				cols.push(w);
				width += w;
			}
		}
		var frac = (aw - cm.getTotalWidth()) / width;
		while (cols.length) {
			w = cols.pop();
			i = cols.pop();
			cm.setColumnWidth(i, Math.max(this.grid.minColumnWidth, Math.floor(w + w * frac)), true);
		}

		if ((tw = cm.getTotalWidth(false)) > aw) {
			for (i = 0; i < colCount; i++) {
				if (!cm.isHidden(i) && !cm.isFixed(i) && i !== omitColumn) {
					w = cm.getColumnWidth(i);
					cols.push(i);
					cols.push(w);
					width += w;
				}
			}
			var delta = (tw - aw) / cols.length;
			while (cols.length) {
				w = cols.pop();
				i = cols.pop();
				cm.setColumnWidth(i, Math.max(0, Math.floor(w - delta)), true);
			}
		}

		if (preventRefresh !== true) {
			this.updateAllColumnWidths();
		}

		return true;
	},

	applyState: function(state) {
		var cm = this.colModel;
		var cs = state.columns;
		if (cs) {
			for (var i = 0, len = cs.length; i < len; i++) {
				var s = cs[i];
				var c = cm.getColumnById(s.id);
				if (c) {
					c.hidden = s.hidden;
					c.width = s.width;
					var oldIndex = cm.getIndexById(s.id);
					if (oldIndex != i) {
						cm.moveColumn(oldIndex, i);
					}
				}
			}
		}
		if (state.sort) {
			this.store[this.store.remoteSort ? 'setDefaultSort' : 'sort'](state.sort.field, state.sort.direction);
		}
		if (state.group && this.store.groupBy) {
			this.store.groupBy(state.group);
		}
	},

	getState: function() {
		var o = { columns: [] };
		for (var i = 0, c; c = this.colModel.config[i]; i++) {
			o.columns[i] = {
				id: c.id,
				width: c.width
			};
			if (c.hidden) {
				o.columns[i].hidden = true;
			}
		}
		var ss = this.store.getSortState();
		if (ss) {
			o.sort = ss;
		}
		if (this.store.getGroupState) {
			var gs = this.store.getGroupState();
			if (gs) {
				o.group = gs;
			}
		}
		return o;
	},

	httpProxyLoadResponse: function(o, success, response) {
		delete this.activeRequest;
		if (!success) {
			this.fireEvent("loadexception", this, o, response);
			o.request.callback.call(o.request.scope, null, o.request.arg, false);
			return;
		}
		var result;
		try {
			result = o.reader.read(response);
			if (result.success === false) {
				this.fireEvent("loadexception", this, o, response);
				//return;
			}
		} catch (e) {
			this.fireEvent("loadexception", this, o, response, e);
			o.request.callback.call(o.request.scope, null, o.request.arg, false);
			return;
		}
		this.fireEvent("load", this, o, o.request.arg);
		o.request.callback.call(o.request.scope, result, o.request.arg, true);
	},

	// Methods
	Refresh: function() {
		this.refreshGrid();
	},
	
	RefreshToolbar: function() {
		this.addToolbarSearchField();
		this.m_toolbar = this.m_gxTbar.ChangeToolbar(this.ToolbarData, this.getUniqueId() + "_Toolbar", this);
	},	

	SelectRow: function(row, keepExisting) {
		index = this.m_grid.getStore().indexOfId(row);
		this.SelectRowByIndex(index, keepExisting);
	},

	SelectRowByIndex: function(rowIndex, keepExisting) {
		this.m_grid.getSelectionModel().selectRow(rowIndex, keepExisting);
	},

	DeselectRow: function(row) {
		index = this.m_grid.getStore().indexOfId(row);
		this.DeselectRowByIndex(index);
	},

	DeselectRowByIndex: function(rowIndex) {
		this.m_grid.getSelectionModel().deselectRow(rowIndex);
	},

	ClearSelections: function() {
		this.m_grid.getSelectionModel().clearSelections();
	}
});
/// <reference path="..\VStudio\vswd-ext_2.2.js" />

gxui.GridExtension = Ext.extend(gxui.UserControl, {
	initialize: function() {
		gxui.GridExtension.superclass.initialize.call(this);
	},

	SetToolbarData: function(data) {
		this.ToolbarData = data;
	},

	GetToolbarData: function() {
		return this.ToolbarData;
	},

	onRender: function() {
		var selModel = this.createSelectionModel();
		var columnModel = this.createColumnModel(selModel);
		this.m_currentColModel = columnModel.cm;
		var store = this.createStore(columnModel.fields);
		var pagingTb = this.createPagingToolbar();
		var view = this.createGridView();

		// create the Grid
		this.m_grid = new Ext.grid.GridPanel({
			id: this.getUniqueId(),
			store: store,
			columns: columnModel.cm,
			sm: selModel,
			view: view,
			autoExpandColumn: columnModel.autoExpandColumn ? columnModel.autoExpandColumn : undefined,
			enableColumnHide: gx.lang.gxBoolean(this.EnableColumnHide),
			enableColumnMove: gx.lang.gxBoolean(this.EnableColumnMove),
			stripeRows: (this.gxTitleBackstyle == gx.grid.styles.report),
			disableSelection: !gx.lang.gxBoolean(this.Allowselection),
			trackMouseOver: gx.lang.gxBoolean(this.Allowhover),
			collapsible: gx.lang.gxBoolean(this.Allowcollapsing),
			collapsed: gx.lang.gxBoolean(this.Collapsed),
			header: gx.lang.gxBoolean(this.Allowcollapsing),
			height: this.ownerGrid.height ? this.ownerGrid.height : undefined,
			width: this.ownerGrid.width ? this.ownerGrid.width : undefined,
			autoHeight: !this.ownerGrid.height,
			title: this.Title ? this.Title : undefined,
			//cls: this.gx.CssClass,
			renderTo: this.getContainerControl(),
			bbar: pagingTb,
			stateful: gx.lang.gxBoolean(this.Stateful),
			listeners: this.gridListeners(),
			stateful: gx.lang.gxBoolean(this.Stateful),
			stateId: (this.StateId != "") ? this.StateId : undefined
		});

		this.correctInheritedCentering();

		// Add to parent UC container
		if (gx.lang.gxBoolean(this.AddToParentGxUIControl)) {
			this.addToParentContainer(this.m_grid);
		}
//		window.gr = this;
//		console.log(this);
//		console.log(store);
	},

	onRefresh: function() {
		var selModel = this.createSelectionModel();
		this.createColumnModel(selModel);
		var grid = this.m_grid;

		if (Ext.util.JSON.encode(this.m_currentColModel) == Ext.util.JSON.encode(columnModel.cm)) {
			grid.getStore().loadData(this.properties);
		}
		else {
			this.m_currentColModel = columnModel.cm;
			var store = this.createStore(columnModel.fields);
			grid.reconfigure(store, new Ext.grid.ColumnModel(columnModel.cm));
		}
		this.updatePagingToolbar(grid.getBottomToolbar());

		this.keepSelection();

		if (gx.lang.gxBoolean(this.Allowcollapsing)) {
			if (gx.lang.gxBoolean(this.Collapsed)) {
				grid.collapse();
			}
			else {
				grid.expand();
			}
		}

		if (!grid.ownerCt) {
			if (this.ownerGrid.height && grid.getBox().height != this.ownerGrid.height) {
				grid.setHeight(this.ownerGrid.height);
			}

			if (this.ownerGrid.width && grid.getBox().width != this.ownerGrid.width) {
				grid.setWidth(this.ownerGrid.width);
			}
		}

		grid.setTitle(this.Title);
	},

	getUnderlyingControl: function() {
		return this.m_grid;
	},

	createSelectionModel: function() {
		if (this.SelectionModel == "CheckBoxSelectionModel")
			return new Ext.grid.CheckboxSelectionModel({ singleSelect: true });
		if (this.SelectionModel == "SmartCheckBoxSelectionModel")
			return new Ext.grid.SmartCheckboxSelectionModel({ singleSelect: true, dataIndex: 'checked' });
		if (this.SelectionModel == "RadioSelectionModel")
			return new Ext.grid.RadioSelectionModel({ dataIndex: 'checked' });

		return new Ext.grid.RowSelectionModel({ singleSelect: true });
	},

	createColumnModel: function(selModel) {
		var columns = this.columns;

		var getColumnType = function(col) {
			return col.type ? gxui.GridExtension.TypesMapping[col.type] || "" : "";
		};

		var getControlType = function(col) {
			for (var type in gx.html.controls.types) {
				if (col.gxControl.type == gx.html.controls.types[type]) {
					return type;
				}
			}
			return "";
		};

		// Renderer function for each control type.
		var renderers = {
			image: function(value, metadata, record, rowIndex, colIndex) {
				return String.format('<img src="{0}" />', value);
			}
		};

		var getColumnRenderer = function(col, actualColIndex, uc) {
			return function(value, metadata, record, rowIndex, storeColIndex) {
				var cell = record.json[actualColIndex];
				if (gx.lang.gxBoolean(cell.visible)) {
					var renderFn = renderers[getControlType(col)];
					if (renderFn) {
						value = renderFn.apply(this, arguments);
					}
					if (cell.link) {
						return String.format('<a href="{0}" alt="{2}" class="{3}">{1}</a>', cell.link, value, cell.alt, "");
					}
					if (col.gxControl.eventName || col.gxControl.jsDynCode) {
						metadata.attr += ' style="cursor:pointer;"';
						//return String.format('<a href="#">{0}</a>', value);
					}
					return value;
				}
				else {
					return "";
				}
			} .createDelegate(this);
		};

		var columnModel = {
			cm: [],
			fields: [],
			autoExpandColumn: 0
		};

		if (this.SelectionModel != "RowSelectionModel") {
			columnModel.cm.push(selModel);
		}

		Ext.each(this.columns, function(col, i) {
			if (gx.lang.gxBoolean(col.visible)) {
				if (gx.lang.gxBoolean(col.AutoExpand)) {
					columnModel.autoExpandColumn = col.gxAttId;
				}

				columnModel.fields.push({
					name: col.gxAttName || col.gxAttId,
					mapping: i,  // For the mapping only the column index is sent, because the getJsonAccessor is overriden to access this.properties matrix
					type: getColumnType(col)
					//,dateFormat
				});

				columnModel.cm.push({
					id: col.gxAttId,
					dataIndex: col.gxAttName || col.gxAttId,
					header: col.title,
					//tooltip: col.gxTooltip,
					width: !gx.lang.gxBoolean(col.AutoExpand) && col.gxWidthUnit == "px" ? col.width : undefined,
					//hidden: !col.gxVisible,
					renderer: getColumnRenderer(col, i, this),
					align: col.align,
					//,css: col.gxControl.cssClass
					//				fixed
					hideable: gx.lang.gxBoolean(col.Hideable),
					menuDisabled: gx.lang.gxBoolean(col.MenuDisabled),
					resizable: gx.lang.gxBoolean(col.Resizable),
					sortable: gx.lang.gxBoolean(col.Sortable)
				});
			}
		}, this);

		return columnModel;
	},

	createStore: function(fields) {
		var reader = new Ext.data.JsonReader({}, fields);
		reader.getJsonAccessor = function(i) {
			return function(obj) {
				return obj[i].value;
			};
		};
		var storeConfig = {
			sortInfo: {
				field: this.SortField,
				direction: this.SortOrder || "ASC"
			},
			remoteSort: true,
			reader: reader,
			data: this.properties,
			listeners: {
				'beforeload': function(store) {
					// Remember the SortField and SortOrder selected by the user.
					this.SortField = store.sortInfo.field;
					this.SortOrder = store.sortInfo.direction;
					this.goToPage("FIRST");
					return false;
				},
				'datachanged': function(store) {
					// Remember the GroupField selected by the user.
					if (gx.lang.gxBoolean(this.Grouping)) {
						this.GroupField = store.groupField;
					}
				},
				scope: this
			}
		};

		if (gx.lang.gxBoolean(this.Grouping)) {
			storeConfig.groupField = this.GroupField;
			return new Ext.data.GroupingStore(storeConfig);
		}
		return new Ext.data.Store(storeConfig);
	},

	createPagingToolbar: function() {
		var pagingTb = [];
		var cp = this.currentPage;
		var tp = 100000; // Todav�a no hay una property que de el total de p�ginas.

		if (this.usePaging || this.OnFirstPage) {
			pagingTb.push({
				tooltip: this.FirstText,
				iconCls: "x-tbar-page-first",
				disabled: cp == 1,
				handler: this.OnFirstPage || this.goToPage.createDelegate(this, ["first"]),
				scope: this
			});
		}

		if (this.usePaging || this.OnPreviousPage) {
			pagingTb.push({
				tooltip: this.PreviousText,
				iconCls: "x-tbar-page-prev",
				disabled: cp == 1,
				handler: this.OnPreviousPage || this.goToPage.createDelegate(this, ["prev"]),
				scope: this
			});
		}

		if (this.usePaging || ((this.OnFirstPage || this.OnPreviousPage) && (this.OnNextPage || this.OnLastPage))) {
			pagingTb.push("-");
		}

		if (this.usePaging || this.OnNextPage) {
			pagingTb.push({
				tooltip: this.NextText,
				iconCls: "x-tbar-page-next",
				disabled: cp == tp,
				handler: this.OnNextPage || this.goToPage.createDelegate(this, ["next"]),
				scope: this
			});
		}

		if (this.usePaging || this.OnLastPage) {
			pagingTb.push({
				tooltip: this.LastText,
				iconCls: "x-tbar-page-last",
				disabled: cp == tp,
				handler: this.OnLastPage || this.goToPage.createDelegate(this, ["last"]),
				scope: this
			});
		}

		if (this.usePaging || this.OnFirstPage || this.OnPreviousPage || this.OnNextPage || this.OnLastPage) {
			pagingTb.push("-");
		}

		pagingTb.push({
			tooltip: this.RefreshText,
			iconCls: "x-tbar-loading",
			handler: this.refreshGrid,
			scope: this
		});

		return pagingTb;
	},

	updatePagingToolbar: function(tb) {
		if (tb) {
			var cp = 10000; // Deber�a ser this.currentPage pero no est� andando
			var tp = 100000; // Todav�a no hay una property que de el total de p�ginas.

			if (tb.items.itemAt(0)) {
				tb.items.itemAt(0).setDisabled(cp == 1);
			}
			if (tb.items.itemAt(1)) {
				tb.items.itemAt(1).setDisabled(cp == 1);
			}
			if (tb.items.itemAt(3)) {
				tb.items.itemAt(3).setDisabled(cp == tp);
			}
			if (tb.items.itemAt(4)) {
				tb.items.itemAt(4).setDisabled(cp == tp);
			}
		}
	},

	createGridView: function() {
		if (gx.lang.gxBoolean(this.Grouping)) {
			return new Ext.grid.GroupingView({
				//autoFill: gx.lang.gxBoolean(this.AutoSizeColumns),
				forceFit: gx.lang.gxBoolean(this.ForceFit),
				hideGroupedColumn: gx.lang.gxBoolean(this.HideGroupedField),
				groupTextTpl: (this.GroupTemplate != "") ? this.GroupTemplate : "{text}"
			});
		}
		return new Ext.grid.GridView({
			//autoFill: gx.lang.gxBoolean(this.AutoSizeColumns),
			forceFit: gx.lang.gxBoolean(this.ForceFit)
		});
	},

	keepSelection: function() {
		Ext.each(this.rows, function(row, index) {
			if (row.selected) {
				this.m_grid.selectRow(index);
				return false;
			}
		}, this);
	},

	gridListeners: function() {
		return {
			'rowclick': function(grid, rowIndex, e) {
				Ext.each(this.rows, function(r) {
					r.selected = false;
				}, this);

				var row = this.rows[rowIndex];
				if (row) {
					row.selected = true;
					// Set row as selected
					this.setSelectedRowVars(row);
					// Execute OnlineActivate event
					if (this.gxOnLineActivate) {
						this.parentGxObject[this.gxOnLineActivate].call(this.parentGxObject, row);
					}
					// Set context
				}
			},
			'cellclick': function(grid, rowIndex, columnIndex, e) {
				var actualColIndex = this.getActualColumnIndex(grid, columnIndex);
				if (this.executeEvent) {
					this.executeEvent(actualColIndex, rowIndex);
				}
			},
			scope: this
		};
	},

	getActualColumnIndex: function(grid, colIndex) {
		var colId = grid.getColumnModel().getColumnId(colIndex);
		var length = this.columns.length;
		for (var i = 0; i < length; i++) {
			if (this.columns[i].gxAttId == colId) {
				return i;
			}
		}
		return -1;
	},

	getPropertiesCell: function(grid, rowIndex, columnIndex) {
		var actualColIndex = this.getActualColumnIndex(grid, columnIndex);
		var record = grid.getStore().getAt(rowIndex);  // Get the Record
		if (record) {
			return record.json[actualColIndex];
		}
		return null;
	},

	goToPage: function(page) {
		if (typeof page == "string") {
			gx.fn.setHidden(this.gxGridName.toUpperCase() + "PAGING", page.toUpperCase());
			gx.evt.execEvt("E" + this.gxGridName.toUpperCase() + "PAGING.", gx.evt.dummyCtrl);
			return;
		}
	},

	refreshGrid: function() {
		this.render();
	},

	// This is to correct the inherited value of the text-align property, because
	// if a TD parent element has de align property set to a value other than "left", 
	// that value is inherited by all the tables that compose the grid.
	correctInheritedCentering: function() {
		var textAlign = this.m_grid.el ? this.m_grid.el.getStyle('text-align') : "";
		if (textAlign == "") {
			return;
		}
		if (textAlign.indexOf("center") >= 0 || textAlign.indexOf("right") >= 0) {
			this.m_grid.el.setStyle('text-align', 'left');
			Ext.select("table", false, this.m_grid.el.dom).setStyle('text-align', 'left');
		}
	}

});

// Mapping between gx.types and ExtJS Grid column types
gxui.GridExtension.TypesMapping = {
	"0": "float",
	"1": "string",
	"2": "string",
	"3": "string",
	"4": "string",
	"5": "string",
	"6": "string",
	"7": "boolean"
};

gxui.Panel = Ext.extend(gxui.UserControl, {
	m_panel: null,
	m_toolbar: null,
	m_gxtb: null,

	initialize: function() {
		gxui.Panel.superclass.initialize.call(this);
	},

	SetToolbarData: function(data) {
		this.ToolbarData = data;
	},

	GetToolbarData: function(data) {
		return this.ToolbarData;
	},

	onRender: function() {
		if (gxui.CBoolean(this.UseToolbar)) {
			this.m_gxTbar = new gxui.Toolbar({ register: false });
			this.m_toolbar = this.m_gxTbar.CreateToolbar({
				id: this.getUniqueId() + "_Toolbar",
				data: this.ToolbarData,
				container: this
			});
		}

		var config = this.getConfig();

		if (gxui.CBoolean(this.ShowAsWindow)) {
			config.closeAction = "hide";
			config.renderTo = 'MAINFORM';
			config.modal = gxui.CBoolean(this.Modal);
			config.constrainHeader = true;
			this.m_panel = new Ext.Window(config);
		}
		else {
			if (gxui.CBoolean(this.Draggable))
				this.m_panel = new gxui.ext.Portlet(config);
			else {
				this.m_panel = new Ext.Panel(config);
				if (gxui.CBoolean(this.Resizable)) {
					this.m_panel.on('render', function() {
						var rz = new Ext.Resizable(this.m_panel.getEl(), {
							minWidth: this.MinWidth,
							maxWidth: this.MaxWidth,
							minHeight: this.MinHeight,
							maxHeight: this.MaxHeight,
							pinned: this.Pinned,
							handles: this.Handles
						});

						rz.on('resize', this.m_panel.doLayout, this.m_panel);
					}, this)
				}
			}
		}

		if (!gxui.CBoolean(this.ShowAsWindow)) {
			// Add to parent UC container
			if (this.AddToParentGxUIControl == undefined || gxui.CBoolean(this.AddToParentGxUIControl)) {
				this.addToParentContainer(this.m_panel);
			}
			this.m_panel.render(this.getContainerControl());
		}
		else {
			if (gx.lang.gxBoolean(this.Visible)) {
				this.m_panel.show();
			}
		}

		this.m_panel.body.first().enableDisplayMode().show();

		// Register as UC Container
		this.registerCt(this.m_panel.body.first().dom, this.m_panel.add, this.m_panel.doLayout, this.m_panel);
	},

	onRefresh: function() {
		var panel = this.m_panel;
		panel.setTitle(this.Title);
		if (!panel.ownerCt) {
			panel.setWidth(gxui.CBoolean(this.AutoWidth) ? undefined : this.Width);
			panel.setHeight(gxui.CBoolean(this.AutoHeight) ? undefined : this.Height);
		}
		if (gx.lang.gxBoolean(this.Visible) && !this.m_panel.isVisible()) {
			panel.show();
		}
		else {
			if (!gx.lang.gxBoolean(this.Visible) && panel.isVisible()) {
				panel.hide();
			}
		}

		if (gxui.CBoolean(this.UseToolbar)) {
			this.m_gxTbar.SetData(this.ToolbarData);
			this.m_gxTbar.onRefresh();
		}
	},

	getUnderlyingControl: function() {
		return this.m_panel;
	},

	getConfig: function() {
		var config = {
			anchor: '100%',
			contentEl: this.getChildContainer("Body"),
			id: this.getUniqueId(),
			title: this.Title,
			width: gxui.CBoolean(this.AutoWidth) ? undefined : parseInt(this.Width),
			height: gxui.CBoolean(this.AutoHeight) ? undefined : parseInt(this.Height),
			autoWidth: gxui.CBoolean(this.AutoWidth),
			autoHeight: gxui.CBoolean(this.AutoHeight),
			autoScroll: this.Layout == 'default' ? true : false,
			frame: gxui.CBoolean(this.Frame),
			border: gxui.CBoolean(this.Border),
			resizable: gxui.CBoolean(this.Resizable),
			minWidth: this.MinWidth,
			minHeight: this.MinHeight,
			maxWidth: this.MaxWidth,
			maxHeight: this.MaxHeight,
			pinned: gxui.CBoolean(this.Pinned),
			resizeHandles: this.Handles,
			collapsible: gxui.CBoolean(this.Collapsible),
			collapsed: gxui.CBoolean(this.Collapsed),
			animateCollapse: gxui.CBoolean(this.AnimateCollapse),
			header: this.Title ? true : false || gxui.CBoolean(this.Collapsible),
			tbar: this.m_toolbar,
			listeners: this.getListeners(),
			stateful: gxui.CBoolean(this.Stateful),
			stateId: (this.StateId != "") ? this.StateId : undefined,
			saveState: function() {
				if (this.stateful === true)
					this.constructor.superclass.saveState.call(this);
			},
			layout: this.Layout == 'default' ? undefined : this.Layout
		};

		if (this.IconCls)
			config.iconCls = this.IconCls;
		if (this.Cls)
			config.cls = this.Cls;
		if (!gx.lang.gxBoolean(this.Visible))
			config.hidden = true;

		return config;
	},

	getListeners: function() {
		return {
			'collapse': function() {
				this.Collapsed = "true";
			},

			'expand': function() {
				this.Collapsed = "false";
			},

			'hide': function() {
				this.Visible = false;
				if (this.OnClose) {
					this.OnClose();
				}
			},

			scope: this
		};
	},

	// Methods
	ChangeToolbar: function(toolbarData) {
		if (this.m_gxTbar)
			this.m_toolbar = this.m_gxTbar.ChangeToolbar(toolbarData, this.getUniqueId() + "_Toolbar", this);
	},

	Collapse: function(animate) {
		this.m_panel.collapse(animate);
	},

	Expand: function(animate) {
		this.m_panel.expand(animate);
	},

	DisableToolbarItem: function(itemId) {
		this.m_gxTbar.DisableItem(itemId);
	},

	EnableToolbarItem: function(itemId) {
		this.m_gxTbar.EnableItem(itemId);
	},

	HideToolbarItem: function(itemId) {
		this.m_gxTbar.HideItem(itemId);
	},

	ShowToolbarItem: function(itemId) {
		this.m_gxTbar.ShowItem(itemId);
	},

	CenterWindow: function() {
		if (gxui.CBoolean(this.ShowAsWindow)) {
			this.m_panel.center();
		}
	}
});
/// <reference path="..\VStudio\vswd-ext_2.2.js" />

gxui.Treeview = Ext.extend(gxui.UserControl, {
    // Private members
    m_tree: null,

    initialize: function() {
        gxui.Treeview.superclass.initialize.call(this);

        this.NotifyContext = "false";
        this.NotifyDataType = 'gxuiTreeNode';
        this.CheckedNodes = [];
    },

    // Databinding
    SetChildren: function(data) {
        this.Children = data;
    },

    // Databinding
    GetChildren: function(data) {
        return this.Children;
    },

    // Databinding
    SetCheckedNodes: function(data) {
        this.CheckedNodes = data;
    },

    // Databinding
    GetCheckedNodes: function(data) {
        if (this.m_tree) {
            this.CheckedNodes = this.m_tree.getChecked("id");
        }
        return this.CheckedNodes;
    },

    // Databinding
    SetUncheckedNodes: function(data) {
        this.UncheckedNodes = data;
    },

    // Databinding
    GetUncheckedNodes: function(data) {
        if (this.m_tree) {
            var root = this.m_tree.getRootNode();
            if (root) {
                var nodes = [];
                root.cascade(function() {
                    if (this.attributes.checked === false) {
                        nodes.push(this.id);
                    }
                });
                this.UncheckedNodes = nodes;
            }
        }
        return this.UncheckedNodes;
    },

    // Databinding
    SetDropData: function(data) {
        this.DropData = data;
    },

    // Databinding
    GetDropData: function(data) {
        return this.DropData;
    },

    // Databinding
    SetSelectedNodeData: function(data) {
        this.SelectedNodeData = data;
    },

    // Databinding
    GetSelectedNodeData: function(data) {
        return this.SelectedNodeData;
    },

    onRender: function() {
        var Tree = Ext.tree;
        var enableCheckbox = gxui.CBoolean(this.EnableCheckbox);
        var ddGroup = this.DragDropGroup || undefined;

        this.Width = parseInt(this.Width);
        this.Height = parseInt(this.Height);

        this.m_tree = new Tree.TreePanel({
            id: this.getUniqueId(),
            renderTo: this.getContainerControl(),
            width: (this.Width != 100) ? this.Width : undefined,
            height: (this.Height != 100) ? this.Height : undefined,
            title: this.Title,
            frame: gxui.CBoolean(this.Frame),
            border: gxui.CBoolean(this.Border),
            cls: this.Cls,
            animate: gxui.CBoolean(this.Animate),
            rootVisible: gxui.CBoolean(this.RootVisible),
            lines: gxui.CBoolean(this.ShowLines),
            loader: new Tree.TreeLoader({
                dataUrl: (gxui.CBoolean(this.LazyLoading)) ? this.LoaderURL : undefined,
                preloadChildren: !gxui.CBoolean(this.LazyLoading),
                createNode: function(attr) {
                    // Create node function is overriden to remove checked attribute if checkboxes aren't enabled, to avoid
                    // rendering the checkbox when not needed.
                    if (!enableCheckbox) {
                        delete attr.checked;
                    }
                    return Ext.tree.TreeLoader.prototype.createNode.call(this, attr);
                },
                listeners: {
                    'beforeload': function() {
                        this.loading = true;
                    },
                    'load': function() {
                        this.loading = false;
                    },
                    scope: this
                }
            }),
            enableDD: gxui.CBoolean(this.EnableDragDrop),
            ddAppendOnly: gxui.CBoolean(this.AppendOnly),
            dragConfig: {
                primaryButtonOnly: false,
                ddGroup: ddGroup
            },
            dropConfig: {
                ddGroup: ddGroup
            },
            autoScroll: gxui.CBoolean(this.AutoScroll),
            containerScroll: gxui.CBoolean(this.Scroll),
            stateful: gxui.CBoolean(this.Stateful),
            stateId: (this.StateId && this.StateId != "") ? this.StateId : this.getUniqueId(),
            stateEvents: gxui.CBoolean(this.Stateful) ? ['collapsenode', 'expandnode'] : undefined,
            getState: gxui.CBoolean(this.Stateful) ? gxui.Treeview.getState : undefined,
            applyState: gxui.CBoolean(this.Stateful) ? gxui.Treeview.applyState(gxui.CBoolean(this.LazyLoading)) : undefined,
            root: new Tree.AsyncTreeNode({
                id: (this.RootId ? this.RootId : 'ROOT'),
                text: this.RootText,
                icon: (this.RootIcon ? this.RootIcon : undefined),
                cls: (this.RootCls ? this.RootCls : undefined),
                iconCls: (this.RootIconCls ? this.RootIconCls : undefined),
                draggable: false, // disable root node dragging
                children: !gxui.CBoolean(this.LazyLoading) ? gxui.clone(this.Children.length && this.Children.length > 0 ? this.Children : [this.Children]) : undefined
            }),
            selModel: gxui.CBoolean(this.Multiselection) ? new Ext.tree.MultiSelectionModel() : undefined
        });

        this.m_tree.addListener(this.getListeners());

        if (gxui.CBoolean(this.Multiselection)) {
            this.m_tree.getSelectionModel().addListener('selectionchange', function(selModel, nodes) {
                this.SelectedNodes = [];
                Ext.each(nodes, function(node) {
                    this.SelectedNodes.push(node.id);
                }, this);
            }, this);
        }

        if (gxui.CBoolean(this.Editable)) {
            this.m_treeEditor = new Ext.tree.TreeEditor(this.m_tree, {}, {
                allowBlank: false,
                selectOnFocus: true,
                cancelOnEsc: true,
                completeOnEnter: true,
                ignoreNoChange: true,
                listeners: {
                    'complete': function(editor, value) {
                        this.NodeEditText = value;
                        if (this.NodeEdit) {
                            this.NodeEdit();
                        }
                    },
                    scope: this
                },
                // Overriden function to avoid bug in IE. See: http://www.extjs.com/forum/showthread.php?43408-2.2-OPEN-TreeEditor-Behaviour&p=285736
                triggerEdit: function(node, defer) {
                    this.completeEdit();
                    if (node.attributes.editable !== false) {

                        this.editNode = node;
                        if (this.tree.autoScroll && !Ext.isIE) {
                            node.ui.getEl().scrollIntoView(this.tree.body);
                        }
                        this.autoEditTimer = this.startEdit.defer(this.editDelay, this, [node.ui.textNode, node.text]);
                        return false;
                    }
                }
            });
        }

        // Add a tree sorter in folder mode
        if (gxui.CBoolean(this.Sort))
            new Tree.TreeSorter(this.m_tree, { folderSort: true });

        // Add to parent UC container
        if (gxui.CBoolean(this.AddToParentGxUIControl)) {
            this.addToParentContainer(this.m_tree);
        }

        this.m_tree.render();

        if (gxui.CBoolean(this.ExpandRoot))
            this.m_tree.getRootNode().expand(gxui.CBoolean(this.ExpandAll), gxui.CBoolean(this.Animate));
    },

    onRefresh: function() {
        var selNode = this.m_tree.getSelectionModel().getSelectedNode();
        if (selNode) {
            this.setSelectedNode(selNode);
        }
    },

    getUnderlyingControl: function() {
        return this.m_tree;
    },

    loadTreeNodes: function() {
        var children = gxui.clone(this.Children.length && this.Children.length > 0 ? this.Children : [this.Children]);
        this.m_tree.root.attributes.children = children;
    },

    getRowDropData: function(dropEvent) {
        if (dropEvent.data && dropEvent.data.gxRow) {
            var gxRow = dropEvent.data.gxRow;
            var gxCols = dropEvent.data.gxColumns;

            var dropData = {};
            Ext.each(gxCols, function(col, i) {
                var colName = col.gxAttName || (col.gxAttId.charAt(0) == "&" ? col.gxAttId.substring(1) : col.gxAttId);
                dropData[colName] = gxRow.values[i];
            }, this);

            return dropData;
        }

        return null;
    },

    getNodeById: function(node) {
        return this.m_tree.getNodeById(node);
    },

    getListeners: function() {
        var listeners = {
            'click': function(node, e) {
                this.endEdit();
                this.setSelectedNode(node);
                if (gx.lang.emptyObject(node.attributes.href)) {
                    if (this.NotifyContext == "true") {
                        var types = new Array();
                        types[0] = this.NotifyDataType;

                        this.notifyContext(types, { id: node.id, text: node.text, leaf: node.leaf, icon: node.attributes.icon });
                    }
                    if (this.Click && (!node.hasChildNodes() || !gxui.CBoolean(this.DisableBranchEvents))) {
                        this.Click();
                    }
                }
            },

            'dblclick': function(node, e) {
                this.endEdit();
                this.setSelectedNode(node);
                if (this.DoubleClick && (!node.hasChildNodes() || !gxui.CBoolean(this.DisableBranchEvents))) {
                    this.DoubleClick();
                }
            },

            'nodedragover': function(dragOverEvent) {
                if (this.NodeOver) {
                    // Set UC properties before fireing the event
                    this.DropTarget = dragOverEvent.target.id;
                    this.DropPoint = dragOverEvent.point;
                    if (dragOverEvent.source.grid) {
                        this.DropData = this.getRowDropData(dragOverEvent);
                    }
                    else {
                        this.DropNode = dragOverEvent.dropNode.id;
                    }

                    this.DropAllowed = true;

                    // Fire the event
                    this.NodeOver();

                    return this.DropAllowed;
                }
                return true;
            },

            'beforenodedrop': function(dropEvent) {
                dropEvent.rawEvent.preventDefault();
                if (dropEvent.source.grid) {
                    this.DropTarget = dropEvent.target.id;
                    this.DropPoint = dropEvent.point;

                    this.DropData = this.getRowDropData(dropEvent);
                    dropEvent.target.ui.endDrop(); // Ended here because if the RowDrop runs in the server, the ghost is not hidden.

                    if (this.RowDrop) {
                        this.RowDrop();
                    }
                }

                // Disable context menu until (workaround for avoiding showing context menu in right click D&D operations in IE and Chrome)
                Ext.getBody().on('contextmenu', Ext.emptyFn, this, {
                    single: true,
                    stopEvent: true,
                    preventDefault: true
                });
            },

            'nodedrop': function(dropEvent) {
                this.DropTarget = dropEvent.target.id;
                this.DropPoint = dropEvent.point;

                if (dropEvent.dropNode) {
                    this.DropNode = dropEvent.dropNode.id;
                    if (this.NodeDrop) {
                        this.NodeDrop();
                    }
                }
            },

            'checkchange': function(node) {
                if (this.CheckChange) {
                    this.setSelectedNode(node);
                    node.select();
                    this.CheckChange();
                }
            },

            scope: this
        };

        if (this.ContextMenu) {
            listeners['contextmenu'] = function(node) {
                this.endEdit();
                if (this.ContextMenu) {
                    this.setSelectedNode(node);
                    node.select();
                    this.ContextMenu();
                }
            };
        }

        return listeners;
    },

    setSelectedNode: function(node) {
        this.SelectedNode = node.id;
        this.SelectedText = node.text;
        this.SelectedIcon = node.attributes.icon;
        this.SelectedNodeData = node.attributes.data;
        this.SelectedNodeChecked = node.attributes.checked || false;
    },

    endEdit: function() {
        if (this.m_treeEditor) {
            this.m_treeEditor.completeEdit();
        }
    },

    // Helper function used by public methods that must be run when the tree is done loading its nodes.
    doAfterLoad: function(fn, scope) {
        if (this.loading) {
            this.m_tree.getLoader().on('load', fn, scope, { single: true });
        }
        else {
            fn.call(scope);
        }
    },

    // Methods
    SelectNode: function(nodeId) {
        this.doAfterLoad(function() {
            var node = this.getNodeById(nodeId);
            if (node) {
                this.setSelectedNode(node)
                node.select();
                this.m_tree.expandPath(node.getPath());
            }
        }, this);
    },

    ExpandNode: function(nodeId) {
        this.doAfterLoad(function() {
            var node = this.getNodeById(nodeId);
            if (node) {
                node.expand();
            }
        }, this);
    },

    ExpandAllNodes: function() {
        this.doAfterLoad(function() {
            this.m_tree.expandAll();
        }, this);
    },

    CollapseNode: function(nodeId) {
        this.doAfterLoad(function() {
            var node = this.getNodeById(nodeId);
            if (node) {
                node.collapse();
            }
        }, this);
    },

    CollapseAllNodes: function() {
        this.doAfterLoad(function() {
            this.m_tree.collapseAll();
        }, this);
    },

    Reload: function(node, expand) {
        // node can be a TreeNode or a String with the Id of a node. If node is undefined, the root node is reloaded.
        var n = node ? ((typeof node == 'object') ? node : this.getNodeById(node)) : this.m_tree.getRootNode();

        if (n) {
            var loadCallback = function() {
                if (expand || expand === undefined) {
                    n.expand();
                }
            };

            var loader = this.m_tree.getLoader();
            if (gxui.CBoolean(this.LazyLoading)) {
                loader.dataUrl = this.LoaderURL;
                if (loader.isLoading())
                    loader.load.defer(500, loader, [n, loadCallback]);
                else
                    loader.load(n, loadCallback);
            }
            else {
                this.loadTreeNodes();
                // Workaround to force the node load event to execute, so the state is applied.
                loader.load(n, function() {
                    this.fireEvent("load", this);
                    loadCallback();
                } .createDelegate(n));
            }

            if (this.SelectedNode != undefined) {
                this.SelectNode(this.SelectedNode);
            }
        }
    },

    Refresh: function() {
        this.m_tree.setHeight((this.Width != 100) ? this.Width : undefined);
        this.m_tree.setWidth((this.Height != 100) ? this.Height : undefined);
        this.m_tree.setTitle(this.Title);
        this.Reload(this.m_tree.getRootNode(), gxui.CBoolean(this.ExpandRoot));
    },

    Show: function() {
        this.m_tree.setVisible(true);
    },

    Hide: function() {
        this.m_tree.setVisible(false);
    },

    GetNodeParentId: function(nodeId) {
        var node = this.getNodeById(nodeId);
        if (node && node.parentNode) {
            return node.parentNode.id;
        }
        return "";
    },

    SetNodeData: function(nodeId, nodeData) {
        var node = this.getNodeById(nodeId);
        if (node) {
            node.attributes.data = nodeData;
        }
    },

    GetNodeData: function(nodeId) {
        var node = this.getNodeById(nodeId);
        if (node) {
            return node.attributes.data;
        }
    },

    SetNodeText: function(nodeId, text) {
        var node = this.getNodeById(nodeId);
        if (node) {
            node.setText(text);
        }
    },

    StartEdit: function(nodeId, value) {
        var node = this.getNodeById(nodeId);
        if (node) {
            this.m_treeEditor.editNode = node;
            this.m_treeEditor.startEdit(value || node.ui.textNode);
        }
    },

    CancelEdit: function() {
        this.m_treeEditor.cancelEdit();
    },

    ClearAllNodes: function() {
        var root = this.m_tree.getRootNode();
        while (root.firstChild) {
            root.removeChild(root.firstChild);
        }
        delete root.attributes.children;
    },
	
	NodeExists: function(nodeId) {
		var node = this.getNodeById(nodeId);
		return (node ? true : false);
	}
});

gxui.Treeview.getState = function() {
	var nodes = [];
	this.getRootNode().eachChild(function(child) {
		//function to store state of tree recursively
		var storeTreeState = function(node, expandedNodes) {
			if (node.isExpanded() && node.childNodes.length > 0) {
				expandedNodes.push(node.getPath());
				node.eachChild(function(child) {
					storeTreeState(child, expandedNodes);
				});
			}
		};
		storeTreeState(child, nodes);
	});

	return {
		expandedNodes: nodes
	}
};

gxui.Treeview.applyState = function(lazyLoading) {
	return function(state) {
		var that = this;
		// If lazyLoading is enabled in the tree, attach to the loader's load event. If not, attach to the root node load event.
		var subject = lazyLoading ? this.getLoader() : this.root;
		subject.on('load', function() {
			//read state in from cookie, not from what is passed in
			var cookie = Ext.state.Manager.get(that.stateId);
			var nodes = cookie.expandedNodes;
			for (var i = 0; i < nodes.length; i++) {
				if (typeof nodes[i] != 'undefined') {
					that.expandPath(nodes[i]);
				}
			}
		});
	}
};

gxui.Splash = Ext.extend(gxui.UserControl, {
	m_cookieId: "gxui.Splash",
	initialize: function(){
		gxui.Splash.superclass.initialize.call(this);

		this.Width;
		this.Height;
		this.Duration;
		this.Image;
		this.Message;
		this.Cls;
	},

	onRender: function(){

		if(gxui.getCookie(this.m_cookieId)==""){	
		
			try{			
				this.mask = Ext.get(document.body).mask(this.Message + " ", this.Cls);
				window.setTimeout("Ext.get(document.body).unmask();", this.Duration*1000);		
			}
			catch(err){};			
			gxui.setCookie(this.m_cookieId, '1', 0);			
		}
	
	}

});
/// <reference path="..\VStudio\vswd-ext_2.2.js" />

gxui.Container = Ext.extend(gxui.UserControl, {
	m_element: null,
	
	initialize: function(){
		gxui.Container.superclass.initialize.call(this);
		
		this.Width;
		this.Height;
		this.Visible;
	},
	
	onRender: function(){
		this.m_element = Ext.get(this.getChildContainer("Body"));
		this.m_element.enableDisplayMode();
		if (!gxui.CBoolean(this.Visible))
			this.m_element.hide();
		else
		    this.m_element.show();
	},
	
	onRefresh: function(){
		if (!gxui.CBoolean(this.Visible) && this.m_element.isVisible())
			this.m_element.slideOut();
			
		if (gxui.CBoolean(this.Visible) && !this.m_element.isVisible())
			this.m_element.slideIn();
	},

	getUnderlyingControl : function(){
		return this.m_element;
	}
});
gxui.Message = Ext.extend(gxui.UserControl, function(){

	// Private variables
	var msgCt;	
	
	return {
		initialize: function(){
			gxui.Message.superclass.initialize.call(this);

			this.Width;
			this.Height;
			this.Duration;
			this.Message;
			this.Title;
			this.Icon;
			this.Cls;
			this.Show;
		},
		
		onRender: function(){
			this.showMessage();
		},
		
		onRefresh: function(){
			this.showMessage();
		},
		
		showMessage: function(){	
		
			if(gxui.CBoolean(this.Show)){
		
				if(this.Type == "alert"){
				
					Ext.MessageBox.show({
					   title: this.Title,
					   msg: this.Message,
					   buttons: Ext.MessageBox.OK,
					   
					   
					   icon: this.Icon == "info"?Ext.MessageBox.INFO:(this.Icon == "question"?Ext.MessageBox.QUESTION:(this.Icon == "warning"?Ext.MessageBox.WARNING:Ext.MessageBox.ERROR))
				   });
				   
				}
				else{
					var titleMsgs = this.Title.split("|");
					Ext.each(this.Message.split("|"), function(msg, i){
						// Create the message box
						if(!msgCt){
			                msgCt = Ext.DomHelper.insertFirst(document.body, {id:'msg-div'}, true);
							if(this.Cls != "")
								msgCt.addClass(this.Cls);
			            }
			            msgCt.alignTo(document, this.Position + '-' + this.Position);
			            var m = Ext.DomHelper.append(msgCt, {html:this.createBox(titleMsgs[i], msg)}, true);
			            
			            var timeoutId;
			            var hideMessage = function(){
		            		timeoutId = setTimeout(function(){
								m.ghost(this.Position, {remove:true});
				            }.createDelegate(this), this.Duration*1000);
			            };
			            
			            // Slide the message box into view
			            m.slideIn(this.Position,  {
			            	callback: hideMessage,
			            	scope: this
			            });
			            
			            // Do not hide the message box if the mouse is over it
			            m.on('mouseover', function(e){
			            	if (timeoutId){
			            		clearTimeout(timeoutId);
			            		timeoutId = null;
			            	}
			            }, this);
			            
			            // If the mouse is outside the message box, schedule its hiding, according to duration
			            m.on('mouseout', function(e){
							var box = m.getBox();
							var x = e.getPageX();
							var y = e.getPageY();
							if (x && y){
								if (x > box.x && x < box.x + box.width && y > box.y && y < box.y + box.height){
									return
								}
							}
				            hideMessage.createDelegate(this)();
			            }, this)
					}, this);
				}
			
			}

		},
		
	    createBox: function(t, s){
	        return ['<div class="msg">',
	                '<div class="x-box-tl"><div class="x-box-tr"><div class="x-box-tc"></div></div></div>',
	                '<div class="x-box-ml"><div class="x-box-mr"><div class="x-box-mc"><h3>', t, '</h3>', s, '</div></div></div>',
	                '<div class="x-box-bl"><div class="x-box-br"><div class="x-box-bc"></div></div></div>',
	                '</div>'].join('');
	    }
	
	};
	
}());
gxui.PropertiesEditorLoader = function(options){
	
	this.categoryPathSeparator = "\\";
	gxui.PropertiesEditorLoader.superclass.constructor.call(this, options);
	this.initialize();
};

Ext.extend(gxui.PropertiesEditorLoader, Ext.tree.TreeLoader, {
	
	
	
	initialize: function() {
		this.definitions = gxui.Properties.ObjectDefsRepository; // Just a shortcut to avoid writing the long class name
		this.definitions.init(this.defParams);
		this.objects = gxui.Properties.ObjectsRepository; // Just a shortcut to avoid writing the long class name
		this.objects.init(this.objParams);
	},

	createNode: function(attr) {
		attr.uiProvider = gxui.PropertiesEditorNodeUI;
		return gxui.PropertiesEditorLoader.superclass.createNode.apply(this, [attr]);
	},

	
	load: function(node, callback, alphOrder) {
		if (this.clearOnLoad) {
			node.children = [];
			delete this.categoriesNodes;
			delete this.propertiesNodes;

			while (node.firstChild) {
				node.removeChild(node.firstChild);
			}
		}
		if (this.doPreload(node)) { // preloaded json children
			if (typeof callback == "function") {
				callback();
			}
		}
		else if (this.objId) {
			this.requestData(node, callback, alphOrder);
		}
		else if (typeof callback == "function") {
			callback();
		}
	},

	requestData: function(node, callback, alphOrder) {
		if (this.fireEvent("beforeload", this, node, callback) !== false) {
			this.transId = true;
			this.objects.getProperties(this.objId, node.attributes.Category || "", function(obj, store, r, success) {
				if (success) {
					this.definitions.getDefinition(obj.ObjectClass, function(def, success) {
						if (success)
							this.handleResponse(node, callback, obj, store, def, alphOrder);
						else
							this.handleFailure(node, callback);
					}, this);
				}
				else
					this.handleFailure();
			}, this);
		} else {
			// if the load is cancelled, make sure we notify
			// the node that we are done
			if (typeof callback == "function") {
				callback();
			}
		}
	},

	handleResponse: function(node, callback, obj, props, def, alphOrder) {
		this.transId = false;
		if (this.objId == obj.objId) {
			this.processResponse(node, callback, props, def, alphOrder);
		}
		this.fireEvent("load", this, node);
	},

	handleFailure: function(node, callback) {
		this.transId = false;
		this.fireEvent("loadexception", this, node);
		if (typeof callback == "function") {
			callback(this, node);
		}
	},

	processResponse: function(node, callback, props, def, alphOrder) {
		if (alphOrder === true) {
			this.createFlatOrderedTree(node, props, def);
		}
		else {
			this.createTree(node, props, def);
		}

		if (node.children) {
			node.beginUpdate();
			for (var i = 0, len = node.children.length; i < len; i++) {
				// Don't show those nodes that seem to be leafs but don't have any children. 
				// >>This is temporal, until we can set in the control if there's Lazy Loading or not.<<
				if (!node.children[i].leaf && (!node.children[i].children || node.children[i].children == [])) {
					node.removeChild(node.children[i]);
				}
				else {
					var n = this.createNode(node.children[i]);
					if (n) {
						node.appendChild(n);
					}
				}
			}
			node.endUpdate();
		}

		if (alphOrder === true) {
			node.sort(function(a, b) {
				if (a.text < b.text)
					return -1;
				if (a.text > b.text)
					return 1;
				return 0;
			});
		}

		if (typeof callback == "function") {
			callback(this, node);
		}
	},

	createTree: function(node, props, def) {
		var root = node.getOwnerTree().getRootNode();

		if (!node.attributes.Category) {
			node.attributes.Category = "";
		}

		if (!this.categoriesNodes) {
			this.categoriesNodes = {
				ROOT: root
			};
		}

		if (!this.propertiesNodes) {
			this.propertiesNodes = {};
		}

		Ext.each(def, function(descriptor) {
			// Find the property described by "descriptor" in props store.
			var idx = props.find("Name", descriptor.Name);

			if (idx >= 0) {
				var prop = props.getAt(idx);
				var parentNode = (node.attributes.Category == descriptor.Category) ? node : this.getParentNode(root, descriptor);

				if (parentNode && !this.propertiesNodes[descriptor.Name]) { // Defensive control to avoid loading the same node more than once
					var n = {
						id: descriptor.Name,
						text: descriptor.DisplayName,
						value: prop.data.Value,
						isDefault: prop.data.IsDefault,
						editor: descriptor.Editor ? descriptor.Editor : { type: 'textfield' },
						expanded: false,
						leaf: true
					};
					this.addPropertyNode(parentNode, n);
				}
			}
			else {
				var categoryList = descriptor.Category.split(this.categoryPathSeparator)
				var category = categoryList.pop();
				if (descriptor.Category != "" && node.attributes.Category == categoryList.join(this.categoryPathSeparator)) {
					// Create branch of categories
					this.createBranch(node, descriptor, [category]);
				}
			}
		}, this);
	},

	createFlatOrderedTree: function(node, props, def) {
		Ext.each(def, function(descriptor) {
			// Find the property described by "descriptor" in props store.
			var idx = props.find("Name", descriptor.Name);

			if (idx >= 0) {
				var prop = props.getAt(idx);

				var newNode = {
					id: descriptor.Name,
					text: descriptor.DisplayName,
					value: prop.data.Value,
					isDefault: prop.data.IsDefault,
					editor: descriptor.Editor ? descriptor.Editor : { type: 'textfield' },
					expanded: false,
					leaf: true
				};
				node.children.push(newNode);
			}
		}, this);
	},

	getParentNode: function(root, descriptor) {
		if (this.categoriesNodes[descriptor.Category || "ROOT"]) {
			parentNode = this.categoriesNodes[descriptor.Category || "ROOT"]
		}
		else {
			// Create branch of categories
			parentNode = this.createBranch(root, descriptor, descriptor.Category.split(this.categoryPathSeparator));
		}
		return parentNode;
	},

	addPropertyNode: function(parentNode, newNode) {
		if (!parentNode.children) {
			parentNode.children = [];
			parentNode.lastPropertyIndex = 0;
		}
		parentNode.children.splice(parentNode.lastPropertyIndex, 0, newNode);
		parentNode.lastPropertyIndex += 1;
		this.propertiesNodes[newNode.id] = newNode;
	},

	addCategoryNode: function(parentNode, newNode) {
		if (!parentNode.children)
			parentNode.children = [];
		parentNode.children.push(newNode);
		this.categoriesNodes[newNode.Category || "ROOT"] = newNode;
	},

	createBranch: function(node, descriptor, branch) {
		var n = this.findChild(node, "Category:" + branch[0]);
		if (!n) {
			n = {
				id: "Category:" + branch[0],
				Category: descriptor.Category,
				text: branch[0],
				value: "",
				isDefault: "",
				editor: "",
				expanded: false,
				leaf: false,
				cls: "gxui-prop-category"
			};
			this.addCategoryNode(node, n);
		}

		if (branch.length > 1) {
			return this.createBranch(n, descriptor, branch.slice(1))
		}
		return n;
	},

	findChild: function(node, id) {
		var child;
		if (node.children) {
			Ext.each(node.children, function(n) {
				if (n.id == id) {
					child = n;
					return false
				}
			}, this);
		}
		return child;
	}
});
gxui.PropertiesEditorNodeUI = Ext.extend(Ext.tree.TreeNodeUI, {
	focus: Ext.emptyFn, // prevent odd scrolling behavior

	renderElements : function(n, a, targetNode, bulkRender){
		this.indentMarkup = n.parentNode ? n.parentNode.ui.getChildIndent() : '';

		var t = n.getOwnerTree();
		var cols = t.columns;
		var bw = t.borderWidth;

		// Label markup
		var c = cols.label;
		var buf = [
			'<li class="x-tree-node"><div ext:tree-node-id="',n.id,'" class="x-tree-node-el x-tree-node-leaf ', a.cls,'">',
				'<div class="x-tree-col x-tree-firstcol" style="width:',c.width-bw,'px;">',
					'<span class="x-tree-node-indent">',this.indentMarkup,"</span>",
					'<img src="', this.emptyIcon, '" class="x-tree-ec-icon x-tree-elbow">',
					'<img src="', a.icon || this.emptyIcon, '" class="x-tree-node-icon',(a.icon ? " x-tree-node-inline-icon" : ""),(a.iconCls ? " "+a.iconCls : ""),'" unselectable="on">',
					'<a hidefocus="on" class="x-tree-node-anchor" href="',a.href ? a.href : "#",'" tabIndex="1" ',
					a.hrefTarget ? ' target="'+a.hrefTarget+'"' : "", '>',
					'<span unselectable="on">', n.text || (c.renderer ? c.renderer(a[c.dataIndex], n, a) : a[c.dataIndex]),"</span></a>",
				"</div>"];

		// Value markup
		c = cols.value;
		var data = (typeof(a[c.dataIndex]) == 'object') ? a[c.dataIndex].data : a[c.dataIndex];
		buf.push('<div class="x-tree-col ',(c.cls?c.cls:''),'" style="width:',c.width-bw,'px;">',
					'<div class="x-tree-col-text">',(c.renderer ? c.renderer(data, n, a) : data),"</div>",
				"</div>");
				
		buf.push(
			'<div class="x-clear"></div></div>',
			'<ul class="x-tree-node-ct" style="display:none;"></ul>',
			"</li>");

		if(bulkRender !== true && n.nextSibling && n.nextSibling.ui.getEl()){
			this.wrap = Ext.DomHelper.insertHtml("beforeBegin",
								n.nextSibling.ui.getEl(), buf.join(""));
		}else{
			this.wrap = Ext.DomHelper.insertHtml("beforeEnd", targetNode, buf.join(""));
		}
		
		this.elNode = this.wrap.childNodes[0];
		this.ctNode = this.wrap.childNodes[1];
		var cs = this.elNode.firstChild.childNodes;
		this.indentNode = cs[0];
		this.ecNode = cs[1];
		this.iconNode = cs[2];
		this.anchor = cs[3];
		this.textNode = cs[3].firstChild;
		this.valueNode = Ext.get(this.elNode.childNodes[1].childNodes[0]);
		
		this.valueEditorConfig = a.editor;
		
		// Fire "labeldoubleclick" event when the label is double clicked.
		Ext.get(this.elNode).on('dblclick', function(){
			t.fireEvent('labeldoubleclick', t, n);
		});
		
		// Open editor if value is clicked
		if (a.editor){
			this.valueNode.on('click', function(e){
				this.startEditor(t, n);
			}, this);
		}
	},
	
	startEditor: function(t, n){
		if (t.readOnly){
			return null;
		}
		
		if (!n.leaf){
			return null;
		}
		
		if (!this.valueEditor){
			this.valueEditorField = this.getField(this.valueEditorConfig);
			this.valueEditor = new Ext.Editor(this.valueEditorField, {
				cancelOnEsc: true,
				completeOnEnter: true,
				updateEl: true,
				ignoreNoChange: true,
				autoSize: true,
				constrain: true
			});
			
			this.valueEditor.on({
				'complete': {
					fn: function(e, value){
						n.attributes.value = value;
						t.selectionPath = t.getSelectionModel().getSelectedNode().getPath();
						t.fireEvent('valuechanged', t, n);
					}
				},
				'hide': {
					fn: function(e, value){
						// This is to set focus on the property again, after the focus on the edit field is lost.
						n.ui.anchor.focus();
					}
				}
			});
		}
		
		this.valueEditor.startEdit(this.valueNode);
	},
	
	startEditorDeferred: function(t, n){
		this.startEditor.defer(350, this, [t, n]);
	},
	
	getField: function(editor){
		var xtype = editor.type;
		if (editor.type == "combo-status"){
			xtype = 'combo';
			editor.cfg = Ext.apply(editor.cfg || {}, {
				store: ['Pre-Online','Online','Pre-Offline','Offline'],
				typeAhead: true,
				triggerAction: 'all',
				selectOnFocus:true,
				disableKeyFilter: true,
				forceSelection: true,
				listeners: {
					'focus': {
						fn: function(f){
							f.setValue('');
						}
					}
				}
			});
		}
		if (editor.type == "combo-align"){
			xtype = 'combo';
			editor.cfg = Ext.apply(editor.cfg || {}, {
				store: ['Center','Left','Right'], 
				disableKeyFilter: true,
				forceSelection: true,
				listeners: {
					'focus': {
						fn: function(f){
							f.setValue('');
						}
					}
				}
			});
		}
		if (editor.type == "combo-valign"){
			xtype = 'combo';
			editor.cfg = Ext.apply(editor.cfg || {}, {
				store: ['Bottom','Middle','Top'], 
				disableKeyFilter: true,
				forceSelection: true,
				listeners: {
					'focus': {
						fn: function(f){
							f.setValue('');
						}
					}
				}
			});
		}
		if (editor.type == "combo-boolean"){
			xtype = 'combo';
			editor.cfg = Ext.apply(editor.cfg || {}, {
				store: ['True','False'], 
				disableKeyFilter: true,
				forceSelection: true,
				listeners: {
					'focus': {
						fn: function(f){
							f.setValue('');
						}
					}
				}
			});
		}
		if (editor.type == "combo-fontfamily"){
			xtype = 'combo';
			editor.cfg = Ext.apply(editor.cfg || {}, {
				store: ['Arial','Arial Narrow','Tahoma','Times','Trebuchet MS','Verdana'], 
				disableKeyFilter: true,
				forceSelection: true,
				listeners: {
					'focus': {
						fn: function(f){
							f.setValue('');
						}
					}
				}
			});
		}
		if (editor.type == "combo-fontsize"){
			xtype = 'combo';
			editor.cfg = Ext.apply(editor.cfg || {}, {
				store: ['7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25'],
				forceSelection: true,
				listeners: {
					'focus': {
						fn: function(f){
							f.setValue('');
						}
					}
				}
			});
		}
		if (editor.type == "combo-fontstyle"){
			xtype = 'combo';
			editor.cfg = Ext.apply(editor.cfg || {}, {
				store: ['Normal','Italic','Bold','Bold Italic'],
				disableKeyFilter: true,					
				forceSelection: true,
				listeners: {
					'focus': {
						fn: function(f){
							f.setValue('');
						}
					}
				}
			});
		}	
		if (editor.type == "combo-fontefect"){
			xtype = 'combo';
			editor.cfg = Ext.apply(editor.cfg || {}, {
				store: ['None','Strikethrough','Underline','Sentence case','lowercase','UPPERCASE','Capitalize Each Word'],
				disableKeyFilter: true,					
				forceSelection: true,
				listeners: {
					'focus': {
						fn: function(f){
							f.setValue('');
						}
					}
				}
			});
		}			
		if (editor.type == "trigger-classfont"){
			xtype = 'combo';
			editor.cfg = Ext.apply(editor.cfg || {}, {
				store: ['Title News','Title Portlets','Title Prpducts','Abstact News','Abstact Content','Body Content'],
				emptyText:'Select template...',
				listeners: {
					'focus': {
						fn: function(f){
							f.setValue('');
						}
					}
				}
			});
		}
		if (editor.type == "trigger-classbox"){
			xtype = 'combo';
			editor.cfg = Ext.apply(editor.cfg || {}, {
				store: ['Box Titles portlet','Box Title News','Box Abstact News'],
				emptyText:'Select template...',
				listeners: {
					'focus': {
						fn: function(f){
							f.setValue('');
						}
					}
				}
			});
		}				
		return Ext.ComponentMgr.create(Ext.apply(editor.cfg || {}, {allowBlank:true, store:(editor.cfg)? editor.cfg.store : undefined}), xtype);
	}
});

gxui.PropertiesEditorTree = Ext.extend(Ext.tree.TreePanel, {
	lines: false,
	borderWidth: 2, // the combined left/right border for each cell
	cls: 'x-column-tree',
	rootVisible: false,
	
	readOnly: false,

	
	alphOrder: false,

	initComponent: function() {
		this.filter.filterActiveClass = 'gxui-prop-filter-active';

		this.filter.filterTextField = new Ext.form.TextField({
			width: this.filter.width,
			emptyText: this.filter.emptyText,
			listeners: {
				render: function(f) {
					f.el.on('keydown', function(e) {
						if (e.getKey() != e.TAB) {
							this.filterTree(e.target.value);
						}
					}, this, { buffer: 350 });

					f.el.on('blur', function(e) {
						// Select first visible node of the tree when leaving the filter field.
						this.root.cascade(function(n) {
							var selNode = this.getSelectionModel().getSelectedNode();
							if (!selNode || (selNode && selNode.hidden)) {
								if (n.isLeaf() && !n.hidden) {
									n.select();
									return false;
								}
								return true;
							}
						}, this);
					}, this);
				},
				scope: this
			}
		});

		this.tbar = [
			this.filter.filterTextField,
			' ',
			' ',
			Ext.apply(this.tbarActions.order, {
				toggleHandler: function(btn, state) {
					this.alphOrder = state;
					this.loadProperties();
				},
				enableToggle: true,
				scope: this
			}),
			'-',
			Ext.apply(this.tbarActions.expand, {
				handler: function() {
					this.root.expand(true);
					this.resizeColumns();
				},
				scope: this
			}),
			Ext.apply(this.tbarActions.collapse, {
				handler: function() {
					this.root.collapse(true);
					this.resizeColumns();
				},
				scope: this
			})
		];

		this.root = new Ext.tree.AsyncTreeNode({
			expanded: true,
			expandable: false,
			cls: 'gxui-prop-category'
		});

		gxui.PropertiesEditorTree.superclass.initComponent.call(this);

		this.addEvents(
		
			"labeldoubleclick",

		
			"valuechanged"
		);

		// This is necessary to enable moving with the keyboard, no matter if the user clicks 
		// on the property label or outside of it.
		this.getSelectionModel().on('selectionchange', function(selModel, node) {
			if (node) {
				node.ui.anchor.focus();
			}
		}, this);
	},

	onRender: function() {
		gxui.PropertiesEditorTree.superclass.onRender.apply(this, arguments);
		this.headers = this.body.createChild(
			{ cls: 'x-tree-headers' }, this.innerCt.dom);

		var cols = this.columns, c;
		var totalWidth = 0;

		var totalWidth = this.createTreeHeaders(cols.label);
		totalWidth += this.createTreeHeaders(cols.value);

		this.headers.createChild({ cls: 'x-clear' });
		// prevent floats from wrapping when clipped
		this.headers.setWidth(totalWidth);
		this.innerCt.setWidth(totalWidth);

		this.filter.treeFilter = new Ext.tree.TreeFilter(this, {
			clearBlank: true,
			autoClear: true
		});

		this.on('bodyresize', function() {
			this.resizeColumns();
		}, this);
	},

	loadProperties: function(objId) {
		if (objId) {
			this.getLoader().objId = objId;
		}
		this.getLoader().load(this.getRootNode(), function() {
			// Re-apply the filter after reloading the properties.
			this.filterTree(this.filter.filterTextField.getValue());
			// Set the node that was selected before reloading as the currently selected node. This shouldn't be necesary if stateful is enabled.
			if (this.selectionPath) {
				this.selectPath(this.selectionPath);
			}
			this.resizeColumns();
		} .createDelegate(this), this.alphOrder);
	},

	createTreeHeaders: function(c) {
		var totalWidth = c.width;
		this.headers.createChild({
			cls: 'x-tree-hd ' + (c.cls ? c.cls + '-hd' : ''),
			cn: {
				cls: 'x-tree-hd-text',
				html: c.header
			},
			style: 'width:' + (c.width - this.borderWidth) + 'px;'
		});

		return totalWidth;
	},

	hiddenCategories: [],

	filterTree: function(text) {
		Ext.each(this.hiddenCategories, function(n) {
			n.ui.show();
		});

		if (text == "") {
			this.filter.treeFilter.clear();
			this.filter.filterTextField.removeClass(this.filter.filterActiveClass);
			return;
		}
		else {
			// Expand all the nodes of the tree before filtering.
			this.root.expand(true);

			this.filter.filterTextField.addClass(this.filter.filterActiveClass);

			var re = new RegExp(Ext.escapeRe(text), 'i');
			this.filter.treeFilter.filterBy(function(n) {
				return !n.leaf || re.test(n.attributes.text);
			});

			// hide empty categories that weren't filtered
			this.hiddenCategories = [];
			this.hideCategories(this.root);
		}
		this.resizeColumns();
	},

	hideCategories: function(node) {
		if (!node.leaf) {
			var hide = true;
			node.eachChild(function(n) {
				hide = this.hideCategories(n) && hide;
			}, this);

			if (hide) {
				node.ui.hide();
				this.hiddenCategories.push(node);
			}
		}

		return node.hidden;
	},

	// Overriden
	getSelectionModel: function() {
		if (!this.selModel) {
			this.selModel = new gxui.PropertiesEditorSelectionModel();
		}
		return this.selModel;
	},

	// Resize columns
	resizeColumns: function() {
		var Cwidth = this.body.getViewSize().width;

		if (Cwidth) {
			var labelWidth = Cwidth * 0.5;
			var valueWidth = Cwidth * 0.5;
			Ext.select("div.x-tree-hd:nth-child(1)", false, this.getId()).setWidth(labelWidth);
			Ext.select("div.x-tree-col:nth-child(1)", false, this.getId()).setWidth(valueWidth);
			Ext.select("div.x-tree-col:nth-child(2)", false, this.getId()).setWidth(valueWidth);
			this.columns.label.width = labelWidth;
			this.columns.value.width = valueWidth;

			this.headers.setWidth(labelWidth + valueWidth);
			this.innerCt.setWidth(labelWidth + valueWidth);
		}
	}
});

// Custom selection model for properties editor.
gxui.PropertiesEditorSelectionModel = Ext.extend(Ext.tree.DefaultSelectionModel, {
	onKeyDown: function(e){
		gxui.PropertiesEditorSelectionModel.superclass.onKeyDown.call(this, e);
		
		var k = e.getKey();
		switch(k){
			case e.TAB:
				e.preventDefault();
				if (!e.shiftKey && !e.ctrlKey){
					this.selNode.ui.startEditorDeferred(this.tree, this.selNode);
				}
			break;
		};
	}
});
/// <reference path="..\VStudio\vswd-ext_2.2.js" />

gxui.PropertiesEditor = Ext.extend(gxui.UserControl, {
	initialize: function() {
		gxui.PropertiesEditor.superclass.initialize.call(this);

		this.Width;
		this.Height;
		this.ReadOnly;
		this.AutoHeight;
		this.ObjectId;
		this.SelectedPropertyId;
		this.SelectedPropertyValue;
		this.Refresh;
		this.FilterEmptyText;
		this.FilterBoxWidth;
		this.IconCollapseURL;
		this.IconCollapseTooltip;
		this.IconExpandURL;
		this.IconExpandTooltip
	},

	onRender: function() {
		this.m_tree = new gxui.PropertiesEditorTree({
			id: this.getUniqueId(),
			renderTo: this.getContainerControl(),
			width: (this.Width != 300) ? this.Width : undefined,
			height: gxui.CBoolean(this.AutoHeight) ? undefined : this.Height,
			autoHeight: gxui.CBoolean(this.AutoHeight),
			readOnly: gxui.CBoolean(this.ReadOnly),
			autoScroll: true,
			hideHeader: true,
			cls: 'gxui-prop-panel',

			filter: {
				width: this.FilterBoxWidth,
				emptyText: this.FilterEmptyText
			},

			tbarActions: {
				order: {
					tooltip: this.IconOrderTooltip || 'Order',
					icon: this.IconOrderURL ? this.IconExpandURL : undefined,
					iconCls: this.IconOrderURL ? 'x-btn-text-icon' : 'icon-order'
				},
				expand: {
					tooltip: this.IconExpandTooltip || 'Expand all',
					icon: this.IconExpandURL ? this.IconExpandURL : undefined,
					iconCls: this.IconExpandURL ? 'x-btn-text-icon' : 'icon-expand-all'
				},
				collapse: {
					tooltip: this.IconCollapseTooltip || 'Collapse all',
					icon: this.IconCollapseURL ? this.IconCollapseURL : undefined,
					iconCls: this.IconCollapseURL ? 'x-btn-text-icon' : 'icon-collapse-all'
				}
			},

			columns: {
				label: {
					width: 0,
					dataIndex: 'text'
				},
				value: {
					width: 0,
					dataIndex: 'value'
				}
			},

			loader: new gxui.PropertiesEditorLoader({
				objId: this.ObjectId,
				defParams: {
					url: this.DefinitionsLoaderURL
				},
				objParams: {
					url: this.PropertiesLoaderURL
				}
			})
		});
		this.addListeners();

		// Add to parent UC container
		this.addToParentContainer(this.m_tree);
	},

	SetSelectedObjectId: function(id) {
		this.ObjectId = id;
		this.RefreshData();
	},

	RefreshData: function() {
		this.Refresh = true;
		this.onRefresh();
	},

	onRefresh: function() {
		var doRefresh = function() {
			if (gxui.CBoolean(this.Refresh)) {
				this.m_tree.loadProperties(this.ObjectId);
			}

			this.m_scheduled = false;
		};

		if (!this.m_scheduled) {
			this.m_scheduled = true;
			setTimeout(doRefresh.createDelegate(this), 500);
		}
	},

	getUnderlyingControl: function() {
		return this.m_tree;
	},

	addListeners: function() {
		this.m_tree.on({
			'labeldoubleclick': {
				fn: function(tree, node) {
					this.SelectedPropertyId = node.attributes.id;
					this.SelectedPropertyValue = node.attributes.value;
					if (this.GetDefault) {
						this.GetDefault();
					}
				},
				scope: this
			},
			'valuechanged': {
				fn: function(tree, node, col) {
					this.SelectedPropertyId = node.attributes.id;
					this.SelectedPropertyValue = node.attributes.value;
					if (this.PropertyChanged) {
						this.PropertyChanged();
					}
				},
				scope: this
			}
		});
	}
});
// vim: ts=4:sw=4:nu:fdc=2:nospell




// {{{
// Define clone function if it is not already defined
if('function' !== Ext.type(Ext.ux.clone)) {
	Ext.ux.clone = function(o) {
		if('object' !== typeof o) {
			return o;
		}
		var c = 'function' === typeof o.pop ? [] : {};
		var p, v;
		for(p in o) {
			if(o.hasOwnProperty(p)) {
				v = o[p];
				if('object' === typeof v) {
					c[p] = Ext.ux.clone(v);
				}
				else {
					c[p] = v;
				}
			}
		}
		return c;
	};
} // eo clone
// }}}


// {{{
Ext.ux.HttpProvider = function(config) {

	this.addEvents(
		
		 'readsuccess'
		
		,'readfailure'
		
		,'savesuccess'
		
		,'savefailure'
	);

	// call parent 
	Ext.ux.HttpProvider.superclass.constructor.call(this);

	Ext.apply(this, config, {
		// defaults
		 delay:750 // buffer changes for 750 ms
		,dirty:false
		,started:false
		,autoStart:true
		,autoRead:true
		,user:'user'
		,id:1
		,session:'session'
		,logFailure:false
		,logSuccess:false
		,queue:[]
		,url:'.'
		,readUrl:undefined
		,saveUrl:undefined
		,method:'post'
		,saveBaseParams:{}
		,readBaseParams:{}
		,paramNames:{
			 id:'id'
			,name:'name'
			,value:'value'
			,user:'user'
			,session:'session'
			,data:'data'
		}
	}); // eo apply

	if(this.autoRead) {
		this.readState();
	}

	this.dt = new Ext.util.DelayedTask(this.submitState, this);
	if(this.autoStart) {
		this.start();
	}
}; // eo constructor
// }}}

Ext.extend(Ext.ux.HttpProvider, Ext.state.Provider, {

	// localizable texts
	 saveSuccessText:'Save Success'
	,saveFailureText:'Save Failure'
	,readSuccessText:'Read Success'
	,readFailureText:'Read Failure'
	,dataErrorText:'Data Error'

	// {{{
	
	,initState:function(state) {
		if(state instanceof Array) {
			Ext.each(state, function(item) {
				this.state[item.name] = this.decodeValue(item.value);
			}, this);
		}
		else {
			this.state = state ? state : {};
		}
	} // eo function initState
	// }}}
	// {{{
	
	,set:function(name, value) {
		if(!name) {
			return;
		}

		this.queueChange(name, value);

	} // eo function set
	// }}}
	// {{{
	
	,start:function() {
		this.dt.delay(this.delay);
		this.started = true;
	} // eo function start
	// }}}
	// {{{
	
	,stop:function() {
		this.dt.cancel();
		this.started = false;
	} // eo function stop
	// }}}
	// {{{
	
	,queueChange:function(name, value) {
		var changed = undefined === this.state[name] || this.state[name] !== value;
		var o = {};
		var i;
		var found = false;
		if(changed) {
			o[this.paramNames.name] = name;
			o[this.paramNames.value] = this.encodeValue(value);
			for(i = 0; i < this.queue.length; i++) {
				if(this.queue[i] && this.queue[i].name === o.name) {
					this.queue[i] = o;
					found = true;
				}
			}
			if(false === found) {
				this.queue.push(o);
			}
			this.dirty = true;
		}
		return changed;
	} // eo function bufferChange
	// }}}
	// {{{
	
	,submitState:function() {
		if(!this.dirty) {
			this.dt.delay(this.delay);
			return;
		}
		this.dt.cancel();

		var o = {
			 url:this.saveUrl || this.url
			,method:this.method
			,scope:this
			,success:this.onSaveSuccess
			,failure:this.onSaveFailure
			,queue:Ext.ux.clone(this.queue)
			,params:{}
		};

		var params = Ext.apply({}, this.saveBaseParams);
		params[this.paramNames.id] = this.id;
		params[this.paramNames.user] = this.user;
		params[this.paramNames.session] = this.session;
		params[this.paramNames.data] = Ext.encode(o.queue);

		Ext.apply(o.params, params);

		// be optimistic
		this.dirty = false;

		Ext.Ajax.request(o);
	} // eo function submitState
	// }}}
	// {{{
	
	,clear:function(name) {
		this.set(name, undefined);
	} // eo function clear
	// }}}
	// {{{
	
	,onSaveSuccess:function(response, options) {
		if(this.started) {
			this.start();
		}
		var o = {};
		try {o = Ext.decode(response.responseText);}
		catch(e) {
			if(true === this.logFailure) {
				this.log(this.saveFailureText, e, response);
			}
			this.dirty = true;
			return;
		}
		if(true !== o.success) {
			if(true === this.logFailure) {
				this.log(this.saveFailureText, o, response);
			}
			this.dirty = true;
		}
		else {
			Ext.each(options.queue, function(item) {
				if (item){
					var name = item[this.paramNames.name];
					var value = this.decodeValue(item[this.paramNames.value]);

					if(undefined === value || null === value) {
						Ext.ux.HttpProvider.superclass.clear.call(this, name);
					}
					else {
						// parent sets value and fires event
						Ext.ux.HttpProvider.superclass.set.call(this, name, value);
					}
				}
			}, this);
			if(false === this.dirty) {
				this.queue = [];
			}
			else {
				var i, j, found;
				for(i = 0; i < options.queue.length; i++) {
					found = false;
					for(j = 0; j < this.queue.length; j++) {
						if(options.queue[i].name === this.queue[j].name) {
							found = true;
							break;
						}
					}
					if(true === found && this.encodeValue(options.queue[i].value) === this.encodeValue(this.queue[j].value)) {
						delete(this.queue[j]);
					}
				}
			}
			if(true === this.logSuccess) {
				this.log(this.saveSuccessText, o, response);
			}
			this.fireEvent('savesuccess', this);
		}
	} // eo function onSaveSuccess
	// }}}
	// {{{
	
	,onSaveFailure:function(response, options) {
		if(true === this.logFailure) {
			this.log(this.saveFailureText, response);
		}
		if(this.started) {
			this.start();
		}
		this.dirty = true;
		this.fireEvent('savefailure', this);
	} // eo function onSaveFailure
	// }}}
	// {{{
	
	,onReadFailure:function(response, options) {
		if(true === this.logFailure) {
			this.log(this.readFailureText, response);
		}
		this.fireEvent('readfailure', this);

	} // eo function onReadFailure
	// }}}
	// {{{
	
	,onReadSuccess:function(response, options) {
		var o = {}, data;
		try {o = Ext.decode(response.responseText);}
		catch(e) {
			if(true === this.logFailure) {
				this.log(this.readFailureText, e, response);
			}
			return;
		}
		if(true !== o.success) {
			if(true === this.logFailure) {
				this.log(this.readFailureText, o, response);
			}
		}
		else {
			try {data = Ext.decode(o[this.paramNames.data]);}
			catch(ex) {
				if(true === this.logFailure) {
					this.log(this.dataErrorText, o, response);
				}
				return;
			}
			if(!(data instanceof Array) && true === this.logFailure) {
				this.log(this.dataErrorText, data, response);
				return;
			}
			Ext.each(data, function(item) {
				this.state[item[this.paramNames.name]] = this.decodeValue(item[this.paramNames.value]);
			}, this);
			this.queue = [];
			this.dirty = false;
			if(true === this.logSuccess) {
				this.log(this.readSuccessText, data, response);
			}
			this.fireEvent('readsuccess', this);
		}
	} // eo function onReadSuccess
	// }}}
	// {{{
	
	,readState:function() {
		var o = {
			 url:this.readUrl || this.url
			,method:this.method
			,scope:this
			,success:this.onReadSuccess
			,failure:this.onReadFailure
			,params:{}
		};

		var params = Ext.apply({}, this.readBaseParams);
		params[this.paramNames.id] = this.id;
		params[this.paramNames.user] = this.user;
		params[this.paramNames.session] = this.session;

		Ext.apply(o.params, params);
		Ext.Ajax.request(o);
	} // eo function readState
	// }}}
	// {{{
	
	,log:function() {
		if(console) {
			console.log.apply(console, arguments);
		}
	} // eo log
	// }}}

}); // eo extend

// eof

/// <reference path="..\VStudio\vswd-ext_2.2.js" />
gxui.Settings = Ext.extend(gxui.UserControl, {

	initialize: function() {
		gxui.Settings.superclass.initialize.call(this);

		this.Enable;
		this.Provider;
		this.SaveURL;
		//this.ReadURL;
		this.State;
	},

	// Databinding
	SetState: function(data) {
		this.State = data;
	},

	// Databinding
	GetState: function(data) {
		return this.State;
	},

	onRender: function() {
		var provider = null;
		if (gxui.CBoolean(this.Enable)) {
			if (this.Provider == gxui.Settings.StateProvider.HTTP) {
				if (this.SaveURL != "") {
					provider = new Ext.ux.HttpProvider({
						saveUrl: this.SaveURL,
						autoRead: false
						
					});
				}
			}
			else {
				if (this.Provider == gxui.Settings.StateProvider.Cookie) {
					provider = new Ext.state.CookieProvider({
						expires: new Date(new Date().getTime() + (1000 * 60 * 60 * 24 * 365)) //365 days
					})
				}
			}
		}
		else {
			// This is equivalent to removing the default provider set in gxui.js.
			provider = new Ext.state.Provider();
		}
		if (provider) {
			// Initialize state provider (required to be able to keep state in controls)
			Ext.state.Manager.setProvider(provider);
			if (this.Provider == gxui.Settings.StateProvider.HTTP) {
				Ext.state.Manager.getProvider().initState(this.State);
			}
			this.State = []; //Reset initial state to avoid innecessary traffic
		}
	},

	onDestroy: Ext.emptyFn

});

// Supported state providers
gxui.Settings.StateProvider = {
	Cookie: "Cookie",
	HTTP: "HTTP"
};

