/**
*    GXflow BPMN plugin
*	 Version 1.2
*    Copyright (c) 2019 Genexus.
*
*/

var GXflowBPMN = Class.create({

    initialize: function(x, y, w, h) {
        this.paper = Raphael(x, y, w, h);
    },

    pool : function(name, x, y, w, h){
        var pool = new GXflowBPMNPool(this.paper, name, x, y, w, h);
		pool.parent = this;
		return pool;
    },
	
    lane : function(name, x, y, w, h){
        var lane = new GXflowBPMNLane(this.paper, name, x, y, w, h);
		lane.parent = this;
		return lane;
    },
	
    event : function(type, id, name, x, y, w, h){
        var event = new GXflowBPMNEvent(this.paper, type, id, name, x, y, w, h);
        event.parent = this;
        return event;
    },

    eventType : { START_NONE : 0, START_TIMER : 1, START_SIGNAL : 2, START_CONDITIONAL : 3, START_MESSAGE : 4, START_MULTIPLE : 5,
        INTER_CANCEL_CATCH : 10, INTER_CANCEL_THROW : 11, INTER_COMPENSATION_CATCH : 12, INTER_COMPENSATION_THROW : 13,
        INTER_CONDITIONAL_CATCH : 14, INTER_ERROR_CATCH : 15, INTER_ERROR_THROW : 16, INTER_MESSAGE_CATCH : 17, INTER_MESSAGE_THROW : 18,
        INTER_MULTIPLE_CATCH : 19, INTER_MULTIPLE_THROW : 20, INTER_NONE : 21, INTER_SIGNAL_CATCH : 22, INTER_SIGNAL_THROW : 23,
        INTER_TIMER_CATCH: 24, INTER_LINK_CATCH: 25, INTER_LINK_THROW: 26, END_NONE : 30, END_CANCEL : 31, END_COMPENSATION : 32,
        END_ERROR : 33, END_MESSAGE : 34, END_MULTIPLE : 35, END_SIGNAL : 36, END_TERMINATE : 37
    },

    gateway : function(type, id, name, x, y, w, h){
        var gateway = new GXflowBPMNGateway(this.paper, type, id, name, x, y, w, h);
		gateway.parent = this;
		return gateway;
    },    

    gatewayType: { INCLUSIVE : 0, EXCLUSIVE : 1, PARALLEL : 2, EVENT: 3, COMPLEX : 4},

    flow : function(type, name, array){
        var arrow = new GXflowBPMNFlow(this.paper, type, name, array);
		arrow.parent = this;
		return arrow;
    },

    flowType : {SEQUENCE : 0, DEFAULT : 1, CONDITION : 2, MESSAGE : 3, ASSOCIATION : 4},

    activity : function(type, id, name, x, y, w, h, info, loopType, expanded){
        var activity = new GXflowBPMNActivity(this.paper, type, id, name, x, y, w, h, info, loopType, expanded);
		activity.parent = this;
		return activity;
    },
	
    activityType : {NONE: 0, USER_TASK : 1, SCRIPT_TASK : 2, SUBPROCESS : 3, EMBEDDED_SUBPROCESS : 4},
	
    artifact : function(type, name, x, y, w, h){
        var artifact = new GXflowBPMNArtifact(this.paper, type, name, x, y, w, h);
		artifact.parent = this;
		return artifact;
    },
	
    artifactType : {ANNOTATION: 0, GROUP: 1},
	
	loopType : {NONE: 0, STANDARD : 1, MULTIINSTANCE_SEQUENTIAL : 2, MULTINSTANCE_PARALLEL : 3},

	setAnimation: function(array){
		this.animationTasks = array;
		this.currentAnimation = 0;
	},
	
	startAnimation: function(speed, callback, scope){
        var speed = speed || 500;
		var timer = speed;
        for (var i=this.currentAnimation; i < this.animationTasks.length; i++) {
			var t = this.animationTasks[i];
			t.animate(timer, speed*2);			
            timer += speed*3;
        }
		setTimeoutObj(scope, callback, timer);
	},

	stopAnimation: function(){
		this.pauseAnimation();
		this.currentAnimation = 0;
	},
	
	pauseAnimation: function(){
        for (var i=this.currentAnimation; i < this.animationTasks.length; i++) {
            var t = this.animationTasks[i];
			t.stopAnimation();
		}
	},	
		
	resetAnimation: function(){		
        for (var i=0; i < this.animationTasks.length; i++) {
            var t = this.animationTasks[i];
			t.resetAnimation();
		}
		this.currentAnimation = 0;
	}	

});

var GXflowBPMNBase = Class.create({

    initialize: function(paper, type, x, y, w, h){
        this.paper = paper;
		this.type = type;
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    },

    show : function(){
        this.figure.show();
    },

    hide : function(){
        this.figure.hide();
    },
	
	createShadow : function(){	
		var figure;
		//figure = f.glow({"width": "1", "opacity":"0.2", "color":"#000000"});		
		if (this.baseType == "ACTIVITY"){
			figure = this.parent.paper.rect(this.x, this.y, this.w, this.h, 10);		
			//figure.attr(this.getAttr(this.parent.type));
		}
		else {
			var r = this.w/2;
			figure = this.parent.paper.circle(this.x + r, this.y + r, r);		
			//figure.attr({"fill" : "", "fill-opacity": "0.3", "stroke-width" : "0.5"});	
		}		
		figure.attr({"fill" : "0-#fff-#c0c0c0", "fill-opacity": 0, "stroke-width" : "0.5", "stroke-dasharray" : "--"});
		figure.scale(1.18, 1.18);
		figure.toBack();
		return figure;
	},	
	
	zoomInTimeout : function(){
		this.parent.currentAnimation += 1;
		var f = this.figure;
		f.scale(1.2, 1.2);
		if (!this.visitedFigure)
			this.visitedFigure = this.createShadow();
		this.visitedFigure.show();
	},
	
    zoomIn : function(timer){
		this.zoomInTimer = setTimeoutObj(this, this.zoomInTimeout, timer);
    },	
	
	zoomOutTimeout : function(){
		var f = this.figure;
		f.scale(1/1.2, 1/1.2);
	},	

    zoomOut : function(timer){
		this.zoomOutTimer = setTimeoutObj(this, this.zoomOutTimeout, timer);
    },

	animate : function(start, lapse){
		this.zoomIn(start);
		this.zoomOut(start + lapse);
	},
	
    stopAnimation : function(){
		if (this.zoomInTimer)
			clearTimeout(this.zoomInTimer);
		if (this.zoomOutTimer)
			clearTimeout(this.zoomOutTimer);			
    },
	
    resetAnimation : function(){
		if (this.visitedFigure)
			this.visitedFigure.hide();
    }
	
});

var GXflowBPMNPool = Class.create(GXflowBPMNBase, {

    initialize: function(paper, name, x, y, w, h) {

		paper.rect(x, y, w, h, 0);	
        var text = paper.text(x + 20, y + h/2, name);
		text.attr({"font-family" : "arial", "font-size" : "13"});		
		text.rotate(-90);

    }
	
});

var GXflowBPMNLane = Class.create(GXflowBPMNBase, {

    initialize: function(paper, name, x, y, w, h) {

		paper.rect(x, y, w, h, 0);	
		paper.rect(x, y, 20,  h, 0);
        var text = paper.text(x + 10, y + h/2, name);
		text.attr({"font-family" : "arial", "font-size" : "13"});		
		text.rotate(-90);
		
    }
	
});

var GXflowBPMNArtifact = Class.create(GXflowBPMNBase, {

    initialize: function(paper, type, name, x, y, w, h) {

		var rect = paper.rect(x, y, w, h, 0);		
		var text;
		
		switch (type) {
            case 0:
				var text = paper.text(x + w/2, y + h/2, name);
				rect.attr("fill", "0-#fff-#eee");
				rect.attr("stroke", "#fff");
				var path = paper.path("M" + (x+15) + " " + y + "L" + x + " " + y + "L" + x + " " + (y+h) + "L" + (x+15) + " " + (y+h));
				break;
			case 1:
				var text = paper.text(x + w/2, y + 12, name);
				rect.attr("stroke-dasharray", "-.");
				rect.attr("stroke-width", 2);
				break;	
		}
		text.attr({"font-family" : "arial", "font-size" : "11"});
    }
	
});

var GXflowBPMNEvent = Class.create(GXflowBPMNBase, {

    initialize: function($super, paper, type, id, name, x, y, w, h) {

        //this.paper = paper;
        //w = w || 30;
        //h = h || 30;
		
		$super(paper, type, x, y, w || 30, h || 30);
		this.baseType = "EVENT";

        switch (type) {
            case 0:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_start_none.png", x, y, w, h);
                 break
            case 1:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_start_timer.png", x, y, w, h);
                 break
            case 2:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_start_signal.png", x, y, w, h);
                 break
            case 3:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_start_conditional.png", x, y, w, h);
                 break
            case 4:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_start_message.png", x, y, w, h);
                 break
            case 5:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_start_multiple.png", x, y, w, h);
                 break
            case 10:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_inter_cancel_catch.png", x, y, w, h);
                 break
            case 11:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_inter_cancel_throw.png", x, y, w, h);
                 break
            case 12:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_inter_compensation_catch.png", x, y, w, h);
                 break
            case 13:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_inter_compensation_throw.png", x, y, w, h);
                 break
            case 14:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_inter_conditional.png", x, y, w, h);
                 break
            case 15:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_inter_error_catch.png", x, y, w, h);
                 break
            case 16:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_inter_error_throw.png", x, y, w, h);
                 break
            case 17:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_inter_message_catch.png", x, y, w, h);
                 break
            case 18:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_inter_message_throw.png", x, y, w, h);
                 break
            case 19:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_inter_multiple_catch.png", x, y, w, h);
                 break
            case 20:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_inter_multiple_throw.png", x, y, w, h);
                 break
            case 21:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_inter_none.png", x, y, w, h);
                 break
            case 22:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_inter_signal_catch.png", x, y, w, h);
                 break
            case 23:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_inter_signal_throw.png", x, y, w, h);
                 break
            case 24:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_inter_timer_catch.png", x, y, w, h);
                 break
            case 25:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_inter_link_catch.png", x, y, w, h);
                 break
            case 26:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_inter_link_throw.png", x, y, w, h);
                 break				 
            case 30:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_end_none.png", x, y, w, h);
                 break
            case 31:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_end_cancel.png", x, y, w, h);
                 break
            case 32:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_end_compensation.png", x, y, w, h);
                 break
            case 33:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_end_error.png", x, y, w, h);
                 break
            case 34:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_end_message.png", x, y, w, h);
                 break
            case 35:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_end_multiple.png", x, y, w, h);
                 break
            case 36:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_end_signal.png", x, y, w, h);
                 break
            case 37:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_event_end_terminate.png", x, y, w, h);
                 break
        }
		this.text = this.paper.text(x + (w/2), y + h + 5, name);
    }

});

var GXflowBPMNGateway = Class.create(GXflowBPMNBase, {

    initialize: function($super, paper, type, id, name, x, y, w, h) {

		/*
		this.paper = paper;
        w = w || 40;
        h = h || 40;
		*/
		
		$super(paper, type, x, y, w || 40, h || 40);

        switch (type) {
            case 0:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_gateway_inclusive.png", x, y, w, h);
                 break
            case 1:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_gateway_exclusive.png", x, y, w, h);
                 break
            case 2:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_gateway_parallel.png", x, y, w, h);
                 break
            case 3:
                 this.figure = this.paper.image(window.GXflowResourcesURL + "wf_grid_gateway_event.png", x, y, w, h);
                 break

        }
		this.text = this.paper.text(x + (w/2), y + h + 5, name);
    }

});

var GXflowBPMNFlow = Class.create(GXflowBPMNBase, {

    initialize: function(paper, type, name, array) {

        this.paper = paper;
		this.type = type;
		var path, figure, figure2;
		var set = this.paper.set();
		
		/*
		path = "M" + array[0].x + " " + array[0].y;
			
        for (var i=1; i<array.length-1; i++)
			path = path + "L" + array[i].x + " " + array[i].y;
		*/
		
		if (type == 3)
			array = moveCoordinate(array, 0, 8, false);		
		
        for (var i=0; i<array.length-2; i++){
			path = "M" + array[i].x + " " + array[i].y + "L" + array[i+1].x + " " + array[i+1].y;
			set.push(this.paper.path(path));
		}		

		//set.attr({"arrow-end" : "classic", "width" : "wide", "length" : "long"});						
		this.paper.arrowSet(set, type, array);

		//flowType : {SEQUENCE : 0, DEFAULT : 1, CONDITION : 2, MESSAGE : 3, ASSOCIATION : 4}
		
		switch (this.type) {
			case 0:
				set.attr({"stroke" : "black", "fill" : "black", "stroke-width" : "1"});	
				break;
			case 1:
				set.push(defaultFlow(this.paper, array));
				set.attr({"stroke" : "green", "fill" : "green", "stroke-width" : "1"});				
				break;
			case 2:		
				set.attr({"stroke" : "green", "fill" : "green", "stroke-width" : "1"});				
				break
			case 3:
				set.attr({"stroke-dasharray" : "- ", "stroke-width" : "0.8"});
				set[set.length-1].attr({"stroke-dasharray" : ""});
				array = moveCoordinate(array, 0, -4, false);	
				set.push(this.paper.circle(array[0].x, array[0].y, 4));				
				break
			case 4:
				set.attr("stroke-dasharray", ". ");
				//set.attr({"fill" : "white", "stroke-width" : "1"});				
				break
		}	
		
		set.push(flowText(this.paper, name, array));
	
		set.toBack();
        
    }

});

var GXflowBPMNActivity = Class.create(GXflowBPMNBase, {

    initialize: function($super, paper, type, id, name, x, y, w, h, info, loopType, expanded) {

		/*
        this.paper = paper;
		this.type = type;		
		this.x = x;
        this.y = y;
        this.w = w || 120;
        this.h = h || 50;
		*/		
		
		$super(paper, type, x, y, w || 120, h || 50);		
		this.baseType = "ACTIVITY";
		
        this.id = id;
        this.name = name;
		this.info = info;
        this.figure = this.paper.rect(x, y, w, h, 10);
		this.figure.attr(this.getAttr(this.type));
		
        this.text = this.paper.text(x + (w/2), y + h/2, name);
		this.text.attr({"font-family" : "arial", "font-size" : "11"});		
		wrapText(this.text, w-20);
		
		//activityType : {NONE: 0, USER_TASK : 1, SCRIPT_TASK : 2, SUBPROCESS : 3, EMBEDDED_SUBPROCESS : 4},
	
		switch (this.type) {
            case 1:
                this.icon = this.paper.image(window.GXflowResourcesURL + "wf_bpmn_taskuser.png", x + 5, y + 5, 16, 16);
                break
            case 2:
                this.icon = this.paper.image(window.GXflowResourcesURL + "wf_bpmn_taskscript.png", x + 5, y + 5, 16, 16);
                break
            case 3:
                this.icon = this.paper.image(window.GXflowResourcesURL + "wf_bpmn_reusable.png", x + 5, y + 5, 16, 16);
                break
			case 4:
				if (expanded){
					this.figure2 = this.paper.rect(x + 15, y + 25, w - 30, h - 50, 10);
					this.figure2.attr({"fill" : "white", "": 1, "stroke-width" : "0.5"});
					this.figure2.toBack();
					this.figure.toBack();
					this.text.attr({"y" : y + 15});
				}
				break			
        }	
		
		if (loopType)
			this.setLoop(loopType);
			
		if (this.type == 4) //embedded subprocess
			this.setExpanded(expanded);				
		
		if (this.info)
			this.setInfo(this.info);        
		
		this.figure.parent = this;
		this.text.parent = this;
		if (this.icon)
			this.icon.parent = this;
		if (this.loopIcon)
			this.loopIcon.parent = this;
		
		this.set = this.paper.set();
		this.set.push(this.figure, this.text, this.icon, this.loopIcon);
		this.set.mouseover(this.showInfo);
		this.set.mouseout(this.hideInfo);
		this.set.attr({"cursor" : "pointer"});
    },
	
	getAttr: function(type){
	
		switch (type) {
            case 0:
                 return {"fill" : "0-#fff-#c0c0c0", "fill-opacity": 1, "stroke-width" : "0.5"};
                 break		
            case 1:
                 return {"fill" : "0-#fff-#d6eb84", "fill-opacity": 1, "stroke-width" : "0.5"};
                 break
            case 2:
                 return {"fill" : "0-#fff-#a5c3f7", "fill-opacity": 1, "stroke-width" : "0.5"};
                 break
            case 3:
                 return {"fill" : "0-#fff-#f38572", "fill-opacity": 1, "stroke-width" : "0.5"};
                 break
            case 4:			
				//if expanded
				//	return {"fill" : "", "": 1, "stroke-width" : "0.5"};
				//else
					return {"fill" : "0-#fff-#f38572", "fill-opacity": 1, "stroke-width" : "0.5"};
                break
				
        }	
	},
	
	setLoop: function(loopType){
	
		//loopType : {NONE: 0, STANDARD : 1, MULTIINSTANCE_SEQUENTIAL : 2, MULTINSTANCE_PARALLEL : 3},
		
		var x = this.x + (this.w/2) - 8;
		var y = this.y + this.h - 18;

		switch (loopType) {
            case 1:
                this.loopIcon = this.paper.image(window.GXflowResourcesURL + "wf_bpmn_loop.png", x, y, 16, 16);
                break
            case 2:
                this.loopIcon = this.paper.image(window.GXflowResourcesURL + "wf_bpmn_multiple_instance.png", x, y, 16, 16);
				this.loopIcon.rotate(90);
                break
            case 3:
                this.loopIcon = this.paper.image(window.GXflowResourcesURL + "wf_bpmn_multiple_instance.png", x, y, 16, 16);				
                break				
        }		
	},
	
	setExpanded: function(expanded){
	
		var x = this.x + (this.w/2) - 8;
		var y = this.y + this.h - 21;	
	
		if (expanded)
			this.expandedIcon = this.paper.image(window.GXflowResourcesURL + "wf_bpmn_subprocess_minus.png", x, y, 16, 16);
		else
			this.expandedIcon = this.paper.image(window.GXflowResourcesURL + "wf_bpmn_subprocess_plus.png", x, y, 16, 16);			
	},	

    setInfo: function(info){
        this.info = this.paper.set();
        var x = this.x + 10;
        var y = this.y + this.h + 5;
        var rec = this.paper.rect(x, y, 150, 100, 10);
        rec.attr(this.getAttr(this.type));
        var ttxt = this.paper.text(x+10, y+50, info);
		ttxt.attr({"text-anchor": "start"});
        this.info.push(rec, ttxt);
        this.info.hide();
    },

    showInfo: function(){
		if (this.parent.info){
			this.parent.info.toFront();//this.info.toFront();
			this.parent.info.show();//this.info.show();
		}
    },

    hideInfo: function(){
		if (this.parent.info)
			this.parent.info.hide();//this.info.hide();
    }

});

var GXflowBPMNInfo = Class.create({

    initialize: function() {
        this.initInfo();
    },

    initInfo : function () {
        this.info = paper.set();
        var t = paper.rect(0, 0, 150, 100, 10);
        t.attr({"fill" : "90-#36f:5-#fff:95", "fill-opacity": 1});
        this.infoTxt = paper.text(100, 100, "Task Info");
        this.info.push(t, this.infoTxt);
        this.info.hide();
    },

    show : function(){
        var x = this.info.attr("x") + 10;
        var y = this.info.attr("y") + 60;
        this.info.attr({"x" : x, "y" : y});
        this.info.show();
    },

    hide : function(){
        this.info.hide();
     }

});

(function() {

    /**
    * Create a set that will contain a path for the arrow line and a path for the arrow head.
    */
    Raphael.fn.arrowSet = function (set, type, array) {
		var paper = this;
		var r = 5;
		var x1, y1, x2, y2;
		
		if (type < 4) //flowType : {SEQUENCE : 0, DEFAULT : 1, CONDITION : 2, MESSAGE : 3, ASSOCIATION : 4}		
			array = moveCoordinate(array, array.length-2, 10, true);
			
		x1 = array[array.length-2].x;
		y1 = array[array.length-2].y;
		x2 = array[array.length-1].x;
		y2 = array[array.length-1].y;			

		set.push(paper.path(line(x1, y1, x2, y2)));			
		set.push(paper.path(triangle(x2, y2 - (r / 2), r)).rotate(arrowHeadAngle(x1, y1, x2, y2), x2, y2));			
				
        return set;

        /**
        * Calculate angle to rotate arrow head by
        */
        function arrowHeadAngle (x1, y1, x2, y2) {
            var angle = Math.atan2(x1 - x2, y2 - y1);
            angle = ((angle / (2 * Math.PI)) * 360) + 180;
            return angle;
        }

        /**
        * String that represents a line path on canvas
        */
        function line (x1, y1, x2, y2) {
            return ["M", x1, y1, "L", x2, y2];
        }

        /**
        * String that represents a triangle path on canvas
        */
        function triangle (cx, cy, r) {
            r *= 1.75;
            return "M".concat(cx, ",", cy, "m0-", r * .58, "l", r * .5, ",", r * .87, "-", r, ",0z");
        }
    };
})();

//Utils
function setTimeoutObj(o, f, t) {

	if (f !== undefined){
		return setTimeout(function() {
			f.call(o);
		}, t);
	}

}

function wrapText(text, maxWidth){

	var tempText = "";
	var words = text.attrs.text.split(" ");
	
	for (var i=0; i<words.length; i++) {
	  text.attr("text", tempText + " " + words[i]);
	  if (text.getBBox().width > maxWidth) {
		tempText += "\n" + words[i];
	  } else {
		tempText += " " + words[i];
	  }
	}
	text.attr("text", tempText.substr(1));
}

function moveCoordinate(array, index, d, end){

	var x1, y1, x2, y2;

	if (end){
		x1 = array[index].x;
		y1 = array[index].y;
		x2 = array[index+1].x;
		y2 = array[index+1].y;
	}
	else{
		x2 = array[index].x;
		y2 = array[index].y;
		x1 = array[index+1].x;
		y1 = array[index+1].y;
	}
	
	if (x1 == x2)
		if (y1 < y2)
			y2 = y2 - d;
		else
			y2 = y2 + d;

	if (y1 == y2)
		if (x1 < x2)
			x2 = x2 - d;
		else
			x2 = x2 + d;	
	
	if (end){
		array[index].x = x1;
		array[index].y = y1;
		array[index+1].x = x2;
		array[index+1].y = y2;
	}
	else{
		array[index].x = x2;
		array[index].y = y2;
		array[index+1].x = x1;
		array[index+1].y = y1;	
	}
	
	return array;
			
}

function defaultFlow(paper, array) {

	x1 = array[0].x;
	y1 = array[0].y;
	
	var array = moveCoordinate(array, 0, 15, false);	
	
	x2 = array[0].x;
	y2 = array[0].y;
	
	var angle = Math.atan2(x2 - x1, y2 - y1) + 50;
	
	var path = paper.path("M" + x1 + ", " + y1 + "L" + x2 + ", " + y2);
	path.rotate(angle);
	return path;
}

function flowText(paper, name, array) {

	var text, x, y;
	var up = 10;
	
	var array2 = selectLine(array);
	
	var x1 = array2[0].x;
	var y1 = array2[0].y;
	var x2 = array2[1].x;
	var y2 = array2[1].y;
	
	if (x1 == x2){
		x = x1;
		y = (y1 + y2)/2;
	}
	else{
		x = (x1 + x2)/2
		y = y1 - up;
	}
	
	text = paper.text(x, y, name);	
	return text;
	
	function selectLine(array){
	
		var min = 100;
		
		var x1 = array[0].x;
		var y1 = array[0].y;
		var x2 = array[1].x;
		var y2 = array[1].y;		

		if (array.length > 3)
			array.splice(3, array.length-3);
		
		if (array.length == 3){
		
			var x3 = array[2].x;
			var y3 = array[2].y;
			
			if (x1 == x2){
				if (Math.abs(x2 - x3) >= min)
					array.splice(0, 1);
				else
					array.splice(2, 1);
			}
			else{
				if (Math.abs(x1 - x2) >= min)
					array.splice(2, 1);				
				else
					array.splice(0, 1);
			}				
		}
		return array;
	}
	
}