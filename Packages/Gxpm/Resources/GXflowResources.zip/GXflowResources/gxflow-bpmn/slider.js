Ext.onReady(function(){

	var slider = new Ext.Slider({
		renderTo: Ext.getBody(), //'slider',
		width: 200,
		value: 50,
		increment: 10,
		minValue: 0,
		maxValue: 100
	});

});