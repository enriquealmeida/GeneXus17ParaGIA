/**
* @module inputex-datatable-group
*/
YUI.add("inputex-datatable-group", function (Y) {

    var lang = Y.Lang,
       inputEx = Y.inputEx;

    /**
    * Handle a DatatableGroup of fields
    * @class inputEx.DatatableGroup
    * @extends inputEx.Field
    * @constructor
    * @param {Object} options The following options are added for Groups and subclasses:
    * <ul>
    *   <li>fields: Array of input fields declared like { label: 'Enter the value:' , type: 'text' or fieldClass: inputEx.Field, optional: true/false, ... }</li>
    *   <li>legend: The legend for the fieldset (default is an empty string)</li>
    *   <li>flatten:</li>
    * </ul>
    */
    inputEx.DatatableGroup = function (options) {
        inputEx.DatatableGroup.superclass.constructor.call(this, options);

        // Run default field interactions (if setValue has not been called before)
        if (!this.options.value) {
            this.runFieldsInteractions();
        }
    };
    Y.extend(inputEx.DatatableGroup, inputEx.Field, {

        /**
        * Adds some options: legend, collapsible, fields...
        * @method setOptions
        * @param {Object} options Options object as passed to the constructor
        */
        setOptions: function (options) {

            inputEx.DatatableGroup.superclass.setOptions.call(this, options);

            this.options.className = options.className || 'yui3-widget yui3-datatable yui3-datatable-sortable';

            this.options.fields = options.fields;

            this.options.flatten = options.flatten;

            this.options.legend = options.legend || '';

            this.options.allowInsert = lang.isUndefined(options.allowInsert) ? false : options.allowInsert;
            this.options.allowDelete = lang.isUndefined(options.allowDelete) ? false : options.allowDelete;
            this.options.allowUpdate = lang.isUndefined(options.allowUpdate) ? false : options.allowUpdate;
            this.options.showRowNumber = lang.isUndefined(options.shownumber) ? false : options.shownumber;
            this.options.showNumberLabel = lang.isUndefined(options.shownumberlabel) ? "#" : options.shownumberlabel;

            if (this.options.allowDelete && this.options.allowUpdate) {
                this.options.extraColumnsCount = 2;
            } else if (this.options.allowDelete || this.options.allowUpdate) {
                this.options.extraColumnsCount = 1;
            } else {
                this.options.extraColumnsCount = 0;
            }
            this.options.BtnPos = lang.isUndefined(options.btnpos) ? "R" : options.btnpos;

            this.options.disabled = lang.isUndefined(options.disabled) ? false : options.disabled;

            // Array containing the list of the field instances
            this.inputs = [];

            // Associative array containing the field instances by names
            this.inputsNames = {};


            // Start Change for builder.
            this.options.editproperty = options.editproperty;
            this.options.component = options.component;
            this.options.action = options.action;
            // End Change for builder.

            this.options.datasource = options.datasource;
            this.datos = null;

            // Start Change for floating options.
            this.options.float = options.float;
            this.options.width = options.width;
            // End Change for floating options.


            this.actionsToAdd = [];
        },

        /**
        * Render the DatatableGroup
        * @method renderComponent
        */
        renderComponent: function () {

            // Create the div wrapper for this DatatableGroup
            this.divEl = inputEx.cn('div', { className: this.options.className });
            if (this.options.id) {
                this.divEl.id = this.options.id;
            } else {
                this.divEl.id = Y.guid();
            }
            this.wrapEl = this.divEl;

            if (gx.popup.ext.ie5) { //Para IE funciona mejor la version vieja de la API de eventos de YUI.
                Y.YUI2.util.Event.onAvailable(this.wrapEl.id, this.buildDataTable, this, true, false);
            } else {
                Y.on('available', this.buildDataTable, "#" + this.wrapEl.id, this);
            }
        },


        /**
        * Send the datasource request
        * @method sendDataRequest
        */
        sendDataRequest: function (oRequest) {
            if (this.myDataTable && this.myDataTable.datasource &&
                this.myDataTable.datasource.load) {
                this.myDataTable.datasource.load();
            }
        },


        /**
        * Build the YUI DataTable
        */
        buildDataTable: function () {
            var varColumns = this.fieldNames("edit");

            var myDataTable = new Y.DataTable({
                editing: 'formeditor',
                columns: varColumns,
                data: [],
                caption: this.options.legend,
                summary: this.options.legend
            });
            this.myDataTable = myDataTable;

            myDataTable.plug(Y.Plugin.DataTableDataSource, { datasource: this.options.datasource });

            myDataTable.render("#" + this.divEl.id).showMessage('loadingMessage');

            var grpFields = this.fieldVisible();

            var inputEx = {
                type: "group",
                fields: grpFields
            }
            var pluginConfig = {
                inputEx: inputEx,
                disableAddFunc: !this.options.allowInsert,
                disableModifyFunc: !this.options.allowUpdate,
                disableDeleteFunc: !this.options.allowDelete,
                btnPosition: this.options.BtnPos,
                ParentOptions: this.options
            };
            myDataTable.plug(Y.inputEx.Plugin.InputExDataTable, pluginConfig);

            // Load the data into the table
            myDataTable.datasource.load();

            this.tabla = myDataTable;

            var varGroup = myDataTable.InputExDataTable.get("panel").get("field");
            this.inputs = varGroup.inputs;
            this.inputsNames = varGroup.inputsNames;

            for (var i = 0; i < this.actionsToAdd.length; i++) {
                var actionToPush = this.actionsToAdd[i];

                var field = this.getFieldByName(actionToPush.FieldId);
                if (field) {
                    field.on('updated', actionToPush.Function);
                    actionToPush.ChildComponent.Fields[actionToPush.Mode] = field;
                }
            }

            // Hidden no funciona en YUI3, para eso tengo que borrar el campo del datatable
            /*for (var x = 0; x < varColumns.length; x++) {
            if (varColumns[x].hidden) myDataTable.getColumn(varColumns[x].key).addClass("hide");
            }*/

            if (gx.popup.ispopup()) {
                var wdth = DynamicFormInstance.GetMetadata("popup_width");
                var hght = DynamicFormInstance.GetMetadata("popup_height");
                wdth = (wdth == "") ? 0 : parseInt(wdth);
                hght = (hght == "") ? 0 : parseInt(hght);
                if (hght != 0 || wdth != 0) {
                    DynamicFormInstance.PDFHeight = hght;
                    DynamicFormInstance.PDFWidth = wdth;
                    DynamicForm.Utils.popup.resize(gx.popup.getPopup().id, wdth, hght);
                    DynamicForm.Utils.popup.move(gx.popup.getPopup().id, -1, -1);
                } else {
                    if (hght == 0) {
                        hght = this.windowHeight(document);
                        if (screen.availHeight < hght) hght = screen.availHeight;
                    }
                    if (wdth == 0) {
                        wdth = this.windowWidth(document);
                        if (screen.availWidth < wdth) wdth = screen.availWidth;
                    }
                    DynamicFormInstance.PDFHeight = hght;
                    DynamicFormInstance.PDFWidth = wdth;
                    DynamicForm.Utils.popup.autoResizePopup();
                }
            } else {
                DynamicFormInstance.PDFHeight = DynamicForm.Utils.popup.windowHeight(document);
                DynamicFormInstance.PDFWidth = DynamicForm.Utils.popup.windowWidth(document);
            }
            DynamicForm.LibraryMgr.initializeUploads();
            // ejecutar reglas dependientes de la grilla
            DynamicForm.Behavior.runDependentOfComponent(this.options.component.Id);
            //
        },

        fieldVisible: function (mode) {
            if (!mode || mode != "")
                mode = "edit";
            var fieldsResult = [];
            if (this.options && this.options.fields) {
                var fields = this.options.fields
                for (var i = 0; i < fields.length; i++) {
                    var campo = fields[i];
                    if (campo.type == "combine") {
                        fields = DynamicForm.Utils.mergeArrays(fields, i, campo.fields)
                        //fields = fields.concat(campo.fields);
                    }
                    if (DynamicForm.Utils.text.equalsIgnoreCase(campo.mode, campo.component.Mode) && campo.name.substring(0, 11) != "description") {
                        fieldsResult.push(campo);
                    }
                }
            }
            return fieldsResult;
        },

        hasDescription: function (fieldName) {
            if (this.options && this.options.fields) {
                for (var i = 0; i < this.options.fields.length; i++) {
                    var campo = this.options.fields[i];
                    if (DynamicForm.Utils.text.equalsIgnoreCase(campo.name, "description_" + fieldName)) {
                        return true;
                    }
                }
            }
            return false;
        },

        fieldNames: function (mode) {
            if (!mode || mode != "") mode = "edit";
            var columnsResult = [];
            if (this.options && this.options.fields) {
                var fields = this.options.fields;
                var columnToPush = {
                    key: "description_idRow",
                    label: this.options.showNumberLabel,
                    execForm: false,
                    formatter: function (o) {
                        var result = "";
                        if (!lang.isUndefined(o.rowIndex)) {
                            result = "" + (o.rowIndex + 1);
                        }
                        return result;
                    },
                    allowHTML: true
                };
                if (this.options.showRowNumber) columnsResult.push(columnToPush);
                for (var i = 0; i < fields.length; i++) {
                    var campo = fields[i];
                    if (campo.type == "combine") {
                        fields = DynamicForm.Utils.mergeArrays(fields, i, campo.fields)
                        //fields = fields.concat(campo.fields);
                    }
                    if (DynamicForm.Utils.text.equalsIgnoreCase(campo.mode, campo.component.Mode) && campo.name.indexOf("--promptImg--") == -1) {
                        var colName = campo.legend;
                        if (colName == '') {
                            colName = '  ';
                        }
                        var columnToPush = {
                            key: campo.name,
                            label: colName,
                            execForm: true
                        };
                        if (DynamicForm.Utils.text.equalsIgnoreCase(campo.type, "datetime")) {
                            columnToPush.formatter = function (o) {
                                var result = DynamicForm.Utils.dates.dateTimeToServer(o.value);
                                if (result == '' && o.value) {
                                    result = o.value;
                                }
                                return result;
                            };
                            columnToPush.allowHTML = true;
                        } else if (DynamicForm.Utils.text.equalsIgnoreCase(campo.type, "date") ||
                            DynamicForm.Utils.text.equalsIgnoreCase(campo.type, "datepicker")) {
                            columnToPush.formatter = function (o) {
                                var result = DynamicForm.Utils.dates.dateToServer(o.value);
                                if (result == '' && o.value) {
                                    result = o.value;
                                }
                                return result;
                            };
                            columnToPush.allowHTML = true;
                        } else if (DynamicForm.Utils.text.equalsIgnoreCase(campo.type, "boolean")) {
                            columnToPush.formatter = '<input type="checkbox" checked/>';
                            columnToPush.emptyCellValue = '<input type="checkbox"/>';
                            columnToPush.allowHTML = true;
                        } else if (DynamicForm.Utils.text.equalsIgnoreCase(campo.type, "image")) {
                            columnToPush.formatter = '<img src="{value}" height="42px" width="42px">';
                            columnToPush.allowHTML = true;
                        } else if (DynamicForm.Utils.text.equalsIgnoreCase(campo.type, "color")) {
                            columnToPush.formatter = '<div style="width:15px;height:15px;background-color:{value};"></div>';
                            columnToPush.allowHTML = true;
                        } else if (DynamicForm.Utils.text.equalsIgnoreCase(campo.type, "file")) {
                            columnToPush.formatter = function (o) {
                                var result = "";
                                if (o.value) {
                                    if (o.value.indexOf(".") >= 0) {
                                        var frminsid = (campo.component.MetadataMap.frminsid ? campo.component.MetadataMap.frminsid : campo.frminsid);
                                        result = DynamicForm.Utils.getUrl("adynformdownloadshandler") + "?" + frminsid + "," + o.column.key + "_" + o.rowIndex;
                                        result = '<a href="' + result + '" target="_blank">' + o.value + '</a>'
                                    } else {
                                        result = o.value;
                                    }
                                }
                                return result;
                            };
                            columnToPush.allowHTML = true;
                            columnToPush.execForm = false;
                        } else if (DynamicForm.Utils.text.equalsIgnoreCase(campo.type, "uneditable")) {
                            if (DynamicForm.Utils.text.equalsIgnoreCase(campo.component.FieldTypes.edit, "upload")) {
                                columnToPush.formatter = function (o) {
                                    var result = "";
                                    if (o.value) {
                                        if (o.value.indexOf(".") >= 0) {
                                            var frminsid = (campo.component.MetadataMap.frminsid ? campo.component.MetadataMap.frminsid : campo.frminsid);
                                            result = DynamicForm.Utils.getUrl("adynformdownloadshandler") + "?" + frminsid + "," + o.column.key + "_" + o.rowIndex;
                                            result = '<a href="' + result + '" target="_blank">' + o.value + '</a>'
                                        } else {
                                            result = o.value;
                                        }
                                    }
                                    return result;
                                };
                                columnToPush.allowHTML = true;
                                columnToPush.execForm = false;
                            }
                        }


                        if (this.hasDescription(campo.name)) {
                            columnToPush.execForm = false;
                            columnToPush.formatter = function (o) { return ""; };
                            columnToPush.className = "hide";
                            if (!gx.popup.ext.ie5) eval('columnToPush.class = "hide"');
                            columnToPush.label = ' ';
                            columnToPush.allowHTML = true;
                        }

                        columnsResult.push(columnToPush);
                    }
                }
            }
            return columnsResult;
        },

        /**
        * Return an object with all the values of the fields
        */
        getValue: function () {
            var o = new Object();

            if (this.tabla) {
                var modelList = this.tabla.get("data");
                var columnsList = this.tabla.get("columns");

                //Recorro las filas

                for (var i = 0; i < modelList.size(); i++) {
                    var recordAttrs = modelList.item(i).getAttrs();

                    o[i] = new Object();
                    //Recorro las columnas
                    var colInicial = 0;
                    if (this.options.showRowNumber) colInicial = 1;
                    if (this.options.BtnPos == "L") colInicial = colInicial + this.options.extraColumnsCount;

                    var colFinal = columnsList.length;
                    if (this.options.BtnPos != "L") colFinal = columnsList.length - this.options.extraColumnsCount;
                    for (var j = colInicial; j < colFinal; j++) {
                        var nam = columnsList[j].key;
                        // Los campos de tipo descripci�n son solo para mostrar (no son campos reales).
                        if (nam.indexOf("description_") == -1 && nam.indexOf("--promptImg--") == -1) {
                            var valor = recordAttrs[nam];
                            // Los campos "hidden" estan marcados por usar un campo descripcion.
                            if (columnsList[j].formatter && columnsList[j].execForm) {
                                valor = columnsList[j].formatter({ value: valor, name: nam });
                            }
                            o[i][nam] = valor;
                        }
                    }
                }
            }

            return o;
        },

        /**
        * Return the sub-field instance by its name property
        * @param {String} fieldName The name property
        */
        getFieldByName: function (fieldName) {
            if (!this.inputsNames.hasOwnProperty(fieldName)) {
                return null;
            }
            return this.inputsNames[fieldName];
        },

        /**
        * Return the sub-field instance by its name property
        * @param {String} fieldName The name property
        */
        pushActionToAdd: function (actionToPush) {
            this.actionsToAdd.push(actionToPush);
        },

        /**
        * Run an action (for interactions)
        * @method runAction
        * @param {Object} action inputEx action object
        * @param {Any} triggerValue The value that triggered the interaction
        */
        runAction: function (action, triggerValue) {
            var field = this.getFieldByName(action.name);
            if (lang.isFunction(field[action.action])) {
                field[action.action].call(field);
            }
            else if (lang.isFunction(action.action)) {
                action.action.call(field, triggerValue);
            }
            else {
                throw new Error("action " + action.action + " is not a valid action for field " + action.name);
            }
        },

        /**
        * Run the interactions for the given field instance
        * @method runInteractions
        * @param {inputEx.Field} fieldInstance Field that just changed
        * @param {Any} fieldValue Field value
        */
        runInteractions: function (fieldInstance, fieldValue) {

            var index = inputEx.indexOf(fieldInstance, this.inputs);
            var fieldConfig = this.options.fields[index];

            // Fix because we are not using interactions and we are doing a builder.
            if (lang.isUndefined(fieldConfig) || lang.isUndefined(fieldConfig.interactions)) return;

            // Let's run the interactions !
            var interactions = fieldConfig.interactions;
            for (var i = 0; i < interactions.length; i++) {
                var interaction = interactions[i];
                if (interaction.valueTrigger === fieldValue) {
                    for (var j = 0; j < interaction.actions.length; j++) {
                        this.runAction(interaction.actions[j], fieldValue);
                    }
                }
            }

        },

        validate: function () {
            return true;
        },
        /**
        * Run the interactions for all fields
        * @method runFieldsInteractions
        */
        runFieldsInteractions: function () {
            if (this.hasInteractions) {
                for (var i = 0; i < this.inputs.length; i++) {
                    this.runInteractions(this.inputs[i], this.inputs[i].getValue());
                }
            }
        }
    });


    // Register this class as "DatatableGroup" type
    inputEx.registerType("datatable", inputEx.DatatableGroup, [{
        type: "string",
        inputParams: {
            label: "Name",
            name: "name",
            value: ''
        }
    }, {
        type: 'string',
        inputParams: {
            label: 'Legend',
            name: 'legend'
        }
    }, {
        type: 'boolean',
        inputParams: {
            label: 'AllowInsert',
            name: 'allowInsert',
            value: false
        }
    }, {
        type: 'boolean',
        inputParams: {
            label: 'AllowUpdate',
            name: 'allowUpdate',
            value: false
        }
    }, {
        type: 'boolean',
        inputParams: {
            label: 'AllowDelete',
            name: 'allowDelete',
            value: false
        }
    },
    {
        type: 'boolean',
        inputParams: {
            label: 'ShowNumber',
            name: 'shownumber',
            value: false
        }
    }], true);


}, '3.1.0', {
    requires: ["inputex-datatable"]
});
