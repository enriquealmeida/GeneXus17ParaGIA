YUI.add("lang/inputex_es", function (a) {
	a.Intl.add("inputex", "es", {
		required : "Este campo es obligatorio",
		invalid : "Este campo no es válido",
		valid : "Este campo es válido",
		invalidEmail : "Correo electrónico no válido, ej: tu.nombre@correo.es",
		selectColor : "Selecciona un color:",
		invalidPassword : ["La contraseña debe contener al menos ", "numeros o letras"],
		invalidPasswordConfirmation : "las contraseñas son diferentes!",
		passwordStrength : "La contraseña es demasiado débil",
		capslockWarning : "Atención: bloqueo de mayúsculas activado",
		invalidDate : "Fecha no válida, ej: 25/01/2007",
		defaultDateFormat : "d/m/Y",
		shortMonths : ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"],
		months : ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"],
		weekdays1char : ["D", "L", "M", "X", "J", "V", "S"],
		shortWeekdays : ["Do", "Lu", "Ma", "Mi", "Ju", "Vi", "Sa"],
		selectMonth : "- Seleccione un mes -",
		dayTypeInvite : "Día",
		monthTypeInvite : "Mes",
		yearTypeInvite : "Año",
		cancelEditor : "Cancelar",
		okEditor : "Aceptar",
		defaultCalendarOpts : {
			navigator : {
				strings : {
					month : "Seleccione un mes",
					year : "Introduzca un año",
					submit : "Aceptar",
					cancel : "Cancelar",
					invalidYear : "Año no válido"
				}
			},
			start_weekday : 1
		},
		stringTooShort : ["Este campo debe contener al menos ", " caracteres (letras o números)"],
		stringTooLong : ["Este campo debe contener como mucho ", " caracteres (letras o números)"],
		ajaxWait : "Enviando...",
		menuTypeInvite : "Haga click aquí para seleccionar",
		listAddLink : "Añadir",
		listRemoveLink : "Eliminar",
		saveText : "Salvar",
		cancelText : "Cancelar",
		modifyText : "Modificar",
		deleteText : "Eliminar",
		insertItemText : "Insertar",
		confirmDeletion : "¿Está seguro que desea borrar?",
		timeUnits : {
			SECOND : "segundos",
			MINUTE : "minutos",
			HOUR : "horas",
			DAY : "días",
			MONTH : "meses",
			YEAR : "años"

        },
        didYouMean: "Quizás quiso decir: ",
        disposableEmail : "Dirección de correo electrónico desechable no se permite con dominio: ",
        emptyInPlaceEdit : "(haga clic para editar)",
        invalidIPv4 : "Dirección IPv4 invalida, ej.: 192.168.0.1",
        invalidUrl : "URLinvalida, ej.: http://www.test.com",
        stringLoading : "Comprobando si está disponible ...",
		stringAvailable : "Este recurso esta disponible",
		stringUnAvailable : "Este recurso no esta disponible",
		ratingMsg : "Valoración: % (% votos emitidos) ",
		thanksRate : "Gracias por votar!",
		sendingRate : "Enviando la valoración ...",
        addButtonText : "Agregar",
        loadingText : "Cargando...",
        emptyDataText : "No hay datos disponibles.",
        errorDataText : "Error al recuperar los datos.",
        tableOptions : "Opciones de tabla",
		showColumnButton : "Mostrar",
		hideColumnButton : "Ocultar",
        columnDialogTitle : "Elije las columnas que desas ver",
        columnDialogCloseButton: "Cerrar",
        addItemHeaderText : "Agregar item",
        modifyItemHeaderText : "Modificar item",
        dialogSaveButton : "Guardar",
        dialogCancelButton: "Cancelar",
        trueValue: "si",
        falseValue: "no"
	});
	a.inputEx.messages = a.Intl.get("inputex")
}, "3.1.0", {
	requires : ["inputex"]
});
