/**
 * @module inputex-uneditable
 */
YUI.add("inputex-uneditable", function (Y) {

    var lang = Y.Lang,
      inputEx = Y.inputEx;

    /**
    * Create a uneditable field where you can stick the html you want
    * Added Options:
    * <ul>
    *    <li>visu: inputEx visu type</li>
    * </ul>
    * @class inputEx.UneditableField
    * @extends inputEx.Field
    * @constructor
    * @param {Object} options inputEx.Field options object
    */
    inputEx.UneditableField = function (options) {
        inputEx.UneditableField.superclass.constructor.call(this, options);
    };
    Y.extend(inputEx.UneditableField, inputEx.Field, {

        /**
        * Set the default values of the options
        * @method setOptions
        * @param {Object} options Options object as passed to the constructor
        */
        setOptions: function (options) {
            inputEx.UneditableField.superclass.setOptions.call(this, options);
            this.options.visu = options.visu;
        },

        render: function () {

            // Start change for readonly enum
            if (this.options.component.ValidValues && lang.isArray(this.options.component.ValidValues)) {
                for (i = 0, length = this.options.component.ValidValues.length; i < length; i++) {
                    if (this.options.component.ValidValues[i].Id == this.options.value) {
                        this.options.value = this.options.component.ValidValues[i].Value;
                        break;
                    }
                }
            } else {
                if (!this.options.value) this.options.value = this.options.component.Value;
            }
            // End change for readonly enum

            inputEx.UneditableField.superclass.render.call(this);

            if (this.options && this.options.component && this.options.component.Type == "upload" && this.options.value != "" /* && this.options.component.Mode != "view" */) {
                this.fieldContainer.onclick = DynamicForm.Utils.createDelegate(this, this.linkClick, [this.options.component]);
                this.fieldContainer.style.cursor = "pointer";
            }
        },

        /**
        * Store the value and update the visu
        * @method setValue
        * @param {Any} val The value that will be sent to the visu
        * @param {boolean} [sendUpdatedEvt] (optional) Wether this setValue should fire the 'updated' event or not (default is true, pass false to NOT send the event)
        */
        setValue: function (val, sendUpdatedEvt) {
            this.value = val;

            inputEx.renderVisu(this.options.visu, val, this.fieldContainer);

            inputEx.UneditableField.superclass.setValue.call(this, val, sendUpdatedEvt);
        },

        /**
        * Return the stored value
        * @method getValue
        * @return {Any} The previously stored value
        */
        getValue: function () {
            return this.value;
        },

        linkClick: function (comp) {
            if (comp.MetadataMap["frminsid2"] && comp.MetadataMap["frminsid2"] != "" && comp.MetadataMap["frminsid2"] != "0") {
                window.open(DynamicForm.Utils.getUrl("adynformdownloadshandler") + "?" + comp.MetadataMap["frminsid2"] + "," + comp.Id);
            } else {
                window.open(DynamicForm.Utils.getUrl("adynformdownloadshandler") + "?" + comp.MetadataMap["frminsid"] + "," + comp.Id);
            }
        }
    });

    // Register this class as "url" type
    inputEx.registerType("uneditable", inputEx.UneditableField);

}, '3.1.0', {
    requires: ['inputex-field']
});
