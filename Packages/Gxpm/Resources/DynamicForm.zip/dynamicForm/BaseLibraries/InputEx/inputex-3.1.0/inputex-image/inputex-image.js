/**
 * @module inputex-image
 */
YUI.add("inputex-image", function (Y) {

    var lang = Y.Lang,
       inputEx = Y.inputEx;

    /**
    * Basic image field (equivalent to the input type "text")
    *
    * @class inputEx.ImageField
    * @extends inputEx.Field
    * @constructor
    * @param {Object} options Added options:
    * <ul>
    *	 <li>regexp: regular expression used to validate (otherwise it always validate)</li>
    *   <li>size: size attribute of the input</li>
    *   <li>maxLength: maximum size of the image field (no message display, uses the maxlength html attribute)</li>
    *   <li>minLength: minimum size of the image field (will display an error message if shorter)</li>
    *   <li>typeInvite: image displayed when the field is empty</li>
    *   <li>readonly: set the field as readonly</li>
    * </ul>
    */
    inputEx.ImageField = function (options) {
        inputEx.ImageField.superclass.constructor.call(this, options);
    };

    Y.extend(inputEx.ImageField, inputEx.Field, {

        /**
        * Set the default values of the options
        * @method setOptions
        * @param {Object} options Options object as passed to the constructor
        */
        setOptions: function (options) {
            inputEx.ImageField.superclass.setOptions.call(this, options);

            this.options.height = (options.elem_lenght) ? options.elem_lenght : "";
            this.options.alt = (options.alt) ? options.alt : "";
            this.options.width = (options.elem_width) ? options.elem_width : "";
            this.options.src = (options.src) ? options.src : (options.value ? options.value : "");
            this.options.value = this.options.src;

            // Start Change for builder.
            this.options.editproperty = options.editproperty;
            this.options.component = options.component;
            this.options.action = options.action;
            // End Change for builder.
        },

        /**
        * Render
        * @method renderComponent
        */
        renderComponent: function () {
            // This element wraps the input node in a float: none div
            this.wrapEl = inputEx.cn('div', { className: 'inputEx-ImageField-wrapper' });

            // Attributes of the input field
            var attributes = {};
            if (this.divEl.id) {
                attributes.id = this.divEl.id + '-field';
            } else {
                attributes.id = Y.guid();
            }
            if (this.options.src) attributes.src = this.options.src;
            if (this.options.alt) attributes.alt = this.options.alt;

            // Create the node
            this.el = inputEx.cn('img', attributes);
            if (this.options.width != "") {
                this.el.style.width = this.options.width + "px";
                this.el.width = this.options.width + "px";
            }
            if (this.options.height != "") {
                this.el.style.height = this.options.height + "px";
                this.el.height = this.options.height + "px";
            }

            // Emparchada gigantesca para solucionar que la imagen del prompt no me esta quedando con el link luego de 
            // crear la img
            for (var i = 0; this.options.component.Actions[i] != undefined; i++) {
                if (this.options.component.Actions[i].Id.indexOf("editActionPrompt") != -1) {
                    this.wrapEl.link = this.options.component.Actions[i].Value.replace("javascript:", "");
                    this.wrapEl.onclick = function () { eval(this.link) };
                    this.wrapEl.style.cursor = "pointer";
                    break;
                }
            }
            // Fin Emparchada gigantesca para solucionar que la imagen del prompt no me esta quedando con el link luego
            // de crear la img

            // Append it to the main element
            this.wrapEl.appendChild(this.el);
            this.fieldContainer.appendChild(this.wrapEl);
        },

        /**
        * Set the value
        * @method setValue
        */
        setValue: function (value, sendUpdatedEvt) {

            this.el.value = value;

            // call parent class method to set style and fire updatedEvt
            inputEx.ImageField.superclass.setValue.call(this, value, sendUpdatedEvt);
            this.el.src = value;
        },

        /**
        * @method getValue
        */
        getValue: function () {
            return this.el.value;
        },

        /**
        * @method initEvents
        */
        initEvents: function () {
        },

        /**
        * Disable the field
        */
        disable: function () {
            this.el.disabled = true;
        },

        /**
        * Enable the field
        */
        enable: function () {
            this.el.disabled = false;
        },

        /**
        * Set the focus to this field
        */
        focus: function () {
            // Can't use lang.isFunction because IE >= 6 would say focus is not a function (IE says it's an object) !!
            if (!!this.el && !lang.isUndefined(this.el.focus)) {
                this.el.focus();
            }
        }
    });

    // Register this class as "image" type
    inputEx.registerType("image", inputEx.ImageField, [
    { type: 'string', label: 'url', name: 'url' }
    ]);

}, '3.1.0', {
    requires: ["inputex-field"]
});
