
CKEDITOR.config.enterMode = CKEDITOR.ENTER_BR;
CKEDITOR.config.shiftEnterMode = CKEDITOR.ENTER_P;
CKEDITOR.config.scayt_autoStartup = false;

CKEDITOR.config.toolbar_ContentBodyHtml =
[
    ['Source','-','Preview'],
    ['Undo','Redo','-','Cut','Copy','Paste','-','Find','Replace','-','SelectAll','RemoveFormat'],
    '/',
    ['insertMultimedia','Table','HorizontalRule','SpecialChar','PageBreak'],
    ['Link','Unlink'],	
    ['NumberedList','BulletedList','-','Outdent','Indent'],	
    ['JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock'],		
	'/',
    ['Bold','Italic','Underline','Strike'],
	['TextColor','BGColor'],
	['Format','Font','FontSize']
];


























