//
//  GXWorkWithEntityDataProviderHelper.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 09/11/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

@import GXObjectsModel;
#import <GXDataLayer/GXBaseEntityDataProvider.h>
#import <GXDataLayer/GXBaseListEntityDataProvider.h>
#import <GXDataLayer/GXBaseEntityDataProvider.h>
#import <GXDataLayer/GXWorkWithDataSource.h>

@interface GXWorkWithEntityDataProviderHelper : NSObject

@property(weak, readonly) GXBaseEntityDataProvider *provider;
@property(nonatomic, strong, readonly) GXWorkWithModel *workWithModel;
@property(weak, readonly) GXWorkWithDetail *workWithDetail;
@property(nonatomic, strong, readonly) GXWorkWithDataSource *workWithDataSource;

- (instancetype)initWithBaseEntityDataProvider:(GXBaseEntityDataProvider *)provider
								workWithDetail:(GXWorkWithDetail *)wwDetail NS_DESIGNATED_INITIALIZER;
- (instancetype)init NS_UNAVAILABLE;

- (GXBaseListEntityDataProvider *)newListProviderWithDataProviderName:(NSString *)dpName; // Abstract

// Default implementation calls newListProviderWithDataProviderName: and sets provider as parent provider
- (id <GXEntityDataListProvider>)entityDataListProviderForDataProviderName:(NSString *)dpName;

@end
