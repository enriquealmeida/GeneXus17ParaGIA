//
//  GXEntityHelper+GXDataLayer_DomainInfo.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 5/4/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import GXObjectsModel;

@interface GXEntityHelper (GXDataLayer_DomainInfo)

/*!
 Builds domain enum values from string
 
 @param string String to be parsed
 @param fieldInfo The field info to be used to resolve data type of values in the given string
 @result A new instance of GXDomainEnumValues with enum values from the given string
 @discussion The string must be a list with the following format:
	list := item | item , list
	item := description : value
 */
+ (GXDomainEnumValues *)domainEnumValuesFromString:(NSString *)string fieldInfo:(id <GXEntityDataFieldInfo>)fieldInfo;

@end
