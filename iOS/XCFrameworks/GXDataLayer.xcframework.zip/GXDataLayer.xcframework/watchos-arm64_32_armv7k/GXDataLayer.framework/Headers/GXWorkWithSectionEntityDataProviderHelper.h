//
//  GXWorkWithSectionEntityDataProviderHelper.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 09/11/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

@import GXObjectsModel;
#import <GXDataLayer/GXWorkWithEntityDataProviderHelper.h>

@protocol GXWorkWithSectionListEntityDataProvider <NSObject>

- (id)initWithWorkWithSection:(GXWorkWithSection *)wwSection
				 workWithData:(GXWorkWithData *)wwData;

@end

@interface GXWorkWithSectionEntityDataProviderHelper : GXWorkWithEntityDataProviderHelper

@property(weak, readonly) GXWorkWithSection *workWithSection;

- (instancetype)initWithBaseEntityDataProvider:(GXBaseEntityDataProvider *)provider
							   workWithSection:(GXWorkWithSection *)wwSection NS_DESIGNATED_INITIALIZER;

- (instancetype)initWithBaseEntityDataProvider:(GXBaseEntityDataProvider *)provider
								workWithDetail:(GXWorkWithDetail *)wwDetail NS_UNAVAILABLE;

@end
