//
//  GXModel+GXDataLayer.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 22/12/15.
//  Copyright © 2015 GeneXus. All rights reserved.
//

@import GXObjectsModel;
#import <GXDataLayer/GXBusinessComponentManager.h>
#import <GXDataLayer/GXEntityDataManager.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXModel (GXDataLayer)

@property(nonatomic, strong, readonly) GXBusinessComponentManager *businessComponentsManager;
@property(nonatomic, strong, readonly) GXEntityDataManager *entityDataManager;

@end

NS_ASSUME_NONNULL_END
