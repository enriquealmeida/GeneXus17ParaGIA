//
//  GXEntityDataFieldDynamicComboData.h
//  GXDataLayer
//
//  Created by José Echagüe on 12/9/21.
//  Copyright © 2021 GeneXus. All rights reserved.
//

@import GXObjectsModel;

@interface GXEntityDataFieldDynamicComboData: GXMutableDomainEnumValues

@end
