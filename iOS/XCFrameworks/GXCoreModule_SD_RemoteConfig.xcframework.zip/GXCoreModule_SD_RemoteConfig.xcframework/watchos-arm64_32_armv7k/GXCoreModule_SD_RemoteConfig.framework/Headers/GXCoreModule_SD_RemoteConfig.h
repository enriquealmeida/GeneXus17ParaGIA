//
//  GXCoreModule_SD_RemoteConfig.h
//  GXCoreModule_SD_RemoteConfig
//
//  Created by Marcos Crispino on 6/5/21.
//

#import <Foundation/Foundation.h>
//! Project version number for GXCoreModule_SD_RemoteConfig.
FOUNDATION_EXPORT double GXCoreModule_SD_RemoteConfigVersionNumber;

//! Project version string for GXCoreModule_SD_RemoteConfig.
FOUNDATION_EXPORT const unsigned char GXCoreModule_SD_RemoteConfigVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GXCoreModule_SD_RemoteConfig/PublicHeader.h>


#if TARGET_OS_IOS || TARGET_OS_TV
#import <UIKit/UIKit.h>
#elif TARGET_OS_WATCH
#import <WatchKit/WatchKit.h>
#endif
