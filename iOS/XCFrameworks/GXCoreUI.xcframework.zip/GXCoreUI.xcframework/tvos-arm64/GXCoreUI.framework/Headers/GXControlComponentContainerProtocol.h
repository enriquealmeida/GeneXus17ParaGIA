//
//  GXControlComponentContainerProtocol.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 1/6/15.
//  Copyright (c) 2015 Artech. All rights reserved.
//

#import <GXCoreUI/GXControlContainer.h>

@protocol GXControlComponentContainer <NSObject>

@end
