//
//  GXButtonWithExtendedHitArea.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 26/12/14.
//  Copyright (c) 2014 Artech. All rights reserved.
//

@import UIKit;

@interface GXButtonWithExtendedHitArea : UIButton

@property(nonatomic) UIEdgeInsets hitAreaInsets;

@end