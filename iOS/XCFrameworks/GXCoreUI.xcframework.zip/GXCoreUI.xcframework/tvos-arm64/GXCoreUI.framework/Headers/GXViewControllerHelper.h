//
//  GXViewControllerHelper.h
//  GXCoreUI
//
//  Created by Fabian Inthamoussu on 10/2/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import UIKit;

@interface GXViewControllerHelper : NSObject

@end