//
//  GXControlActionBarItemAlertActionView.h
//  GXCoreUI
//
//  Created by Fabian Inthamoussu on 19/8/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import UIKit;
#import <GXCoreUI/GXControlActionBarItem.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXControlActionBarItemAlertActionView : UIAlertAction <GXControlActionBarItemView>
@end

NS_ASSUME_NONNULL_END
