//
//  GXControlTableForHeightCalculation.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 06/09/13.
//  Copyright (c) 2013 Artech. All rights reserved.
//

#import <GXCoreUI/GXControlTableGridItem.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXControlTableForHeightCalculation : GXControlTableGridItem

@end

NS_ASSUME_NONNULL_END
