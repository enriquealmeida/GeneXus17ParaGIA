//
//  GXEditorLabelBase.h
//  GXCoreUI
//
//  Created by Marcos Crispino on 6/10/20.
//  Copyright © 2020 GeneXus. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXEditorLabelBase : UILabel

@end

NS_ASSUME_NONNULL_END
