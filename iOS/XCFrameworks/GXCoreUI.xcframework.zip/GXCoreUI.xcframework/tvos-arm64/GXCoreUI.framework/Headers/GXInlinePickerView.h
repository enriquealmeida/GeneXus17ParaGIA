//
//  GXInlinePickerView.h
//  GXCoreUI
//
//  Created by Marcos Crispino on 7/17/20.
//  Copyright © 2020 GeneXus. All rights reserved.
//

@protocol GXInlinePickerView

@end
