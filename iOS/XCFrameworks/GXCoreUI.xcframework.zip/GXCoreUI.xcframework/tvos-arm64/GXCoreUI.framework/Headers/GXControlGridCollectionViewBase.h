//
//  GXControlGridCollectionViewBase.h
//  GXCoreUI
//
//  Created by José Echagüe on 12/9/21.
//  Copyright © 2021 GeneXus. All rights reserved.
//

#import <GXCoreUI/GXControlGridCollectionTableViewBase.h>

@interface GXControlGridCollectionViewBase : GXControlGridCollectionTableViewBase

@end
