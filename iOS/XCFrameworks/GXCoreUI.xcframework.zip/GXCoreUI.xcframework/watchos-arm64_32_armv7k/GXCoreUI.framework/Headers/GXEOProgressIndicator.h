//
//  GXEOProgressIndicator.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 22/3/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import GXCoreBL;
@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN

@interface GXEOProgressIndicator : GXExternalObjectBase

@property (nonatomic, strong) NSString *progressIndicatorClass;
@property (nonatomic, assign) NSInteger progressIndicatorType;
@property (nonatomic, strong) NSString *progressIndicatorTitle;
@property (nonatomic, strong) NSString *progressIndicatorDescription;
@property (nonatomic, assign) NSInteger progressIndicatorMaxValue;
@property (nonatomic, assign) NSInteger progressIndicatorValue;

- (void)show;

- (void)showWithTitle:(NSString *)title;

- (void)showWithTitle:(NSString *)title description:(NSString *)desc;

- (void)hide;

@end

NS_ASSUME_NONNULL_END
