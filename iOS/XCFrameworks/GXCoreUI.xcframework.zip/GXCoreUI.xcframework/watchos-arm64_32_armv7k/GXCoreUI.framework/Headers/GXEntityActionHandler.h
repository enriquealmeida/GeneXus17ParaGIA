//
//  GXEntityActionHandler.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 28/07/11.
//  Copyright 2011 Artech. All rights reserved.
//

#import <GXCoreUI/GXActionUIHandler.h>
#import <GXCoreUI/GXEntityActionHandlerProtocol.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString *const GXActionHandlerUserInfoEntityModelKey;

@interface GXActionHandler (GXEntityActionHandler) <GXEntityActionHandler>
@end

NS_ASSUME_NONNULL_END
