//
//  GXActionUIHandler.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 3/12/15.
//  Copyright © 2015 GeneXus. All rights reserved.
//

@import GXObjectsModel;
@import GXObjectsModel.Swift;
@import GXCoreBL;

@interface GXActionHandler (GXActionHandlerUIDelegate) <GXActionUIHandler, GXActionHandlerUIDelegate>

#pragma mark Helpers

@property(nullable, nonatomic, strong, readonly) GXUserInterfaceContext *userInterfaceContext;
@property(nullable, nonatomic, strong, readonly) id <GXActionHandlerUserInterfaceControllerProtocol> gxActionHandlerUserInterfaceController;
@property(nullable, nonatomic, strong, readonly) id <GXControllerPresentationHandlerProtocol> gxActionHandlerControllerPresentationHandler;

@end
