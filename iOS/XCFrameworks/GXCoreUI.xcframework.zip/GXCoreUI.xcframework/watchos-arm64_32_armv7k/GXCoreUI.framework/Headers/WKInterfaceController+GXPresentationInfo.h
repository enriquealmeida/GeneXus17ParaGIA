//
//  WKInterfaceController+GXPresentationInfo.h
//  GXCoreUI
//
//  Created by Fabian Inthamoussu on 29/12/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import WatchKit;

typedef NS_ENUM(NSUInteger, GXPresentationInfoStyle) {
	GXPresentationInfoStyleUnknown,
	GXPresentationInfoStyleRoot,
	GXPresentationInfoStylePushed,
	GXPresentationInfoStyleModal,
};

typedef NS_ENUM(NSUInteger, GXPresentedControllerType) {
	GXPresentedControllerTypeUnknown,
	GXPresentedControllerTypeNone,
	GXPresentedControllerTypePushed,
	GXPresentedControllerTypeModalSingle,
	GXPresentedControllerTypeModalPaged,
	GXPresentedControllerTypeTextInput,
	GXPresentedControllerTypeMediaPlayer,
	GXPresentedControllerTypeAudioRecorder,
	GXPresentedControllerTypeAlert,
	GXPresentedControllerTypePasses,
};

NS_ASSUME_NONNULL_BEGIN

@interface WKInterfaceController (GXPresentationInfo)

@property(nonatomic, assign) GXPresentationInfoStyle gxPresentationInfoStyle;

@property(nullable, nonatomic, strong) NSNumber *gxPresentationInfoTabIndexNumber;

@end

NS_ASSUME_NONNULL_END
