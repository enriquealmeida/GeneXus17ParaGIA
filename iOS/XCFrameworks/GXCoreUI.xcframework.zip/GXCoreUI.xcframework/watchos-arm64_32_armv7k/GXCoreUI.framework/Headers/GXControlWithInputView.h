//
//  GXControlWithInputView.h
//  GXCoreUI
//
//  Created by Marcos Crispino on 6/10/20.
//  Copyright © 2020 GeneXus. All rights reserved.
//

@protocol GXControlWithInputView

- (BOOL)usePickerViewControllerForEditing;

@end
