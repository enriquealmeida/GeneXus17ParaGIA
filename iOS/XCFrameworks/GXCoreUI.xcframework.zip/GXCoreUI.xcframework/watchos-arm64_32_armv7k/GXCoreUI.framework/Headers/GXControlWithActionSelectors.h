//
//  GXControlWithActionSelectors.h
//  GXCoreUI
//
//  Created by Fabian Inthamoussu on 2/1/17.
//  Copyright © 2017 GeneXus. All rights reserved.
//

@import WatchKit;

NS_ASSUME_NONNULL_BEGIN

// Handles actions for WKInterfaceButton
@protocol GXControlWithActionSelector <NSObject>

- (void)handleControlActionSelector:(NSString *)interfaceObjectIdentifier;

@end

// Handles actions for WKInterfaceSwitch
@protocol GXControlWithBoolValueActionSelector <NSObject>

- (void)handleControlActionSelector:(NSString *)interfaceObjectIdentifier boolValue:(BOOL)value;

@end

// Handles actions for WKInterfaceTable
@protocol GXControlGridWithActionSelector <NSObject>

- (void)handleControlActionSelector:(NSString *)interfaceObjectIdentifier atIndexPath:(NSIndexPath *)itemIndexPath;

@end


NS_ASSUME_NONNULL_END
