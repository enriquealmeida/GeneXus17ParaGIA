//
//  GXEOLocation.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 21/03/14.
//  Copyright (c) 2014 Artech. All rights reserved.
//

@import GXFoundation;
@import GXObjectsModel;
@import GXCoreBL;
@import CoreBluetooth;
@import CoreLocation;

typedef NS_ENUM(uint_least8_t, GXRegionStateType) {
	GXRegionStateUnknown = 0,
	GXRegionStateInside = 1,
	GXRegionStateOutside = 2
};

typedef NS_ENUM(uint_least8_t, GXBeaconProximityType) {
	GXBeaconProximityUnknown = 0,
	GXBeaconProximityInmediate = 1,
	GXBeaconProximityNear = 2,
	GXBeaconProximityFar = 3
};

@interface GXEOLocation : GXExternalObjectBase <CLLocationManagerDelegate, CBPeripheralManagerDelegate>

+ (BOOL)serviceEnabled;

+ (GXAuthorizationStatusType)authorizationStatus;

#pragma mark - Beacon region monitoring

+ (BOOL)beaconProximityAlertsAvailable;

+ (BOOL)addBeaconProximityAlert:(id <GXSDTData>)proximityAlert completionBlock:(void(^)(NSError *error))block;
+ (BOOL)addBeaconProximityAlert:(id <GXSDTData>)proximityAlert; // Synchronic, must not be called on main thread

+ (BOOL)addBeaconProximityAlerts:(id <GXSDTDataCollection>)proximityAlerts completionBlock:(void(^)(NSError *error))block;
+ (BOOL)addBeaconProximityAlerts:(id <GXSDTDataCollection>)proximityAlerts; // Synchronic, must not be called on main thread

+ (id <GXSDTDataCollection>)beaconProximityAlerts;

+ (void)removeBeaconProximityAlert:(NSString *)proximityAlertRegionId;
+ (void)clearBeaconProximityAlerts;

+ (BOOL)requestBeaconRegionState:(NSString *)beaconRegionId completionBlock:(void(^)(GXRegionStateType regionState, NSError *error))block;
+ (GXRegionStateType)beaconRegionState:(NSString *)beaconRegionId; // Synchronic, must not be called on main thread

#pragma mark - Beacon ranging

+ (BOOL)rangingAvailable;

+ (BOOL)startRangingBeaconRegion:(id <GXSDTData>)beaconRegion completionBlock:(void(^)(NSError *error))block;
+ (BOOL)startRangingBeaconRegion:(id <GXSDTData>)beaconRegion; // Synchronic, must not be called on main thread

+ (id <GXSDTDataCollection>)rangedBeaconRegions;

+ (void)stopRangingBeaconRegion:(NSString *)beaconRegionId;

+ (id <GXSDTDataCollection>)beaconsInRange:(NSString *)beaconRegionId;

#pragma mark - Advertising as beacon

+ (BOOL)startAsBeacon:(id <GXSDTData>)beaconInfo completionBlock:(void(^)(NSError *error))block;
+ (BOOL)startAsBeacon:(id <GXSDTData>)beaconInfo; // Synchronic, must not be called on main thread

+ (BOOL)stopAsBeacon;

@end


@interface GXEOLocation (OfflineGenerator)

+ (NSNumber *)authorizationStatusNumber;
+ (BOOL)addBeaconProximityAlertWithParameters:(NSArray *)params;
+ (BOOL)addBeaconProximityAlertsWithParameters:(NSArray *)params;
+ (id <GXSDTDataCollection>)beaconProximityAlertsCollection; // Same as beaconProximityAlerts but never returns nil
+ (void)removeBeaconProximityAlertWithParameters:(NSArray *)params;
+ (NSNumber *)beaconRegionStateWithParameters:(NSArray *)params;
+ (BOOL)startRangingBeaconRegionWithParameters:(NSArray *)params;
+ (id <GXSDTDataCollection>)rangedBeaconRegionsCollection; // Same as rangedBeaconRegions but never returns nil
+ (void)stopRangingBeaconRegionWithParameters:(NSArray *)params;
+ (id <GXSDTDataCollection>)beaconsInRangeWithParameters:(NSArray *)params;
+ (BOOL)startAsBeaconWithParameters:(NSArray *)params;

@end
