//
//  GXCoreModule_Common_Maps.h
//  GXCoreModule_Common_Maps
//
//  Created by José Echagüe on 6/25/18.
//  Copyright © 2018 genexus. All rights reserved.
//

#import <Foundation/Foundation.h>
//! Project version number for GXCoreModule_Common_Maps.
FOUNDATION_EXPORT double GXCoreModule_Common_MapsVersionNumber;

//! Project version string for GXCoreModule_Common_Maps.
FOUNDATION_EXPORT const unsigned char GXCoreModule_Common_MapsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GXCoreModule_Common_Maps/PublicHeader.h>

#if TARGET_OS_IOS || TARGET_OS_TV
#import <UIKit/UIKit.h>
#elif TARGET_OS_WATCH
#import <WatchKit/WatchKit.h>
#endif
