//
//  GXFlexLayout.h
//  GXFlexLayout
//
//  Created by José Echagüe on 1/25/18.
//  Copyright © 2018 genexus. All rights reserved.
//

#import <Foundation/Foundation.h>
//! Project version number for GXFlexLayout.
FOUNDATION_EXPORT double GXFlexLayoutVersionNumber;

//! Project version string for GXFlexLayout.
FOUNDATION_EXPORT const unsigned char GXFlexLayoutVersionString[];

#if TARGET_OS_IOS || TARGET_OS_TV
#import <UIKit/UIKit.h>
#elif TARGET_OS_WATCH
#import <WatchKit/WatchKit.h>
#endif

#import <GXFlexLayout/GXControlFlexGrid.h>
