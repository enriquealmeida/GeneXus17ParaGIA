//
//  GXControlFlexGrid.h
//  GXFlexLayout-iOS
//
//  Created by José Echagüe on 12/9/21.
//  Copyright © 2021 GeneXus. All rights reserved.
//

@import Foundation;
@import GXObjectsModel;

@import yoga;

@import GXCoreUI;

NS_ASSUME_NONNULL_BEGIN

@interface GXControlFlexGridReuseContext: GXControlGridBaseReuseContext

@property(nonatomic, readwrite, assign) BOOL restoreLayoutElementFlexDirection;
@property(nonatomic, readwrite, assign) BOOL restoreLayoutElementFlexWrap;
@property(nonatomic, readwrite, assign) BOOL restoreLayoutElementFlexJustifyContent;
@property(nonatomic, readwrite, assign) BOOL restoreLayoutElementAlignContent;
@property(nonatomic, readwrite, assign) BOOL restoreLayoutElementAlignItems;

@end

@interface GXControlFlexGrid : GXControlGridCollectionViewBase

- (instancetype)initWithLayoutElement:(id<GXLayoutElement>)layoutElement
					   dataDescriptor:(id <GXEntityDataDescriptor>)dataDescriptor
			   businessComponentLevel:(nullable GXBusinessComponentLevel *)businessComponentLevel
							controlId:(int)controlId
							   gxMode:(GXModeType)modeType
						 indexerStack:(nullable NSArray *)indexerStack
						parentControl:(nullable id<GXControlContainer>)parentControl
							relations:(nullable NSDictionary *)relations;

@property(nonatomic, readwrite, assign) YGFlexDirection flexDirection;
@property(nonatomic, readwrite, assign) YGWrap flexWrap;
@property(nonatomic, readwrite, assign) YGAlign flexJustifyContent;
@property(nonatomic, readwrite, assign) YGAlign flexAlignItems;
@property(nonatomic, readwrite, assign) YGAlign flexAlignContent;

@property(nullable, nonatomic, readonly, strong) GXControlFlexGridReuseContext* flexGridReuseContext;

- (void)invalidateCollectionViewLayout;

@end

NS_ASSUME_NONNULL_END
