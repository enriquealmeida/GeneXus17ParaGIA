//
//  GXInvocationHelpers.h
//  GXDataLayerLocal
//
//  Created by Marcos Crispino on 9/12/20.
//  Copyright © 2020 GeneXus. All rights reserved.
//

@import Foundation;
@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN

@interface GXInvocationHelpers : NSObject

+ (BOOL)asyncInvokeCollectionReturningMethod:(NSString *)methodBaseName
							   fromClassName:(NSString *)className
							  withParameters:(NSArray * _Nullable)params
								  completion:(void (^)(GXObjectCollection * _Nullable))completion;

+ (NSString * _Nullable)invokeStringReturningSelector:(SEL)selector
											fromClass:(Class)targetClass
									   withParameters:(NSArray * _Nullable)params
												error:(NSError * __autoreleasing *)error;

@end

NS_ASSUME_NONNULL_END
