//
//  GXBaseLocalListEntityDataProvider.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 18/1/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import GXDataLayer;

@interface GXBaseLocalListEntityDataProvider : GXBaseListEntityDataProvider

@end
