//
//  GXCertificatePinning.h
//  GXCertificatePinning
//
//  Created by José Echagüe on 11/11/19.
//  Copyright © 2019 genexus. All rights reserved.
//

#import <Foundation/Foundation.h>
//! Project version number for GXCertificatePinning.
FOUNDATION_EXPORT double GXCertificatePinningVersionNumber;

//! Project version string for GXCertificatePinning.
FOUNDATION_EXPORT const unsigned char GXCertificatePinningVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GXCertificatePinning/PublicHeader.h>


#if TARGET_OS_IOS || TARGET_OS_TV
#import <UIKit/UIKit.h>
#elif TARGET_OS_WATCH
#import <WatchKit/WatchKit.h>
#endif
