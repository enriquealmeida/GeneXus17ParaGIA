//
//  GXDebugger.h
//  GXDebugger
//
//  Created by Fabian Inthamoussu on 19/5/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

#import <Foundation/Foundation.h>
//! Project version number for GXDebugger.
FOUNDATION_EXPORT double GXDebuggerVersionNumber;

//! Project version string for GXDebugger.
FOUNDATION_EXPORT const unsigned char GXDebuggerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GXDebugger/PublicHeader.h>


#if TARGET_OS_IOS || TARGET_OS_TV
#import <UIKit/UIKit.h>
#elif TARGET_OS_WATCH
#import <WatchKit/WatchKit.h>
#endif
