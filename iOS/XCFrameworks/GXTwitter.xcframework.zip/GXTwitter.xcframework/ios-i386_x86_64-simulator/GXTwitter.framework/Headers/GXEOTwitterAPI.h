//
//  GXEOTwitterAPI.h
//  GXFlexibleClient
//
//  Created by Alejandro Panizza on 18/09/13.
//  Copyright (c) 2013 Artech. All rights reserved.
//

@import GXCoreBL;
@import GXStandardClasses;

@interface GXEOTwitterAPI : GXExternalObjectBase

- (void)follow:(NSArray *)users ;
- (void)sendtweet:(NSArray *)data ;
- (void)revokeauthorization:(NSArray *)data;

@end
