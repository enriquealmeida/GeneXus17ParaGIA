//
//  GXSoapLocation.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 23/04/14.
//  Copyright (c) 2014 Artech. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

@interface GXSoapLocation : NSObject

@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *host;
@property (nonatomic, assign) NSInteger port;
@property (nonatomic, strong) NSString *proxyServerHost;
@property (nonatomic, assign) NSInteger proxyServerPort;
@property (nonatomic, strong) NSString *baseURL;
@property (nonatomic, strong) NSString *resourceName;
@property (nonatomic, assign) NSInteger secure;
@property (nonatomic, assign) NSInteger timeout;
@property (nonatomic, assign) NSInteger authenticationMethod;
@property (nonatomic, strong) NSString *authenticationUser;
@property (nonatomic, strong) NSString *authenticationRealm;
@property (nonatomic, strong) NSString *authenticationPassword;
@property (nonatomic, assign) NSInteger proxyAuthenticationMethod;
@property (nonatomic, strong) NSString *proxyAuthenticationUser;
@property (nonatomic, strong) NSString *proxyAuthenticationRealm;
@property (nonatomic, strong) NSString *proxyAuthenticationPassword;
@property (nonatomic, strong) NSString *certificate;
@property (nonatomic, assign) NSInteger authentication;
@property (nonatomic, assign) NSInteger proxyAuthentication;
@property (nonatomic, assign) NSInteger cancelOnError;
@property (nonatomic, strong) NSString *groupLocation;
@property (nonatomic, strong) NSString *wsdlurl;

@end

NS_ASSUME_NONNULL_END
