//
//  GXOfflineDynamicCallHelper.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 1/9/15.
//  Copyright (c) 2015 Artech. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

@interface GXOfflineDynamicCallHelper : NSObject

+ (NSArray *)dynamicExecuteSwift:(NSString *)objName parameters:(NSArray *)params;

@end

NS_ASSUME_NONNULL_END
