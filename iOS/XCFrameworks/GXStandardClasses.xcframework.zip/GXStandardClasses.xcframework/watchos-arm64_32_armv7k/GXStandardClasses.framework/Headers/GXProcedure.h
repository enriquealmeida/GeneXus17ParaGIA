//
//  GXProcedure.h
//  GXStd
//
//  Created by Marcos Crispino on 22/08/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

@interface GXProcedure : NSObject {
    NSString *gx_mode;
}

@property (nonatomic, strong) NSString *Gx_mode NS_SWIFT_NAME(Gx_mode);

- (void)executeSubmit:(nullable NSArray *)params;

- (void)setCreateDataBase;

- (void)cleanup;

- (void)initialize;

@end

NS_ASSUME_NONNULL_END
