//
//  GXProcedureHelper.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 25/09/14.
//  Copyright (c) 2014 Artech. All rights reserved.
//

@import GXFoundation;
@import GXObjectsModel;
#import <GXStandardClasses/GXProcedure.h>

NS_ASSUME_NONNULL_BEGIN

/// Allowed value types are GXProcedureExecutionOptions or NSDictionary<NSString*, GXProcedureExecutionOptions *> being the keys the lowercase proc names
extern NSString *const GXActionHandlerUserInfoProcedureOptionsKey;


@interface GXProcedureExecutionOptions: NSObject <NSCopying>

/*!
 Indicates the timeout (in seconds) for the HTTP request of Online Procedures
 @discussion Return 0 to use iOS's default HTTP Request timeout
 */
@property NSTimeInterval procedureHttpRequestTimeout;

/*!
 This options is used when there is a security check failure. Default to YES
 @return Return NO if you don't want to retry. The procedure call action will be terminated with error.
 */
@property BOOL shouldRetryOnSecurityCheckFailure;

/*!
 Indicates if last parameter out Messages (if any) should be handled automatically, displaing messages to the user, and
 call action terminated with error if there is any massage with Type = Error. Default to YES
 @return Return NO if you don't want this automatic behaviour.
*/
@property BOOL shouldProcessMessagesOutput;

@end


@interface GXProcedureHelperExecutionOptions : NSObject <NSCopying>

@property(nullable) id<GXInheritedConnectivitySupportResolver> connectivitySupportResolver;
@property(nullable) GXProcedureExecutionOptions* executionOptions;

@end


@protocol GXProcedureHelperOptionals <NSObject>

@optional
+ (NSArray *)executeOnlineProcedure:(NSString *)procName params:(NSArray *)params;
+ (NSArray *)executeOnlineProcedure:(NSString *)procName params:(NSArray *)params options:(nullable GXProcedureExecutionOptions *)options;

+ (nullable id<GXCancelableOperation>)executeProcedure:(NSString *)procName
												params:(NSArray *)params
											   options:(nullable GXProcedureHelperExecutionOptions *)options
											completion:(void(^_Nullable)(NSArray * _Nullable  resultParams,  NSError * _Nullable error))completion;

@end



@interface GXProcedureHelper : NSObject <GXProcedureHelperOptionals>

+ (nullable Class)gxOfflineProcedureClassForProcedureName:(NSString *)procedureName;

+ (NSArray *)executeOfflineProcedure:(Class)gxProcClass withParameters:(nullable NSArray *)gxProcParams;

+ (NSArray *)executeOfflineProcedureInstance:(GXProcedure *)gxProc withParameters:(nullable NSArray *)gxProcParams;

@end

NS_ASSUME_NONNULL_END
