//
//  GXEOSynchronizationEventsAPI.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 8/7/13.
//  Copyright (c) 2013 Artech. All rights reserved.
//

@import GXFoundation;
@import GXDataLayer;
@import GXStandardClasses;
@import GXCoreBL;

@interface GXEOSynchronizationEventsAPI : GXExternalObjectBase

- (BOOL)hasEventsWithStatus:(NSUInteger)status;

- (NSArray<id<GXSynchronizationSendEvent>> *)getEventsWithStatus:(NSUInteger)status;

- (GXObjectCollection *)getEventsCollectionWithStatus:(NSUInteger)status;

- (void)markEventAsPendingForEventId:(NSString *)eventId;

- (void)removeEventForEventId:(NSString *)eventId;

@end
