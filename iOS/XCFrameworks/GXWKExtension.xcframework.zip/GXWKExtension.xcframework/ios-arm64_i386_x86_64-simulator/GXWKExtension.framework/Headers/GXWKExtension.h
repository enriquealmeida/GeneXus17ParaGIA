//
//  GXWKExtension.h
//  GXWKExtension
//
//  Created by Fabian Inthamoussu on 22/2/18.
//  Copyright © 2018 GeneXus. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for GXWKExtension.
FOUNDATION_EXPORT double GXWKExtensionVersionNumber;

//! Project version string for GXWKExtension.
FOUNDATION_EXPORT const unsigned char GXWKExtensionVersionString[];
