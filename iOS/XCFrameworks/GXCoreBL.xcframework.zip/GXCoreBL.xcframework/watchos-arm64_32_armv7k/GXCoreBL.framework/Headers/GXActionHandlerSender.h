//
//  GXActionHandlerSender.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 21/11/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

#import <GXCoreBL/GXActionHandler.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXActionHandlerSender : NSObject <GXActionSender>

@end

NS_ASSUME_NONNULL_END
