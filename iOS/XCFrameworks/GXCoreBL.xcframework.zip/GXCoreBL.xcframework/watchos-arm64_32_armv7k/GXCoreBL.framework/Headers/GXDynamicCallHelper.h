//
//  GXDynamicCallHelper.h
//  GXCoreBL
//
//  Created by Fabian Inthamoussu on 18/1/18.
//  Copyright © 2018 GeneXus. All rights reserved.
//

@import GXObjectsModel;

NS_ASSUME_NONNULL_BEGIN

@interface GXDynamicCallHelper : NSObject

+ (nullable NSString *)dynamicObjectTypePrefixFromObjectTypeEnum:(GXObjectType)objType;

+ (NSString *)dynamicObjectPrefixedNameWithObjectName:(NSString *)objectName objectType:(GXObjectType)objectType;

+ (NSString *)dynamicObjectLinkWithDynamicObjectName:(NSString *)dynamicObjectName
									 parameterValues:(NSArray *)paramsValues
								parameterDescriptors:(NSArray<id<GXActionParameterDescriptor>> *)paramsDescriptors;

+ (void)parseDynamicCallString:(NSString *)dynamicCallString
			  objectTypePrefix:(out NSString * _Nullable * _Nullable)outObjType
					objectName:(out NSString * _Nullable * _Nullable)outObjName
			  objectParameters:(out NSArray<id<GXActionParameterDescriptor>> * _Nullable * _Nullable)outObjParams;

+ (nullable GXWorkWithModel *)resolveSdDynamicCallFromObjectName:(NSString *)objNameString
												workWithCallMode:(out GXWorkWithModeType * _Nullable)callMode
											   workWithComponent:(out NSString * _Nullable * _Nullable)workWithComponent;

@end

NS_ASSUME_NONNULL_END
