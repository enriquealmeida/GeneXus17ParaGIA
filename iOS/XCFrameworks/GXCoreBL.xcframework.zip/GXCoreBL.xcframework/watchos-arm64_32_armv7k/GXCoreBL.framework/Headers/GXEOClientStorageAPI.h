//
//  GXEOClientStorageAPI.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 11/04/14.
//  Copyright (c) 2014 Artech. All rights reserved.
//

@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN

@interface GXEOClientStorageAPI : GXExternalObjectBase

+ (void)set:(NSString *)key :(NSString *)value;

+ (void)secureSet:(NSString *)key :(NSString *)value;

+ (NSString *)get:(NSString *)key;

+ (void)remove:(NSString *)key;

+ (void)clear;

@end

NS_ASSUME_NONNULL_END
