//
//  GXGAMSecurityService.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 18/2/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import GXObjectsModel;

@interface GXGAMSecurityService : NSObject <GXSecurityService>

@end
