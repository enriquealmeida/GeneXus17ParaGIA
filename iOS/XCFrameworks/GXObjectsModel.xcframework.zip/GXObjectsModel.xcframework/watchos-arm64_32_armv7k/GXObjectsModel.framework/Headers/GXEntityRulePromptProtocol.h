//
//  GXEntityRulePromptProtocol.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 2/27/13.
//  Copyright (c) 2013 Artech. All rights reserved.
//

@import Foundation;
#import <GXObjectsModel/GXActionDescriptorProtocol.h>

@protocol GXEntityRulePrompt <NSObject>

@property(nullable, nonatomic, strong, readonly) NSString *entityRulePromptCallObjectName;
@property(nullable, nonatomic, strong, readonly) NSString *entityRulePromptCallObjectType;
@property(nullable, nonatomic, strong, readonly) id <GXActionParametersDescriptor> entityRulePromptParameters;

/**
 * If the rule specifies the control name (like in "prompt(...) on <control_name>", is the value of the control where the prompt should be placed
 *
 * Otherwise it is nil, and it shoul be calculated based on the attributes and variables present in the layout.
 */
@property(nullable, nonatomic, strong, readonly) NSString *entityRulePromptControlName;
@property(nullable, nonatomic, strong, readonly) NSString *entityRulePromptAfterServiceURI;
@property(nullable, nonatomic, strong, readonly) id <GXActionParametersDescriptor> entityRulePromptAfterServiceInputParameters;
@property(nullable, nonatomic, strong, readonly) id <GXActionParametersDescriptor> entityRulePromptAfterServiceOutputParameters;

@end
