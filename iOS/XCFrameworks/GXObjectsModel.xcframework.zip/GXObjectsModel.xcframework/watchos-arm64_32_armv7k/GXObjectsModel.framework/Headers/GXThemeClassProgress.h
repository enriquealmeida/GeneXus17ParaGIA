//
//  GXThemeClassProgress.h
//  GXObjectsModel
//
//  Created by José Echagüe on 12/6/17.
//  Copyright © 2017 GeneXus. All rights reserved.
//

#import <GXObjectsModel/GXThemeClass.h>
@import UIKit;

NS_ASSUME_NONNULL_BEGIN

@interface GXThemeClassProgress : GXThemeClass
@end

NS_ASSUME_NONNULL_END
