//
//  GXEntityHelper+GXNSURL.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 12/11/15.
//  Copyright © 2015 Artech. All rights reserved.
//

#import <GXObjectsModel/GXEntityHelper.h>

@interface GXEntityHelper (GXNSURL)

/*!
Builds an absolute URL relative to the server base URL

@param relativeURL the relative URL string
@result Returns an absolute URL relative to the server base URL
*/
+ (nullable NSURL *)urlRelativeToServerBaseURL:(nullable NSString *)relativeURL;

+ (nullable NSURL *)webPanelURLFromName:(nullable NSString *)webPanelName parameters:(nullable NSArray *)parameters;

+ (nullable NSURL *)procedureURLFromName:(nullable NSString *)procName;
+ (nullable NSURL *)multicallProcedureURLFromName:(nullable NSString *)procName;

+ (nullable NSURL *)staticResourceURLWithRelativePath:(nullable NSString *)path;

/// Convert the given url if has a known gx scheme, otherwise returns the given url.
+ (nullable NSURL *)urlFromGXSchemeURL:(nullable NSURL *)url;

+ (nullable NSURL *)absoluteURLFromFieldValue:(nullable id)fieldValue;

@end
