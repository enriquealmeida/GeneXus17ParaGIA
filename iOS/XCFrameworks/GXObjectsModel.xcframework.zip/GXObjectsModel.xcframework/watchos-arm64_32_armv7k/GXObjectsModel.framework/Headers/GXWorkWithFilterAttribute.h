//
//  GXWorkWithFilterAttribute.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 10/12/10.
//  Copyright 2010 Artech. All rights reserved.
//

@import Foundation;
#import <GXObjectsModel/GXDescriptionElement.h>
#import <GXObjectsModel/GXEntityListFilterAdvancedProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@class GXTypedObjectInfo;

typedef NS_ENUM(uint_least8_t, GXWorkWithFilterAdvancedAttributeType) {
	GXWorkWithFilterAdvancedAttributeTypeStandard,
	GXWorkWithFilterAdvancedAttributeTypeRange
};

@interface GXWorkWithFilterAdvancedField : GXDescriptionElement <GXEntityListFilterAdvancedField>

- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithName:(nullable NSString *)name NS_UNAVAILABLE;

@property(assign, readonly) GXWorkWithFilterAdvancedAttributeType type;

@end



@interface GXWorkWithFilterAdvancedFieldStandard : GXWorkWithFilterAdvancedField <GXEntityListFilterAdvancedFieldStandard>

- (instancetype)initWithName:(NSString *)name
				 description:(NSString *)desc
				defaultValue:(nullable id)defaultValue
				   allOption:(BOOL)allOption NS_DESIGNATED_INITIALIZER;

- (instancetype)init NS_UNAVAILABLE;
- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

@end



@interface GXWorkWithFilterAdvancedFieldRange : GXWorkWithFilterAdvancedField <GXEntityListFilterAdvancedFieldRange>

- (instancetype)initWithName:(NSString *)name
				 description:(NSString *)desc
			defaultFromValue:(nullable id)defaultFromValue
			  defaultToValue:(nullable id)defaultToValue NS_DESIGNATED_INITIALIZER;

- (instancetype)init NS_UNAVAILABLE;
- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

@end



@interface GXWorkWithFilterAdvancedFieldAttributeStandard : GXWorkWithFilterAdvancedFieldStandard <GXEntityDataFieldAttributeDescriptor>

@end

@interface GXWorkWithFilterAdvancedFieldVariableStandard : GXWorkWithFilterAdvancedFieldStandard <GXEntityDataFieldVariableDescriptor>

@property(nonatomic, strong, readonly) GXTypedObjectInfo *typedObjectInfo;

- (instancetype)initWithTypedObjectInfo:(GXTypedObjectInfo *)typedObjectInfo
							description:(NSString *)desc
						   defaultValue:(nullable id)defaultValue
							  allOption:(BOOL)allOption NS_DESIGNATED_INITIALIZER;

- (instancetype)initWithName:(nullable NSString *)name
				 description:(nullable NSString *)desc NS_UNAVAILABLE;
- (instancetype)initWithName:(NSString *)name
				 description:(NSString *)desc
				defaultValue:(nullable id)defaultValue
				   allOption:(BOOL)allOption NS_UNAVAILABLE;
- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

@end



@interface GXWorkWithFilterAdvancedFieldAttributeRange : GXWorkWithFilterAdvancedFieldRange <GXEntityDataFieldAttributeDescriptor>

@end

@interface GXWorkWithFilterAdvancedFieldVariableRange : GXWorkWithFilterAdvancedFieldRange <GXEntityDataFieldVariableDescriptor>

@property(nonatomic, strong, readonly) GXTypedObjectInfo *typedObjectInfo;

- (instancetype)initWithTypedObjectInfo:(GXTypedObjectInfo *)typedObjectInfo
							description:(NSString *)desc
					   defaultFromValue:(nullable id)defaultFromValue
						 defaultToValue:(nullable id)defaultToValue NS_DESIGNATED_INITIALIZER;

- (instancetype)initWithName:(nullable NSString *)name
				 description:(nullable NSString *)desc NS_UNAVAILABLE;
- (instancetype)initWithName:(NSString *)name
				 description:(NSString *)desc
			defaultFromValue:(nullable id)defaultFromValue
			  defaultToValue:(nullable id)defaultToValue NS_UNAVAILABLE;
- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

@end

NS_ASSUME_NONNULL_END
