//
//  GXWorkWithActions.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 10/12/10.
//  Copyright 2010 Artech. All rights reserved.
//

@import Foundation;
#import <GXObjectsModel/GXEventDescriptorProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXWorkWithActions : NSObject <NSCoding>

@property(nonatomic, strong, readonly) NSArray<id<GXEventDescriptor>> *events;

- (instancetype)initWithEvents:(nullable NSArray<id <GXEventDescriptor>> *)events NS_DESIGNATED_INITIALIZER;

- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

@end

NS_ASSUME_NONNULL_END
