//
//  GXDescriptionModelObjectChild.h
//  GXObjectsModel
//
//  Created by Fabian Inthamoussu on 18/9/21.
//  Copyright © 2021 GeneXus. All rights reserved.
//

#import <GXObjectsModel/GXDescriptionElement.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXDescriptionModelObjectChild : GXDescriptionElement
@end

NS_ASSUME_NONNULL_END
