//
//  GXModelLoadOperationContext+GXModelManagerExtension.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 26/1/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

#import <GXObjectsModel/GXModelLoadOperation.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXModelLoadOperationContext (GXModelManagerExtension)

@property(nullable, nonatomic, strong, readwrite) NSError *error;

- (void)setModelObject:(id)modelObject forKey:(NSString *)key;
- (nullable id)modelObjectForKey:(NSString *)key;

@end

NS_ASSUME_NONNULL_END
