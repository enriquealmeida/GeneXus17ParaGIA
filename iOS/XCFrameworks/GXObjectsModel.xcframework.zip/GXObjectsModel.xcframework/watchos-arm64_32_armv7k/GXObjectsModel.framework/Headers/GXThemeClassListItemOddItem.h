//
//  GXThemeClassListItemOddItem.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 12/05/11.
//  Copyright 2011 Artech. All rights reserved.
//

#import <GXObjectsModel/GXThemeClassListItem.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXThemeClassListItemOddItem : GXThemeClassListItem
@end

NS_ASSUME_NONNULL_END
