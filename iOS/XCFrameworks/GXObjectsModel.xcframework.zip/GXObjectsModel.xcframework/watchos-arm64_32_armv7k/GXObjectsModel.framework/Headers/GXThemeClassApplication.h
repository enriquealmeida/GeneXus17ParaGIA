//
//  GXThemeClassApplication.h
//  GXFlexibleClient
//
//  Created by willy on 11/29/11.
//  Copyright (c) 2011 Artech. All rights reserved.
//

#import <GXObjectsModel/GXThemeClassBase.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXThemeClassApplication : GXThemeClassBase
@end

NS_ASSUME_NONNULL_END
