//
//  GXDomainEnumValues.h
//  GXObjectsModel
//
//  Created by José Echagüe on 12/9/21.
//  Copyright © 2021 GeneXus. All rights reserved.
//

@import Foundation;

@interface GXDomainEnumValues : NSObject

@end

@interface GXMutableDomainEnumValues : GXDomainEnumValues

@end
