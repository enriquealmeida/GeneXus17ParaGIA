//
//  GXThemeClassDashboard.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 11/05/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

#import <GXObjectsModel/GXThemeClass.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXThemeClassDashboard : GXThemeClass
@end

NS_ASSUME_NONNULL_END
