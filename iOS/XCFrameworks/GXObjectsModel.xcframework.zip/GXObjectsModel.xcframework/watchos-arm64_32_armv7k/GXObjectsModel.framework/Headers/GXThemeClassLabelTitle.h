//
//  GXThemeClassLabelTitle.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 26/04/11.
//  Copyright 2011 Artech. All rights reserved.
//

#import <GXObjectsModel/GXThemeClassLabel.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXThemeClassLabelTitle : GXThemeClassLabel

@end

NS_ASSUME_NONNULL_END
