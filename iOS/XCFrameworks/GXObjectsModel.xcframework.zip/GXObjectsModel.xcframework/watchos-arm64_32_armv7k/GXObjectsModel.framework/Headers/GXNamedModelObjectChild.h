//
//  GXNamedModelObjectChild.h
//  GXObjectsModel
//
//  Created by Fabian Inthamoussu on 17/9/21.
//  Copyright © 2021 GeneXus. All rights reserved.
//

#import <GXObjectsModel/GXNamedElement.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXNamedModelObjectChild : GXNamedElement
@end

NS_ASSUME_NONNULL_END
