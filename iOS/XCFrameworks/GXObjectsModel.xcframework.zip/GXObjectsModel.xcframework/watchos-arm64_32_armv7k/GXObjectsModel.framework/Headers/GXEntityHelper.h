//
//  GXEntityHelper.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 17/12/10.
//  Copyright 2010 Artech. All rights reserved.
//

@import Foundation;

@interface GXEntityHelper : NSObject
@end