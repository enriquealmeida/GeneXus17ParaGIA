//
//  GXClientInformation.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 28/12/15.
//  Copyright © 2015 GeneXus. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

@interface GXClientInformation : NSObject

+ (nullable NSString *)deviceUUID;
+ (NSString *)osName;
+ (NSString *)osVersion;
+ (NSString *)deviceLanguage;
+ (NSUInteger)deviceType;
+ (nullable NSString *)platformName;
+ (nonnull NSString *)appID;
+ (nullable NSString *)appVersionCode;
+ (nullable NSString *)appVersionName;
+ (nonnull NSString *)installationUUID;

@end

NS_ASSUME_NONNULL_END
