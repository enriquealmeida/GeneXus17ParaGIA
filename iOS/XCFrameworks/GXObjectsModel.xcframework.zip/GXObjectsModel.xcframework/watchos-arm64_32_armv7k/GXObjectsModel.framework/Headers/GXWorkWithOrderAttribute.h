//
//  GXWorkWithOrderField.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 10/12/10.
//  Copyright 2010 Artech. All rights reserved.
//

@import Foundation;
#import <GXObjectsModel/GXDescriptionElement.h>
#import <GXObjectsModel/GXEntityListOrderProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@class GXTypedObjectInfo;

@interface GXWorkWithOrderField : GXDescriptionElement <GXEntityListOrderField>

@property(assign, readonly) BOOL ascending;

- (instancetype)initWithName:(NSString *)name
				 description:(nullable NSString *)desc
				   ascending:(BOOL)ascending NS_DESIGNATED_INITIALIZER;

- (instancetype)init NS_UNAVAILABLE;
- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

@end


@interface GXWorkWithOrderFieldAttribute : GXWorkWithOrderField <GXEntityDataFieldAttributeDescriptor>

@end


@interface GXWorkWithOrderFieldVariable : GXWorkWithOrderField <GXEntityDataFieldVariableDescriptor>

@property(nonatomic, strong, readonly) GXTypedObjectInfo *typedObjectInfo;

- (instancetype)initWithTypedObjectInfo:(GXTypedObjectInfo *)typedObjectInfo
							description:(nullable NSString *)desc
							  ascending:(BOOL)ascending NS_DESIGNATED_INITIALIZER;

- (instancetype)initWithName:(nullable NSString *)name NS_UNAVAILABLE;
- (instancetype)initWithName:(nullable NSString *)name
				 description:(nullable NSString *)desc NS_UNAVAILABLE;
- (instancetype)initWithName:(NSString *)name
				 description:(nullable NSString *)desc
				   ascending:(BOOL)ascending NS_UNAVAILABLE;
- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

@end

NS_ASSUME_NONNULL_END
