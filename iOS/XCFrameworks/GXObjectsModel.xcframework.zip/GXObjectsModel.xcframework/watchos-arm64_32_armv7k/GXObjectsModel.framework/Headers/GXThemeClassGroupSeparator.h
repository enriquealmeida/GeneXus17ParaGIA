//
//  GXThemeClassGroupSeparator.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 05/01/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

#import <GXObjectsModel/GXThemeClassBase.h>
#import <GXObjectsModel/GXThemeClassWithPadding.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXThemeClassGroupSeparator : GXThemeClassBase
@end

NS_ASSUME_NONNULL_END
