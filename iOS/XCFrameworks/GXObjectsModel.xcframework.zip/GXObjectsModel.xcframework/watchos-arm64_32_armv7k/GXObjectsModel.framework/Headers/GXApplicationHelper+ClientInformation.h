//
//  GXApplicationHelper+ClientInformation.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 28/12/15.
//  Copyright © 2015 GeneXus. All rights reserved.
//

#import <GXObjectsModel/GXApplicationHelper.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXApplicationHelper (ClientInformation)

+ (void)setClientInfoHeaders:(NSMutableURLRequest *)urlRequest;

@end

NS_ASSUME_NONNULL_END
