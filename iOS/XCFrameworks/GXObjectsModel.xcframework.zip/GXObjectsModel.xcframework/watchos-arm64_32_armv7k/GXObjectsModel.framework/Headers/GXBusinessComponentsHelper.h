//
//  GXBusinessComponentsHelper.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 30/09/11.
//  Copyright (c) 2011 Artech. All rights reserved.
//

@import Foundation;
#import <GXObjectsModel/GXBusinessComponentLevel.h>

@interface GXBusinessComponentsHelper : NSObject

+ (GXBusinessComponentLevel *)businessComponentLevelRootForBusinessComponentWithName:(NSString *)bcName;

+ (GXBusinessComponentLevel *)businessComponentLevelWithName:(NSString *)levelName
								forBusinessComponentWithName:(NSString *)bcName;

+ (GXBusinessComponentModel *)businessComponentModelForBusinessComponentWithName:(NSString *)bcName;

@end
