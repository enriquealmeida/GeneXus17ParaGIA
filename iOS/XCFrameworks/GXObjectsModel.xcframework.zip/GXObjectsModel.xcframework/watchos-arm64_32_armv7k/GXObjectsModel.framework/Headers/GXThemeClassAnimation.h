//
//  GXThemeClassAnimation.h
//  GXObjectsModel
//
//  Created by Fabian Inthamoussu on 8/8/17.
//  Copyright © 2017 GeneXus. All rights reserved.
//

#import <GXObjectsModel/GXThemeClass.h>
@import GXFoundation;

NS_ASSUME_NONNULL_BEGIN

@interface GXThemeClassAnimation : GXThemeClass
@end

NS_ASSUME_NONNULL_END
