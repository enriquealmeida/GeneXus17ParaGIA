//
//  GXThemeHelper.h
//  GXObjectsModel
//
//  Created by Fabian Inthamoussu on 17/11/15.
//  Copyright © 2015 GeneXus. All rights reserved.
//

@import GXFoundation;

@interface GXStyleHelper : NSObject
@end

@interface GXThemeHelper : GXStyleHelper
@end
