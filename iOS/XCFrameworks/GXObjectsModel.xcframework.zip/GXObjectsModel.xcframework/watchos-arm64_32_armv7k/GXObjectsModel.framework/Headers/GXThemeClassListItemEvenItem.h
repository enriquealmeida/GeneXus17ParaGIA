//
//  GXThemeClassListItemEvenItem.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 26/04/11.
//  Copyright 2011 Artech. All rights reserved.
//

#import <GXObjectsModel/GXThemeClassListItem.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXThemeClassListItemEvenItem : GXThemeClassListItem
@end

NS_ASSUME_NONNULL_END
