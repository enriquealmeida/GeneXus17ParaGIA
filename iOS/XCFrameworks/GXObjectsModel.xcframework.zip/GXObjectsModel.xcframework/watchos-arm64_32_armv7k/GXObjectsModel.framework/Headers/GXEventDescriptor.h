//
//  GXEventDescriptor.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 23/11/15.
//  Copyright © 2015 Artech. All rights reserved.
//

#import <GXObjectsModel/GXNamedElement.h>
#import <GXObjectsModel/GXEventDescriptorProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXEventDescriptor : GXNamedElement <GXEventDescriptor>

- (instancetype)initWithName:(NSString *)name
				   eventType:(GXEventType)type
		 eventParametersDesc:(nullable id <GXActionParametersDescriptor>)eventParametersDesc
			  rootActionDesc:(nullable id <GXEventActionDescriptor>)rootActionDesc; // GXActionErrorHandlingModeComposite

- (instancetype)initWithName:(NSString *)name
				   eventType:(GXEventType)type
		 eventParametersDesc:(nullable id <GXActionParametersDescriptor>)eventParametersDesc
			  rootActionDesc:(nullable id <GXEventActionDescriptor>)rootActionDesc
		   errorHandlingMode:(GXActionErrorHandlingMode)errorHandlingMode NS_DESIGNATED_INITIALIZER;

- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithName:(nullable NSString *)name NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
