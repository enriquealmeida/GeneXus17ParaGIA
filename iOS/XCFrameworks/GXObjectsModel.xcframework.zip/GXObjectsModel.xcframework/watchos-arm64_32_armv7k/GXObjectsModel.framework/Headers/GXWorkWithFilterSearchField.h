//
//  GXWorkWithFilterSearchField.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 22/11/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

@import Foundation;
#import <GXObjectsModel/GXDescriptionElement.h>
#import <GXObjectsModel/GXEntityListFilterSearchProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@class GXTypedObjectInfo;

@interface GXWorkWithFilterSearchField : GXDescriptionElement <GXEntityListFilterSearchField>

- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithName:(nullable NSString *)name NS_UNAVAILABLE;

@end


@interface GXWorkWithFilterSearchFieldAttribute : GXWorkWithFilterSearchField <GXEntityDataFieldAttributeDescriptor>
@end


@interface GXWorkWithFilterSearchFieldVariable : GXWorkWithFilterSearchField <GXEntityDataFieldVariableDescriptor>

@property(nonatomic, strong, readonly) GXTypedObjectInfo *typedObjectInfo;


- (instancetype)initWithTypedObjectInfo:(GXTypedObjectInfo *)typedObjectInfo
							description:(NSString *)desc NS_DESIGNATED_INITIALIZER;

- (instancetype)initWithName:(nullable NSString *)name description:(nullable NSString *)desc NS_UNAVAILABLE;
- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

@end

NS_ASSUME_NONNULL_END
