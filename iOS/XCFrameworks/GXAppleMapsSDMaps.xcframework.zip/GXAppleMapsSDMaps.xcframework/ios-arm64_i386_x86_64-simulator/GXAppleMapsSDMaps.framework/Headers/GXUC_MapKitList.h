//
//  GXUC_MapKitList.h
//  GXFlexibleClient
//
//  Created by willy on 1/28/11.
//  Copyright 2011 Artech. All rights reserved.
//

@import MapKit;
@import GXCoreUI;
@import GXUCMaps;

NS_ASSUME_NONNULL_BEGIN

@interface GXUC_MapKitList : GXUC_MapList <MKMapViewDelegate, GXUC_MapKitListCalloutAnnotationViewDelegate>

@property(nullable, nonatomic, strong, readonly) GXMKMapView *mapView;

@end

NS_ASSUME_NONNULL_END
