//
//  GXTimeZone.h
//  GXFoundation
//
//  Created by Fabian Inthamoussu on 21/4/22.
//  Copyright © 2022 GeneXus. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

@interface GXTimeZone : NSObject

@end

NS_ASSUME_NONNULL_END
