//
//  GXUIApplicationClass.h
//  GXUIApplication
//
//  Created by José Echagüe on 1/5/22.
//  Copyright © 2022 GeneXus. All rights reserved.
//

@import UIKit;

@interface GXUIApplicationClass : UIApplication

@end
