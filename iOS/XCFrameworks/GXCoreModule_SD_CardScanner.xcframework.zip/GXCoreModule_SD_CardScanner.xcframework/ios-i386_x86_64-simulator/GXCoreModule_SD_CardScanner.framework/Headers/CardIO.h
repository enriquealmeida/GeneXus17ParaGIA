//
//  CardIO.h
//  Version 5.4.1
//
//  See the file "LICENSE.md" for the full license governing this code.
//

// All-in-one header file for card.io sdk.
#import <GXCoreModule_SD_CardScanner/CardIOCreditCardInfo.h>
#import <GXCoreModule_SD_CardScanner/CardIODetectionMode.h>
#import <GXCoreModule_SD_CardScanner/CardIOView.h>
#import <GXCoreModule_SD_CardScanner/CardIOViewDelegate.h>
#import <GXCoreModule_SD_CardScanner/CardIOPaymentViewController.h>
#import <GXCoreModule_SD_CardScanner/CardIOPaymentViewControllerDelegate.h>
#import <GXCoreModule_SD_CardScanner/CardIOUtilities.h>
