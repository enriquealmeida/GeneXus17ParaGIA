//
//  GXEOAlipayInvokeExtensionLibrary.h
//  GXEOAlipayInvoke
//
//  Created by Marcos Crispino on 1/9/17.
//  Copyright © 2017 GeneXus. All rights reserved.
//

@import Foundation;
@import GXCoreBL;

@interface GXEOAlipayInvokeExtensionLibrary : NSObject <GXExtensionLibraryProtocol>

@end
