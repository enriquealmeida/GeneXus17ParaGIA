//
//  GXEOGeolocationHandlerHelper.h
//  GXCoreModule_Common_GeoLocation
//
//  Created by José Echagüe on 2/20/19.
//  Copyright © 2019 GeneXus. All rights reserved.
//

@import Foundation;
@import GXCoreBL;
@import GXFoundation;
@import GXObjectsModel;

NS_ASSUME_NONNULL_BEGIN

@interface GXEOGeolocationHandlerHelper : NSObject

@property(class, readonly) GXEOGeolocationHandlerHelper *sharedInstance;
@property(class, readonly) GXEOGeolocationHandlerHelper *compatibleSharedInstance;


- (void)cancelExecution;

- (void)releaseGeolocationEO;

- (void)authorizedForEOHandler:(GXActionExternalObjectHandler *)eoHandler;

- (void)serviceEnabledForEOHandler:(GXActionExternalObjectHandler *)eoHandler;

- (void)authorizationStatusForEOHandler:(GXActionExternalObjectHandler *)eoHandler;

#pragma mark - Proximity Alerts

- (void)setProximityAlertsForEOHandler:(GXActionExternalObjectHandler *)eoHandler
					   	withParameters:(NSArray *)parameters NS_SWIFT_NAME(setProximityAlerts(forEOHandler:withParamters:));

- (void)getProximityAlertsForEOHandler:(GXActionExternalObjectHandler *)eoHandler;

- (void)clearProximityAlertsForEOHandler:(GXActionExternalObjectHandler *)eoHandler;

- (void)getCurrentProximityAlertForEOHandler:(GXActionExternalObjectHandler *)eoHandler;

#pragma mark - Location

- (void)getLatitudeForEOHandler:(GXActionExternalObjectHandler *)eoHandler
				 withParameters:(NSArray *)parameters NS_SWIFT_NAME(getLatitude(forEOHandler:withParamters:));

- (void)getLongitudeForEOHandler:(GXActionExternalObjectHandler *)eoHandler
				  withParameters:(NSArray *)parameters NS_SWIFT_NAME(getLongitude(forEOHandler:withParamters:));

- (void)getDistanceForEOHandler:(GXActionExternalObjectHandler *)eoHandler
				 withParameters:(NSArray *)parameters NS_SWIFT_NAME(getDistance(forEOHandler:withParamters:));

- (void)geocodeAddressForEOHandler:(GXActionExternalObjectHandler *)eoHandler
				withParameters:(NSArray *)parameters NS_SWIFT_NAME(geocodeAddress(forEOHandler:withParamters:));

- (void)reverseGeocodeLocationForEOHandler:(GXActionExternalObjectHandler *)eoHandler
					 withParameters:(NSArray *)parameters NS_SWIFT_NAME(reverseGeocodeLocation(forEOHandler:withParamters:));

- (void)getLocationForEOHandler:(GXActionExternalObjectHandler *)eoHandler
				 withParameters:(NSArray *)parameters NS_SWIFT_NAME(getLocation(forEOHandler:withParamters:));

#pragma mark - Location Tracking

- (void)startTrackingForEOHandler:(GXActionExternalObjectHandler *)eoHandler
				   withParameters:(NSArray *)parameters;

- (void)endTrackingForEOHandler:(GXActionExternalObjectHandler *)eoHandler;

- (void)getLocationHistoryForEOHandler:(GXActionExternalObjectHandler *)eoHandler
						withParameters:(NSArray *)parameters;

- (void)clearLocationHistoryForEOHandler:(GXActionExternalObjectHandler *)eoHandler;

#pragma mark - Pick Location

#if TARGET_OS_IOS || TARGET_OS_TV
- (void)pickLocationForEOHandler:(GXActionExternalObjectHandler *)eoHandler
				  withParameters:(NSArray *)parameters;
#endif // TARGET_OS_IOS || TARGET_OS_TV

@end

NS_ASSUME_NONNULL_END
