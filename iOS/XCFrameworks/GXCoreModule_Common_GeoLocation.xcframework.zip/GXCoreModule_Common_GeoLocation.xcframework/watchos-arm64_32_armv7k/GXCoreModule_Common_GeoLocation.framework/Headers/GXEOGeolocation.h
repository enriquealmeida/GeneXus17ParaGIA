//
//  GXEOGeolocation.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 1/3/13.
//  Copyright (c) 2013 Artech. All rights reserved.
//

@import GXFoundation;
@import GXObjectsModel;
@import GXStandardClasses;
@import GXCoreBL;
@import CoreLocation;

NS_ASSUME_NONNULL_BEGIN

@interface GXEOGeolocation : GXExternalObjectBase <CLLocationManagerDelegate>

@property(nonatomic, assign, readonly) BOOL geolocationCompatibilityFlag;
@property(nonatomic, strong, readonly) NSString *proximityAlertsSDTName;

- (instancetype)initWithGeolocationCompatibilityFlag:(BOOL)geolocationCompatibilityFlag NS_DESIGNATED_INITIALIZER;

+ (GXAuthorizationStatusType)authorizationStatus;

+ (BOOL)locationServicesAuthorized;

+ (BOOL)locationServicesEnabled;

- (id<GXSDTData>)getmylocation:(NSArray *)params;

- (NSDecimalNumber *)getlatitude:(NSArray *)params;

- (NSDecimalNumber *)getlongitude:(NSArray *)params;

- (NSDecimalNumber *)getdistance:(NSArray *)params;

- (NSArray *)getAddressAsArrary:(NSArray *)params;
- (GXObjectCollection *)getaddress:(NSArray *)params;

- (NSArray *)getLocationAsArray:(NSArray *)params;
- (GXObjectCollection *)getlocation:(NSArray *)params;

- (BOOL)setproximityalerts:(NSArray *)params;

- (GXObjectCollection *)getproximityalerts;

- (null_unspecified id<GXSDTData>)getcurrentproximityalert;

- (void)clearproximityalerts;

+ (NSString *)proximityAlertsSDTNameWithCompatibilityFlag:(BOOL)compatibilityFlag;

@end

NS_ASSUME_NONNULL_END
