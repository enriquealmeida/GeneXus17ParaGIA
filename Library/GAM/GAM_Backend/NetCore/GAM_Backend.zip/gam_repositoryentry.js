/*
               File: GAM_RepositoryEntry
        Description: Repository
             Author: GeneXus .NET Generator version 17_0_10-161416
       Generated on: 6/23/2022 0:54:12.94
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_repositoryentry', false, function () {
   this.ServerClass =  "gam_repositoryentry" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_repositoryentry.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = true;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
      this.AV28Id=gx.fn.getIntegerValue("vID",gx.thousandSeparator) ;
      this.Gx_mode=gx.fn.getControlValue("vMODE") ;
      this.AV9AllowOauthAccess=gx.fn.getControlValue("vALLOWOAUTHACCESS") ;
   };
   this.Validv_Generatesessionstatistics=function()
   {
      return this.validCliEvt("Validv_Generatesessionstatistics", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vGENERATESESSIONSTATISTICS");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV25GenerateSessionStatistics , "None" ) == 0 || gx.text.compare( this.AV25GenerateSessionStatistics , "Minimum" ) == 0 || gx.text.compare( this.AV25GenerateSessionStatistics , "Detail" ) == 0 || gx.text.compare( this.AV25GenerateSessionStatistics , "Full" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Generate session statistics"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.e151k1_client=function()
   {
      /* Copyapplicationrolepermissions_Click Routine */
      this.clearMessages();
      if ( this.AV15CopyApplicationRolePermissions )
      {
         this.AV18CopyRoles =  true  ;
         this.AV14CopyApplication =  true  ;
         gx.fn.setCtrlProperty("ADMINROLEIDCELL","Visible", true );
         gx.fn.setCtrlProperty("COPYFROMMAPPIDCELL","Visible", true );
      }
      this.refreshOutputs([{av:'AV18CopyRoles',fld:'vCOPYROLES',pic:''},{av:'AV14CopyApplication',fld:'vCOPYAPPLICATION',pic:''},{av:'gx.fn.getCtrlProperty("ADMINROLEIDCELL","Visible")',ctrl:'ADMINROLEIDCELL',prop:'Visible'},{av:'gx.fn.getCtrlProperty("COPYFROMMAPPIDCELL","Visible")',ctrl:'COPYFROMMAPPIDCELL',prop:'Visible'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e161k1_client=function()
   {
      /* Copyroles_Click Routine */
      this.clearMessages();
      if ( this.AV18CopyRoles )
      {
         gx.fn.setCtrlProperty("ADMINROLEIDCELL","Visible", true );
      }
      else
      {
         this.AV15CopyApplicationRolePermissions =  false  ;
         this.AV14CopyApplication =  false  ;
         gx.fn.setCtrlProperty("ADMINROLEIDCELL","Visible", false );
         gx.fn.setCtrlProperty("COPYFROMMAPPIDCELL","Visible", false );
      }
      this.refreshOutputs([{av:'AV15CopyApplicationRolePermissions',fld:'vCOPYAPPLICATIONROLEPERMISSIONS',pic:''},{av:'AV14CopyApplication',fld:'vCOPYAPPLICATION',pic:''},{av:'gx.fn.getCtrlProperty("COPYFROMMAPPIDCELL","Visible")',ctrl:'COPYFROMMAPPIDCELL',prop:'Visible'},{av:'gx.fn.getCtrlProperty("ADMINROLEIDCELL","Visible")',ctrl:'ADMINROLEIDCELL',prop:'Visible'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e171k1_client=function()
   {
      /* Copyapplication_Click Routine */
      this.clearMessages();
      if ( this.AV14CopyApplication )
      {
         gx.fn.setCtrlProperty("COPYFROMMAPPIDCELL","Visible", true );
      }
      else
      {
         this.AV15CopyApplicationRolePermissions =  false  ;
         this.AV18CopyRoles =  false  ;
         gx.fn.setCtrlProperty("ADMINROLEIDCELL","Visible", false );
         gx.fn.setCtrlProperty("COPYFROMMAPPIDCELL","Visible", false );
      }
      this.refreshOutputs([{av:'AV15CopyApplicationRolePermissions',fld:'vCOPYAPPLICATIONROLEPERMISSIONS',pic:''},{av:'AV18CopyRoles',fld:'vCOPYROLES',pic:''},{av:'gx.fn.getCtrlProperty("ADMINROLEIDCELL","Visible")',ctrl:'ADMINROLEIDCELL',prop:'Visible'},{av:'gx.fn.getCtrlProperty("COPYFROMMAPPIDCELL","Visible")',ctrl:'COPYFROMMAPPIDCELL',prop:'Visible'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e121k2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e131k2_client=function()
   {
      /* Usecurrentrepositorasmasterauthentication_Click Routine */
      return this.executeServerEvent("VUSECURRENTREPOSITORASMASTERAUTHENTICATION.CLICK", true, null, false, true);
   };
   this.e181k1_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,13,14,17,18,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,111,112,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159];
   this.GXLastCtrlId =159;
   this.TAB2Container = gx.uc.getNew(this, 15, 0, "gx.ui.controls.Tab", "TAB2Container", "Tab2", "TAB2");
   var TAB2Container = this.TAB2Container;
   TAB2Container.setProp("Enabled", "Enabled", true, "boolean");
   TAB2Container.setProp("ActivePage", "Activepage", '', "int");
   TAB2Container.setProp("ActivePageControlName", "Activepagecontrolname", "", "char");
   TAB2Container.setProp("PageCount", "Pagecount", 2, "num");
   TAB2Container.setProp("Class", "Class", "Tab", "str");
   TAB2Container.setProp("HistoryManagement", "Historymanagement", false, "bool");
   TAB2Container.setProp("Visible", "Visible", true, "bool");
   TAB2Container.setC2ShowFunction(function(UC) { UC.show(); });
   this.setUserControl(TAB2Container);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLE1",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TEXTBLOCK1", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"GENERAL_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"TAB1",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"GUIDCELL",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id:25 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGUID",fmt:0,gxz:"ZV27GUID",gxold:"OV27GUID",gxvar:"AV27GUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV27GUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV27GUID=Value},v2c:function(){gx.fn.setControlValue("vGUID",gx.O.AV27GUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV27GUID=this.val()},val:function(){return gx.fn.getControlValue("vGUID")},nac:gx.falseFn};
   this.declareDomainHdlr( 25 , function() {
   });
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id:30 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV31Name",gxold:"OV31Name",gxvar:"AV31Name",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV31Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV31Name=Value},v2c:function(){gx.fn.setControlValue("vNAME",gx.O.AV31Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV31Name=this.val()},val:function(){return gx.fn.getControlValue("vNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 30 , function() {
   });
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id:35 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDESCRIPTION",fmt:0,gxz:"ZV21Description",gxold:"OV21Description",gxvar:"AV21Description",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV21Description=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV21Description=Value},v2c:function(){gx.fn.setControlValue("vDESCRIPTION",gx.O.AV21Description,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV21Description=this.val()},val:function(){return gx.fn.getControlValue("vDESCRIPTION")},nac:gx.falseFn};
   this.declareDomainHdlr( 35 , function() {
   });
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"",grid:0};
   GXValidFnc[38]={ id: 38, fld:"",grid:0};
   GXValidFnc[39]={ id: 39, fld:"",grid:0};
   GXValidFnc[40]={ id:40 ,lvl:0,type:"boolean",len:4,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSECURRENTREPOSITORASMASTERAUTHENTICATION",fmt:0,gxz:"ZV40UseCurrentRepositorAsMasterAuthentication",gxold:"OV40UseCurrentRepositorAsMasterAuthentication",gxvar:"AV40UseCurrentRepositorAsMasterAuthentication",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV40UseCurrentRepositorAsMasterAuthentication=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV40UseCurrentRepositorAsMasterAuthentication=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vUSECURRENTREPOSITORASMASTERAUTHENTICATION",gx.O.AV40UseCurrentRepositorAsMasterAuthentication,true)},c2v:function(){if(this.val()!==undefined)gx.O.AV40UseCurrentRepositorAsMasterAuthentication=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vUSECURRENTREPOSITORASMASTERAUTHENTICATION")},nac:gx.falseFn,evt:"e131k2_client",values:['true','false']};
   GXValidFnc[41]={ id: 41, fld:"",grid:0};
   GXValidFnc[42]={ id: 42, fld:"NAMESPACECELL",grid:0};
   GXValidFnc[43]={ id: 43, fld:"",grid:0};
   GXValidFnc[44]={ id: 44, fld:"",grid:0};
   GXValidFnc[45]={ id:45 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAMESPACE",fmt:0,gxz:"ZV32NameSpace",gxold:"OV32NameSpace",gxvar:"AV32NameSpace",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV32NameSpace=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV32NameSpace=Value},v2c:function(){gx.fn.setControlValue("vNAMESPACE",gx.O.AV32NameSpace,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV32NameSpace=this.val()},val:function(){return gx.fn.getControlValue("vNAMESPACE")},nac:gx.falseFn};
   this.declareDomainHdlr( 45 , function() {
   });
   GXValidFnc[46]={ id: 46, fld:"",grid:0};
   GXValidFnc[47]={ id: 47, fld:"",grid:0};
   GXValidFnc[48]={ id: 48, fld:"",grid:0};
   GXValidFnc[49]={ id: 49, fld:"",grid:0};
   GXValidFnc[50]={ id:50 ,lvl:0,type:"char",len:20,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Generatesessionstatistics,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGENERATESESSIONSTATISTICS",fmt:0,gxz:"ZV25GenerateSessionStatistics",gxold:"OV25GenerateSessionStatistics",gxvar:"AV25GenerateSessionStatistics",ucs:[],op:[50],ip:[50],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV25GenerateSessionStatistics=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV25GenerateSessionStatistics=Value},v2c:function(){gx.fn.setComboBoxValue("vGENERATESESSIONSTATISTICS",gx.O.AV25GenerateSessionStatistics);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV25GenerateSessionStatistics=this.val()},val:function(){return gx.fn.getControlValue("vGENERATESESSIONSTATISTICS")},nac:gx.falseFn};
   this.declareDomainHdlr( 50 , function() {
   });
   GXValidFnc[51]={ id: 51, fld:"",grid:0};
   GXValidFnc[52]={ id: 52, fld:"",grid:0};
   GXValidFnc[53]={ id: 53, fld:"TBLUSERSSETTINGS",grid:0};
   GXValidFnc[54]={ id: 54, fld:"",grid:0};
   GXValidFnc[55]={ id: 55, fld:"",grid:0};
   GXValidFnc[56]={ id: 56, fld:"",grid:0};
   GXValidFnc[57]={ id: 57, fld:"",grid:0};
   GXValidFnc[58]={ id:58 ,lvl:0,type:"char",len:100,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCONNECTIONUSERNAME",fmt:0,gxz:"ZV12ConnectionUserName",gxold:"OV12ConnectionUserName",gxvar:"AV12ConnectionUserName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV12ConnectionUserName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12ConnectionUserName=Value},v2c:function(){gx.fn.setControlValue("vCONNECTIONUSERNAME",gx.O.AV12ConnectionUserName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV12ConnectionUserName=this.val()},val:function(){return gx.fn.getControlValue("vCONNECTIONUSERNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 58 , function() {
   });
   GXValidFnc[59]={ id: 59, fld:"",grid:0};
   GXValidFnc[60]={ id: 60, fld:"",grid:0};
   GXValidFnc[61]={ id: 61, fld:"",grid:0};
   GXValidFnc[62]={ id: 62, fld:"",grid:0};
   GXValidFnc[63]={ id:63 ,lvl:0,type:"char",len:254,dec:0,sign:false,isPwd:true,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCONNECTIONUSERPASSWORD",fmt:0,gxz:"ZV13ConnectionUserPassword",gxold:"OV13ConnectionUserPassword",gxvar:"AV13ConnectionUserPassword",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV13ConnectionUserPassword=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV13ConnectionUserPassword=Value},v2c:function(){gx.fn.setControlValue("vCONNECTIONUSERPASSWORD",gx.O.AV13ConnectionUserPassword,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV13ConnectionUserPassword=this.val()},val:function(){return gx.fn.getControlValue("vCONNECTIONUSERPASSWORD")},nac:gx.falseFn};
   GXValidFnc[64]={ id: 64, fld:"",grid:0};
   GXValidFnc[65]={ id: 65, fld:"",grid:0};
   GXValidFnc[66]={ id: 66, fld:"",grid:0};
   GXValidFnc[67]={ id: 67, fld:"",grid:0};
   GXValidFnc[68]={ id:68 ,lvl:0,type:"char",len:254,dec:0,sign:false,isPwd:true,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCONFCONNECTIONUSERPASSWORD",fmt:0,gxz:"ZV11ConfConnectionUserPassword",gxold:"OV11ConfConnectionUserPassword",gxvar:"AV11ConfConnectionUserPassword",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV11ConfConnectionUserPassword=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV11ConfConnectionUserPassword=Value},v2c:function(){gx.fn.setControlValue("vCONFCONNECTIONUSERPASSWORD",gx.O.AV11ConfConnectionUserPassword,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV11ConfConnectionUserPassword=this.val()},val:function(){return gx.fn.getControlValue("vCONFCONNECTIONUSERPASSWORD")},nac:gx.falseFn};
   GXValidFnc[69]={ id: 69, fld:"",grid:0};
   GXValidFnc[70]={ id: 70, fld:"",grid:0};
   GXValidFnc[71]={ id: 71, fld:"TBLUSECURRENTASMASTERREPOSITORY",grid:0};
   GXValidFnc[72]={ id: 72, fld:"",grid:0};
   GXValidFnc[73]={ id: 73, fld:"",grid:0};
   GXValidFnc[74]={ id: 74, fld:"",grid:0};
   GXValidFnc[75]={ id: 75, fld:"",grid:0};
   GXValidFnc[76]={ id:76 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vAUTHENTICATIONMASTERAUTHTYPENAME",fmt:0,gxz:"ZV42AuthenticationMasterAuthTypeName",gxold:"OV42AuthenticationMasterAuthTypeName",gxvar:"AV42AuthenticationMasterAuthTypeName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV42AuthenticationMasterAuthTypeName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV42AuthenticationMasterAuthTypeName=Value},v2c:function(){gx.fn.setControlValue("vAUTHENTICATIONMASTERAUTHTYPENAME",gx.O.AV42AuthenticationMasterAuthTypeName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV42AuthenticationMasterAuthTypeName=this.val()},val:function(){return gx.fn.getControlValue("vAUTHENTICATIONMASTERAUTHTYPENAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 76 , function() {
   });
   GXValidFnc[77]={ id: 77, fld:"",grid:0};
   GXValidFnc[78]={ id: 78, fld:"",grid:0};
   GXValidFnc[79]={ id: 79, fld:"",grid:0};
   GXValidFnc[80]={ id: 80, fld:"",grid:0};
   GXValidFnc[81]={ id:81 ,lvl:0,type:"char",len:100,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vADMINISTRATORUSERNAME",fmt:0,gxz:"ZV7AdministratorUserName",gxold:"OV7AdministratorUserName",gxvar:"AV7AdministratorUserName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV7AdministratorUserName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV7AdministratorUserName=Value},v2c:function(){gx.fn.setControlValue("vADMINISTRATORUSERNAME",gx.O.AV7AdministratorUserName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV7AdministratorUserName=this.val()},val:function(){return gx.fn.getControlValue("vADMINISTRATORUSERNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 81 , function() {
   });
   GXValidFnc[82]={ id: 82, fld:"",grid:0};
   GXValidFnc[83]={ id: 83, fld:"",grid:0};
   GXValidFnc[84]={ id: 84, fld:"",grid:0};
   GXValidFnc[85]={ id: 85, fld:"",grid:0};
   GXValidFnc[86]={ id:86 ,lvl:0,type:"char",len:254,dec:0,sign:false,isPwd:true,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vADMINISTRATORUSERPASSWORD",fmt:0,gxz:"ZV8AdministratorUserPassword",gxold:"OV8AdministratorUserPassword",gxvar:"AV8AdministratorUserPassword",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV8AdministratorUserPassword=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV8AdministratorUserPassword=Value},v2c:function(){gx.fn.setControlValue("vADMINISTRATORUSERPASSWORD",gx.O.AV8AdministratorUserPassword,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV8AdministratorUserPassword=this.val()},val:function(){return gx.fn.getControlValue("vADMINISTRATORUSERPASSWORD")},nac:gx.falseFn};
   this.declareDomainHdlr( 86 , function() {
   });
   GXValidFnc[87]={ id: 87, fld:"",grid:0};
   GXValidFnc[88]={ id: 88, fld:"",grid:0};
   GXValidFnc[89]={ id: 89, fld:"",grid:0};
   GXValidFnc[90]={ id: 90, fld:"",grid:0};
   GXValidFnc[91]={ id:91 ,lvl:0,type:"char",len:254,dec:0,sign:false,isPwd:true,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCONFADMINISTRATORUSERPASSWORD",fmt:0,gxz:"ZV10ConfAdministratorUserPassword",gxold:"OV10ConfAdministratorUserPassword",gxvar:"AV10ConfAdministratorUserPassword",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV10ConfAdministratorUserPassword=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV10ConfAdministratorUserPassword=Value},v2c:function(){gx.fn.setControlValue("vCONFADMINISTRATORUSERPASSWORD",gx.O.AV10ConfAdministratorUserPassword,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV10ConfAdministratorUserPassword=this.val()},val:function(){return gx.fn.getControlValue("vCONFADMINISTRATORUSERPASSWORD")},nac:gx.falseFn};
   this.declareDomainHdlr( 91 , function() {
   });
   GXValidFnc[92]={ id: 92, fld:"",grid:0};
   GXValidFnc[93]={ id: 93, fld:"",grid:0};
   GXValidFnc[94]={ id: 94, fld:"TBUPDCONNFILE",grid:0};
   GXValidFnc[95]={ id: 95, fld:"",grid:0};
   GXValidFnc[96]={ id: 96, fld:"",grid:0};
   GXValidFnc[97]={ id: 97, fld:"",grid:0};
   GXValidFnc[98]={ id: 98, fld:"",grid:0};
   GXValidFnc[99]={ id:99 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUPDATECONNECTIONFILE",fmt:0,gxz:"ZV39UpdateConnectionFile",gxold:"OV39UpdateConnectionFile",gxvar:"AV39UpdateConnectionFile",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV39UpdateConnectionFile=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV39UpdateConnectionFile=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vUPDATECONNECTIONFILE",gx.O.AV39UpdateConnectionFile,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV39UpdateConnectionFile=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vUPDATECONNECTIONFILE")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 99 , function() {
   });
   GXValidFnc[100]={ id: 100, fld:"",grid:0};
   GXValidFnc[101]={ id: 101, fld:"",grid:0};
   GXValidFnc[102]={ id: 102, fld:"",grid:0};
   GXValidFnc[103]={ id: 103, fld:"",grid:0};
   GXValidFnc[104]={ id:104 ,lvl:0,type:"boolean",len:4,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vISGAMADMINACCESSREPOSITORY",fmt:0,gxz:"ZV29isGAMAdminAccessRepository",gxold:"OV29isGAMAdminAccessRepository",gxvar:"AV29isGAMAdminAccessRepository",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV29isGAMAdminAccessRepository=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV29isGAMAdminAccessRepository=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vISGAMADMINACCESSREPOSITORY",gx.O.AV29isGAMAdminAccessRepository,true)},c2v:function(){if(this.val()!==undefined)gx.O.AV29isGAMAdminAccessRepository=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vISGAMADMINACCESSREPOSITORY")},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[105]={ id: 105, fld:"",grid:0};
   GXValidFnc[106]={ id: 106, fld:"",grid:0};
   GXValidFnc[107]={ id: 107, fld:"",grid:0};
   GXValidFnc[108]={ id: 108, fld:"",grid:0};
   GXValidFnc[109]={ id:109 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCREATEGAMAPPLICATION",fmt:0,gxz:"ZV20CreateGAMApplication",gxold:"OV20CreateGAMApplication",gxvar:"AV20CreateGAMApplication",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV20CreateGAMApplication=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV20CreateGAMApplication=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCREATEGAMAPPLICATION",gx.O.AV20CreateGAMApplication,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV20CreateGAMApplication=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCREATEGAMAPPLICATION")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 109 , function() {
   });
   GXValidFnc[111]={ id: 111, fld:"COPYREPOSITORYDATA_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[112]={ id: 112, fld:"",grid:0};
   GXValidFnc[114]={ id: 114, fld:"TABPAGE3TABLE",grid:0};
   GXValidFnc[115]={ id: 115, fld:"",grid:0};
   GXValidFnc[116]={ id: 116, fld:"",grid:0};
   GXValidFnc[117]={ id: 117, fld:"COPYAPPLICATIONTABLE",grid:0};
   GXValidFnc[118]={ id: 118, fld:"",grid:0};
   GXValidFnc[119]={ id: 119, fld:"",grid:0};
   GXValidFnc[120]={ id: 120, fld:"",grid:0};
   GXValidFnc[121]={ id: 121, fld:"",grid:0};
   GXValidFnc[122]={ id:122 ,lvl:0,type:"int",len:9,dec:0,sign:false,pic:"ZZZZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCOPYFROMREPOSITORYID",fmt:0,gxz:"ZV17CopyFromRepositoryId",gxold:"OV17CopyFromRepositoryId",gxvar:"AV17CopyFromRepositoryId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV17CopyFromRepositoryId=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV17CopyFromRepositoryId=gx.num.intval(Value)},v2c:function(){gx.fn.setComboBoxValue("vCOPYFROMREPOSITORYID",gx.O.AV17CopyFromRepositoryId);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV17CopyFromRepositoryId=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vCOPYFROMREPOSITORYID",gx.thousandSeparator)},nac:gx.falseFn};
   this.declareDomainHdlr( 122 , function() {
   });
   GXValidFnc[123]={ id: 123, fld:"",grid:0};
   GXValidFnc[124]={ id: 124, fld:"",grid:0};
   GXValidFnc[125]={ id: 125, fld:"",grid:0};
   GXValidFnc[126]={ id: 126, fld:"",grid:0};
   GXValidFnc[127]={ id:127 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCOPYROLES",fmt:0,gxz:"ZV18CopyRoles",gxold:"OV18CopyRoles",gxvar:"AV18CopyRoles",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV18CopyRoles=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV18CopyRoles=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCOPYROLES",gx.O.AV18CopyRoles,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV18CopyRoles=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCOPYROLES")},nac:gx.falseFn,evt:"e161k1_client",values:['true','false']};
   this.declareDomainHdlr( 127 , function() {
   });
   GXValidFnc[128]={ id: 128, fld:"",grid:0};
   GXValidFnc[129]={ id: 129, fld:"ADMINROLEIDCELL",grid:0};
   GXValidFnc[130]={ id: 130, fld:"",grid:0};
   GXValidFnc[131]={ id: 131, fld:"",grid:0};
   GXValidFnc[132]={ id:132 ,lvl:0,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vADMINISTRATORROLEID",fmt:0,gxz:"ZV6AdministratorRoleId",gxold:"OV6AdministratorRoleId",gxvar:"AV6AdministratorRoleId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV6AdministratorRoleId=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV6AdministratorRoleId=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vADMINISTRATORROLEID",gx.O.AV6AdministratorRoleId,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV6AdministratorRoleId=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vADMINISTRATORROLEID",gx.thousandSeparator)},nac:gx.falseFn};
   this.declareDomainHdlr( 132 , function() {
   });
   GXValidFnc[133]={ id: 133, fld:"",grid:0};
   GXValidFnc[134]={ id: 134, fld:"",grid:0};
   GXValidFnc[135]={ id: 135, fld:"",grid:0};
   GXValidFnc[136]={ id: 136, fld:"",grid:0};
   GXValidFnc[137]={ id:137 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCOPYSECURITYPOLICIES",fmt:0,gxz:"ZV19CopySecurityPolicies",gxold:"OV19CopySecurityPolicies",gxvar:"AV19CopySecurityPolicies",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV19CopySecurityPolicies=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV19CopySecurityPolicies=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCOPYSECURITYPOLICIES",gx.O.AV19CopySecurityPolicies,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV19CopySecurityPolicies=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCOPYSECURITYPOLICIES")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 137 , function() {
   });
   GXValidFnc[138]={ id: 138, fld:"",grid:0};
   GXValidFnc[139]={ id: 139, fld:"",grid:0};
   GXValidFnc[140]={ id: 140, fld:"",grid:0};
   GXValidFnc[141]={ id: 141, fld:"",grid:0};
   GXValidFnc[142]={ id:142 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCOPYAPPLICATION",fmt:0,gxz:"ZV14CopyApplication",gxold:"OV14CopyApplication",gxvar:"AV14CopyApplication",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV14CopyApplication=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV14CopyApplication=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCOPYAPPLICATION",gx.O.AV14CopyApplication,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV14CopyApplication=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCOPYAPPLICATION")},nac:gx.falseFn,evt:"e171k1_client",values:['true','false']};
   this.declareDomainHdlr( 142 , function() {
   });
   GXValidFnc[143]={ id: 143, fld:"",grid:0};
   GXValidFnc[144]={ id: 144, fld:"COPYFROMMAPPIDCELL",grid:0};
   GXValidFnc[145]={ id: 145, fld:"",grid:0};
   GXValidFnc[146]={ id: 146, fld:"",grid:0};
   GXValidFnc[147]={ id:147 ,lvl:0,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCOPYFROMAPPLICATIONID",fmt:0,gxz:"ZV16CopyFromApplicationId",gxold:"OV16CopyFromApplicationId",gxvar:"AV16CopyFromApplicationId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV16CopyFromApplicationId=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV16CopyFromApplicationId=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vCOPYFROMAPPLICATIONID",gx.O.AV16CopyFromApplicationId,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV16CopyFromApplicationId=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vCOPYFROMAPPLICATIONID",gx.thousandSeparator)},nac:gx.falseFn};
   this.declareDomainHdlr( 147 , function() {
   });
   GXValidFnc[148]={ id: 148, fld:"",grid:0};
   GXValidFnc[149]={ id: 149, fld:"",grid:0};
   GXValidFnc[150]={ id: 150, fld:"",grid:0};
   GXValidFnc[151]={ id: 151, fld:"",grid:0};
   GXValidFnc[152]={ id:152 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCOPYAPPLICATIONROLEPERMISSIONS",fmt:0,gxz:"ZV15CopyApplicationRolePermissions",gxold:"OV15CopyApplicationRolePermissions",gxvar:"AV15CopyApplicationRolePermissions",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV15CopyApplicationRolePermissions=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV15CopyApplicationRolePermissions=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCOPYAPPLICATIONROLEPERMISSIONS",gx.O.AV15CopyApplicationRolePermissions,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV15CopyApplicationRolePermissions=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCOPYAPPLICATIONROLEPERMISSIONS")},nac:gx.falseFn,evt:"e151k1_client",values:['true','false']};
   this.declareDomainHdlr( 152 , function() {
   });
   GXValidFnc[153]={ id: 153, fld:"",grid:0};
   GXValidFnc[154]={ id: 154, fld:"",grid:0};
   GXValidFnc[155]={ id: 155, fld:"",grid:0};
   GXValidFnc[156]={ id: 156, fld:"",grid:0};
   GXValidFnc[157]={ id: 157, fld:"BTNCANCEL",grid:0,evt:"e181k1_client"};
   GXValidFnc[158]={ id: 158, fld:"",grid:0};
   GXValidFnc[159]={ id: 159, fld:"BTNCONFIRM",grid:0,evt:"e121k2_client",std:"ENTER"};
   this.AV27GUID = "" ;
   this.ZV27GUID = "" ;
   this.OV27GUID = "" ;
   this.AV31Name = "" ;
   this.ZV31Name = "" ;
   this.OV31Name = "" ;
   this.AV21Description = "" ;
   this.ZV21Description = "" ;
   this.OV21Description = "" ;
   this.AV40UseCurrentRepositorAsMasterAuthentication = false ;
   this.ZV40UseCurrentRepositorAsMasterAuthentication = false ;
   this.OV40UseCurrentRepositorAsMasterAuthentication = false ;
   this.AV32NameSpace = "" ;
   this.ZV32NameSpace = "" ;
   this.OV32NameSpace = "" ;
   this.AV25GenerateSessionStatistics = "" ;
   this.ZV25GenerateSessionStatistics = "" ;
   this.OV25GenerateSessionStatistics = "" ;
   this.AV12ConnectionUserName = "" ;
   this.ZV12ConnectionUserName = "" ;
   this.OV12ConnectionUserName = "" ;
   this.AV13ConnectionUserPassword = "" ;
   this.ZV13ConnectionUserPassword = "" ;
   this.OV13ConnectionUserPassword = "" ;
   this.AV11ConfConnectionUserPassword = "" ;
   this.ZV11ConfConnectionUserPassword = "" ;
   this.OV11ConfConnectionUserPassword = "" ;
   this.AV42AuthenticationMasterAuthTypeName = "" ;
   this.ZV42AuthenticationMasterAuthTypeName = "" ;
   this.OV42AuthenticationMasterAuthTypeName = "" ;
   this.AV7AdministratorUserName = "" ;
   this.ZV7AdministratorUserName = "" ;
   this.OV7AdministratorUserName = "" ;
   this.AV8AdministratorUserPassword = "" ;
   this.ZV8AdministratorUserPassword = "" ;
   this.OV8AdministratorUserPassword = "" ;
   this.AV10ConfAdministratorUserPassword = "" ;
   this.ZV10ConfAdministratorUserPassword = "" ;
   this.OV10ConfAdministratorUserPassword = "" ;
   this.AV39UpdateConnectionFile = false ;
   this.ZV39UpdateConnectionFile = false ;
   this.OV39UpdateConnectionFile = false ;
   this.AV29isGAMAdminAccessRepository = false ;
   this.ZV29isGAMAdminAccessRepository = false ;
   this.OV29isGAMAdminAccessRepository = false ;
   this.AV20CreateGAMApplication = false ;
   this.ZV20CreateGAMApplication = false ;
   this.OV20CreateGAMApplication = false ;
   this.AV17CopyFromRepositoryId = 0 ;
   this.ZV17CopyFromRepositoryId = 0 ;
   this.OV17CopyFromRepositoryId = 0 ;
   this.AV18CopyRoles = false ;
   this.ZV18CopyRoles = false ;
   this.OV18CopyRoles = false ;
   this.AV6AdministratorRoleId = 0 ;
   this.ZV6AdministratorRoleId = 0 ;
   this.OV6AdministratorRoleId = 0 ;
   this.AV19CopySecurityPolicies = false ;
   this.ZV19CopySecurityPolicies = false ;
   this.OV19CopySecurityPolicies = false ;
   this.AV14CopyApplication = false ;
   this.ZV14CopyApplication = false ;
   this.OV14CopyApplication = false ;
   this.AV16CopyFromApplicationId = 0 ;
   this.ZV16CopyFromApplicationId = 0 ;
   this.OV16CopyFromApplicationId = 0 ;
   this.AV15CopyApplicationRolePermissions = false ;
   this.ZV15CopyApplicationRolePermissions = false ;
   this.OV15CopyApplicationRolePermissions = false ;
   this.AV27GUID = "" ;
   this.AV31Name = "" ;
   this.AV21Description = "" ;
   this.AV40UseCurrentRepositorAsMasterAuthentication = false ;
   this.AV32NameSpace = "" ;
   this.AV25GenerateSessionStatistics = "" ;
   this.AV12ConnectionUserName = "" ;
   this.AV13ConnectionUserPassword = "" ;
   this.AV11ConfConnectionUserPassword = "" ;
   this.AV42AuthenticationMasterAuthTypeName = "" ;
   this.AV7AdministratorUserName = "" ;
   this.AV8AdministratorUserPassword = "" ;
   this.AV10ConfAdministratorUserPassword = "" ;
   this.AV39UpdateConnectionFile = false ;
   this.AV29isGAMAdminAccessRepository = false ;
   this.AV20CreateGAMApplication = false ;
   this.AV17CopyFromRepositoryId = 0 ;
   this.AV18CopyRoles = false ;
   this.AV6AdministratorRoleId = 0 ;
   this.AV19CopySecurityPolicies = false ;
   this.AV14CopyApplication = false ;
   this.AV16CopyFromApplicationId = 0 ;
   this.AV15CopyApplicationRolePermissions = false ;
   this.AV28Id = 0 ;
   this.Gx_mode = "" ;
   this.AV9AllowOauthAccess = false ;
   this.Events = {"e121k2_client": ["ENTER", true] ,"e131k2_client": ["VUSECURRENTREPOSITORASMASTERAUTHENTICATION.CLICK", true] ,"e181k1_client": ["CANCEL", true] ,"e151k1_client": ["VCOPYAPPLICATIONROLEPERMISSIONS.CLICK", false] ,"e161k1_client": ["VCOPYROLES.CLICK", false] ,"e171k1_client": ["VCOPYAPPLICATION.CLICK", false]};
   this.EvtParms["REFRESH"] = [[{av:'AV40UseCurrentRepositorAsMasterAuthentication',fld:'vUSECURRENTREPOSITORASMASTERAUTHENTICATION',pic:''},{av:'AV39UpdateConnectionFile',fld:'vUPDATECONNECTIONFILE',pic:''},{av:'AV29isGAMAdminAccessRepository',fld:'vISGAMADMINACCESSREPOSITORY',pic:''},{av:'AV20CreateGAMApplication',fld:'vCREATEGAMAPPLICATION',pic:''},{av:'AV18CopyRoles',fld:'vCOPYROLES',pic:''},{av:'AV19CopySecurityPolicies',fld:'vCOPYSECURITYPOLICIES',pic:''},{av:'AV14CopyApplication',fld:'vCOPYAPPLICATION',pic:''},{av:'AV15CopyApplicationRolePermissions',fld:'vCOPYAPPLICATIONROLEPERMISSIONS',pic:''},{av:'AV9AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:'',hsh:true},{av:'AV28Id',fld:'vID',pic:'ZZZZZZZZ9',hsh:true},{av:'Gx_mode',fld:'vMODE',pic:'@!',hsh:true}],[]];
   this.EvtParms["ENTER"] = [[{av:'AV28Id',fld:'vID',pic:'ZZZZZZZZ9',hsh:true},{av:'Gx_mode',fld:'vMODE',pic:'@!',hsh:true},{av:'AV8AdministratorUserPassword',fld:'vADMINISTRATORUSERPASSWORD',pic:''},{av:'AV10ConfAdministratorUserPassword',fld:'vCONFADMINISTRATORUSERPASSWORD',pic:''},{av:'AV13ConnectionUserPassword',fld:'vCONNECTIONUSERPASSWORD',pic:''},{av:'AV11ConfConnectionUserPassword',fld:'vCONFCONNECTIONUSERPASSWORD',pic:''},{av:'AV31Name',fld:'vNAME',pic:''},{av:'AV32NameSpace',fld:'vNAMESPACE',pic:''},{av:'AV21Description',fld:'vDESCRIPTION',pic:''},{av:'AV7AdministratorUserName',fld:'vADMINISTRATORUSERNAME',pic:''},{av:'AV9AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:'',hsh:true},{av:'AV12ConnectionUserName',fld:'vCONNECTIONUSERNAME',pic:''},{ctrl:'vGENERATESESSIONSTATISTICS'},{av:'AV25GenerateSessionStatistics',fld:'vGENERATESESSIONSTATISTICS',pic:''},{av:'AV40UseCurrentRepositorAsMasterAuthentication',fld:'vUSECURRENTREPOSITORASMASTERAUTHENTICATION',pic:''},{av:'AV42AuthenticationMasterAuthTypeName',fld:'vAUTHENTICATIONMASTERAUTHTYPENAME',pic:''},{av:'AV20CreateGAMApplication',fld:'vCREATEGAMAPPLICATION',pic:''},{ctrl:'vCOPYFROMREPOSITORYID'},{av:'AV17CopyFromRepositoryId',fld:'vCOPYFROMREPOSITORYID',pic:'ZZZZZZZZ9'},{av:'AV18CopyRoles',fld:'vCOPYROLES',pic:''},{av:'AV6AdministratorRoleId',fld:'vADMINISTRATORROLEID',pic:'ZZZZZZZZZZZ9'},{av:'AV19CopySecurityPolicies',fld:'vCOPYSECURITYPOLICIES',pic:''},{av:'AV14CopyApplication',fld:'vCOPYAPPLICATION',pic:''},{av:'AV16CopyFromApplicationId',fld:'vCOPYFROMAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV15CopyApplicationRolePermissions',fld:'vCOPYAPPLICATIONROLEPERMISSIONS',pic:''},{av:'AV39UpdateConnectionFile',fld:'vUPDATECONNECTIONFILE',pic:''},{av:'AV29isGAMAdminAccessRepository',fld:'vISGAMADMINACCESSREPOSITORY',pic:''}],[{av:'AV27GUID',fld:'vGUID',pic:''}]];
   this.EvtParms["VUSECURRENTREPOSITORASMASTERAUTHENTICATION.CLICK"] = [[{av:'AV40UseCurrentRepositorAsMasterAuthentication',fld:'vUSECURRENTREPOSITORASMASTERAUTHENTICATION',pic:''}],[{av:'AV32NameSpace',fld:'vNAMESPACE',pic:''},{av:'AV8AdministratorUserPassword',fld:'vADMINISTRATORUSERPASSWORD',pic:''},{av:'AV10ConfAdministratorUserPassword',fld:'vCONFADMINISTRATORUSERPASSWORD',pic:''},{av:'gx.fn.getCtrlProperty("vNAMESPACE","Visible")',ctrl:'vNAMESPACE',prop:'Visible'},{av:'gx.fn.getCtrlProperty("NAMESPACECELL","Visible")',ctrl:'NAMESPACECELL',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TBLUSECURRENTASMASTERREPOSITORY","Visible")',ctrl:'TBLUSECURRENTASMASTERREPOSITORY',prop:'Visible'},{av:'gx.fn.getCtrlProperty("vADMINISTRATORUSERNAME","Caption")',ctrl:'vADMINISTRATORUSERNAME',prop:'Caption'},{av:'gx.fn.getCtrlProperty("vADMINISTRATORUSERPASSWORD","Visible")',ctrl:'vADMINISTRATORUSERPASSWORD',prop:'Visible'},{av:'gx.fn.getCtrlProperty("vCONFADMINISTRATORUSERPASSWORD","Visible")',ctrl:'vCONFADMINISTRATORUSERPASSWORD',prop:'Visible'}]];
   this.EvtParms["VCOPYAPPLICATIONROLEPERMISSIONS.CLICK"] = [[{av:'AV15CopyApplicationRolePermissions',fld:'vCOPYAPPLICATIONROLEPERMISSIONS',pic:''}],[{av:'AV18CopyRoles',fld:'vCOPYROLES',pic:''},{av:'AV14CopyApplication',fld:'vCOPYAPPLICATION',pic:''},{av:'gx.fn.getCtrlProperty("ADMINROLEIDCELL","Visible")',ctrl:'ADMINROLEIDCELL',prop:'Visible'},{av:'gx.fn.getCtrlProperty("COPYFROMMAPPIDCELL","Visible")',ctrl:'COPYFROMMAPPIDCELL',prop:'Visible'}]];
   this.EvtParms["VCOPYROLES.CLICK"] = [[{av:'AV18CopyRoles',fld:'vCOPYROLES',pic:''}],[{av:'AV15CopyApplicationRolePermissions',fld:'vCOPYAPPLICATIONROLEPERMISSIONS',pic:''},{av:'AV14CopyApplication',fld:'vCOPYAPPLICATION',pic:''},{av:'gx.fn.getCtrlProperty("COPYFROMMAPPIDCELL","Visible")',ctrl:'COPYFROMMAPPIDCELL',prop:'Visible'},{av:'gx.fn.getCtrlProperty("ADMINROLEIDCELL","Visible")',ctrl:'ADMINROLEIDCELL',prop:'Visible'}]];
   this.EvtParms["VCOPYAPPLICATION.CLICK"] = [[{av:'AV14CopyApplication',fld:'vCOPYAPPLICATION',pic:''}],[{av:'AV15CopyApplicationRolePermissions',fld:'vCOPYAPPLICATIONROLEPERMISSIONS',pic:''},{av:'AV18CopyRoles',fld:'vCOPYROLES',pic:''},{av:'gx.fn.getCtrlProperty("ADMINROLEIDCELL","Visible")',ctrl:'ADMINROLEIDCELL',prop:'Visible'},{av:'gx.fn.getCtrlProperty("COPYFROMMAPPIDCELL","Visible")',ctrl:'COPYFROMMAPPIDCELL',prop:'Visible'}]];
   this.EvtParms["VALIDV_GENERATESESSIONSTATISTICS"] = [[],[]];
   this.EnterCtrl = ["BTNCONFIRM"];
   this.setVCMap("AV28Id", "vID", 0, "int", 9, 0);
   this.setVCMap("Gx_mode", "vMODE", 0, "char", 3, 0);
   this.setVCMap("AV9AllowOauthAccess", "vALLOWOAUTHACCESS", 0, "boolean", 1, 0);
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(this.gam_repositoryentry);});
