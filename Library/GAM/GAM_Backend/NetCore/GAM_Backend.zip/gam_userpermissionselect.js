/*
               File: GAM_UserPermissionSelect
        Description: GAMExample User Permission Select
             Author: GeneXus .NET Generator version 17_0_10-161416
       Generated on: 6/23/2022 0:54:27.74
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_userpermissionselect', false, function () {
   this.ServerClass =  "gam_userpermissionselect" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_userpermissionselect.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
      this.AV28UserId=gx.fn.getControlValue("vUSERID") ;
      this.AV7ApplicationId=gx.fn.getIntegerValue("vAPPLICATIONID",gx.thousandSeparator) ;
      this.AV10CurrentPage=gx.fn.getIntegerValue("vCURRENTPAGE",gx.thousandSeparator) ;
      this.AV17isOK=gx.fn.getControlValue("vISOK") ;
      this.AV28UserId=gx.fn.getControlValue("vUSERID") ;
      this.AV7ApplicationId=gx.fn.getIntegerValue("vAPPLICATIONID",gx.thousandSeparator) ;
      this.AV10CurrentPage=gx.fn.getIntegerValue("vCURRENTPAGE",gx.thousandSeparator) ;
      this.AV10CurrentPage=gx.fn.getIntegerValue("vCURRENTPAGE",gx.thousandSeparator) ;
   };
   this.Validv_Permissionaccesstype=function()
   {
      return this.validCliEvt("Validv_Permissionaccesstype", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vPERMISSIONACCESSTYPE");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV20PermissionAccessType , "A" ) == 0 || gx.text.compare( this.AV20PermissionAccessType , "D" ) == 0 || gx.text.compare( this.AV20PermissionAccessType , "R" ) == 0 || (gx.text.compare('',this.AV20PermissionAccessType)==0) ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Permission Access Type"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Boolenfilter=function()
   {
      return this.validCliEvt("Validv_Boolenfilter", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vBOOLENFILTER");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV8BoolenFilter , "A" ) == 0 || gx.text.compare( this.AV8BoolenFilter , "T" ) == 0 || gx.text.compare( this.AV8BoolenFilter , "F" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Boolen Filter"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Access=function()
   {
      var currentRow = gx.fn.currentGridRowImpl(71);
      return this.validCliEvt("Validv_Access", 71, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vACCESS");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV5Access , "A" ) == 0 || gx.text.compare( this.AV5Access , "D" ) == 0 || gx.text.compare( this.AV5Access , "R" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Access"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.e112t1_client=function()
   {
      /* 'Hide' Routine */
      this.clearMessages();
      if ( gx.text.compare( gx.fn.getCtrlProperty("FILTERSCONTAINER","Class") , "AdvancedContainer" ) == 0 )
      {
         gx.fn.setCtrlProperty("FILTERSCONTAINER","Class", "AdvancedContainer"+" "+"AdvancedContainerVisible" );
         gx.fn.setCtrlProperty("HIDE","Caption", gx.getMessage( "HIDE FILTERS") );
         gx.fn.setCtrlProperty("HIDE","Class", "HideFiltersButton" );
         gx.fn.setCtrlProperty("GRIDCELL","Class", "WWGridCell" );
      }
      else
      {
         gx.fn.setCtrlProperty("FILTERSCONTAINER","Class", "AdvancedContainer" );
         gx.fn.setCtrlProperty("HIDE","Caption", gx.getMessage( "SHOW FILTERS") );
         gx.fn.setCtrlProperty("HIDE","Class", "ShowFiltersButton" );
         gx.fn.setCtrlProperty("GRIDCELL","Class", "WWGridCellExpanded" );
      }
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("FILTERSCONTAINER","Class")',ctrl:'FILTERSCONTAINER',prop:'Class'},{ctrl:'HIDE',prop:'Caption'},{ctrl:'HIDE',prop:'Class'},{av:'gx.fn.getCtrlProperty("GRIDCELL","Class")',ctrl:'GRIDCELL',prop:'Class'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e182t2_client=function()
   {
      /* Name_Click Routine */
      this.clearMessages();
      this.call("gam_apppermissionentry.aspx", ["DSP", this.AV7ApplicationId, this.AV16Id], null, ["Mode","ApplicationId","GUID"]);
      this.refreshOutputs([{av:'AV16Id',fld:'vID',pic:''},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e122t1_client=function()
   {
      /* 'First' Routine */
      this.clearMessages();
      this.AV10CurrentPage = gx.num.trunc( 1 ,0) ;
      gx.fn.setCtrlProperty("TBFIRST","Class", "SelectedPagingText" );
      gx.fn.setCtrlProperty("TBPREV","Class", "SelectedPagingText" );
      gx.fn.setCtrlProperty("TBFIRST","Enabled", false );
      gx.fn.setCtrlProperty("TBPREV","Enabled", false );
      this.refreshOutputs([{av:'AV10CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'AV10CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e132t1_client=function()
   {
      /* 'Previous' Routine */
      this.clearMessages();
      if ( this.AV10CurrentPage > 1 )
      {
         this.AV10CurrentPage = gx.num.trunc( this.AV10CurrentPage - 1 ,0) ;
      }
      if ( this.AV10CurrentPage == 1 )
      {
         gx.fn.setCtrlProperty("TBFIRST","Class", "SelectedPagingText" );
         gx.fn.setCtrlProperty("TBPREV","Class", "SelectedPagingText" );
         gx.fn.setCtrlProperty("TBFIRST","Enabled", false );
         gx.fn.setCtrlProperty("TBPREV","Enabled", false );
      }
      this.refreshOutputs([{av:'AV10CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'AV10CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e142t1_client=function()
   {
      /* 'Next' Routine */
      this.clearMessages();
      if ( this.AV10CurrentPage == 1 )
      {
         gx.fn.setCtrlProperty("TBFIRST","Class", "PagingText" );
         gx.fn.setCtrlProperty("TBPREV","Class", "PagingText" );
         gx.fn.setCtrlProperty("TBFIRST","Enabled", true );
         gx.fn.setCtrlProperty("TBPREV","Enabled", true );
      }
      this.AV10CurrentPage = gx.num.trunc( this.AV10CurrentPage + 1 ,0) ;
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'},{av:'AV10CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'},{av:'AV10CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e152t2_client=function()
   {
      /* 'AddSelected' Routine */
      return this.executeServerEvent("'ADDSELECTED'", false, null, false, false);
   };
   this.e192t2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e202t1_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,69,70,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91];
   this.GXLastCtrlId =91;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",71,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_userpermissionselect",[],false,1,false,true,0,false,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),false,false,true,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addCheckBox("Select",72,"vSELECT",gx.getMessage( "Select"),"","Select","boolean","true","false",null,true,false,0,"px","WWActionColumn");
   GridwwContainer.addSingleLineEdit("Name",73,"vNAME",gx.getMessage( "Permission name"),"","Name","char",0,"px",254,80,"left","e182t2_client",[],"Name","Name",true,0,false,false,"Attribute",1,"WWColumn");
   GridwwContainer.addSingleLineEdit("Dsc",74,"vDSC",gx.getMessage( "Description"),"","Dsc","char",0,"px",254,80,"left",null,[],"Dsc","Dsc",true,0,false,false,"Attribute",1,"WWColumn WWOptionalColumn");
   GridwwContainer.addComboBox("Access",75,"vACCESS",gx.getMessage( "Permissions options"),"Access","char",null,0,true,false,0,"px","WWColumn");
   GridwwContainer.addSingleLineEdit("Appid",76,"vAPPID",gx.getMessage( "Key Numeric Long"),"","AppId","int",0,"px",12,12,"right",null,[],"Appid","AppId",false,0,false,false,"Attribute",1,"");
   GridwwContainer.addSingleLineEdit("Id",77,"vID",gx.getMessage( "GUID"),"","Id","char",0,"px",40,40,"left",null,[],"Id","Id",false,0,false,false,"Attribute",1,"");
   this.GridwwContainer.emptyText = gx.getMessage( "");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLE2",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TABLE7",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"HIDE",grid:0,evt:"e112t1_client"};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"TEXTBLOCK3", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id: 16, fld:"TABLE3",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"BACK",grid:0,evt:"e202t1_client"};
   GXValidFnc[20]={ id: 20, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"ADDSELECTED",grid:0,evt:"e152t2_client"};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id:24 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSEARCH",fmt:0,gxz:"ZV25Search",gxold:"OV25Search",gxvar:"AV25Search",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV25Search=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV25Search=Value},v2c:function(){gx.fn.setControlValue("vSEARCH",gx.O.AV25Search,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV25Search=this.val()},val:function(){return gx.fn.getControlValue("vSEARCH")},nac:gx.falseFn};
   this.declareDomainHdlr( 24 , function() {
   });
   GXValidFnc[25]={ id: 25, fld:"",grid:0};
   GXValidFnc[26]={ id: 26, fld:"CELLFILTERS",grid:0};
   GXValidFnc[27]={ id: 27, fld:"FILTERSCONTAINER",grid:0};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id: 30, fld:"TABLE8",grid:0};
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id:34 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSEARCHFILTER",fmt:0,gxz:"ZV26SearchFilter",gxold:"OV26SearchFilter",gxvar:"AV26SearchFilter",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV26SearchFilter=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV26SearchFilter=Value},v2c:function(){gx.fn.setControlValue("vSEARCHFILTER",gx.O.AV26SearchFilter,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV26SearchFilter=this.val()},val:function(){return gx.fn.getControlValue("vSEARCHFILTER")},nac:gx.falseFn};
   this.declareDomainHdlr( 34 , function() {
   });
   GXValidFnc[35]={ id: 35, fld:"",grid:0};
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"TABLE4",grid:0};
   GXValidFnc[38]={ id: 38, fld:"",grid:0};
   GXValidFnc[39]={ id: 39, fld:"",grid:0};
   GXValidFnc[40]={ id: 40, fld:"TEXTBLOCK1", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[41]={ id: 41, fld:"",grid:0};
   GXValidFnc[42]={ id: 42, fld:"",grid:0};
   GXValidFnc[43]={ id: 43, fld:"",grid:0};
   GXValidFnc[44]={ id:44 ,lvl:0,type:"char",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Permissionaccesstype,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vPERMISSIONACCESSTYPE",fmt:0,gxz:"ZV20PermissionAccessType",gxold:"OV20PermissionAccessType",gxvar:"AV20PermissionAccessType",ucs:[],op:[44],ip:[44],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV20PermissionAccessType=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV20PermissionAccessType=Value},v2c:function(){gx.fn.setComboBoxValue("vPERMISSIONACCESSTYPE",gx.O.AV20PermissionAccessType);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV20PermissionAccessType=this.val()},val:function(){return gx.fn.getControlValue("vPERMISSIONACCESSTYPE")},nac:gx.falseFn};
   this.declareDomainHdlr( 44 , function() {
   });
   GXValidFnc[45]={ id: 45, fld:"",grid:0};
   GXValidFnc[46]={ id: 46, fld:"",grid:0};
   GXValidFnc[47]={ id: 47, fld:"TABLE5",grid:0};
   GXValidFnc[48]={ id: 48, fld:"",grid:0};
   GXValidFnc[49]={ id: 49, fld:"",grid:0};
   GXValidFnc[50]={ id: 50, fld:"TEXTBLOCK2", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[51]={ id: 51, fld:"",grid:0};
   GXValidFnc[52]={ id: 52, fld:"",grid:0};
   GXValidFnc[53]={ id: 53, fld:"",grid:0};
   GXValidFnc[54]={ id:54 ,lvl:0,type:"char",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Boolenfilter,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBOOLENFILTER",fmt:0,gxz:"ZV8BoolenFilter",gxold:"OV8BoolenFilter",gxvar:"AV8BoolenFilter",ucs:[],op:[54],ip:[54],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV8BoolenFilter=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV8BoolenFilter=Value},v2c:function(){gx.fn.setComboBoxValue("vBOOLENFILTER",gx.O.AV8BoolenFilter);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV8BoolenFilter=this.val()},val:function(){return gx.fn.getControlValue("vBOOLENFILTER")},nac:gx.falseFn};
   this.declareDomainHdlr( 54 , function() {
   });
   GXValidFnc[55]={ id: 55, fld:"GRIDCELL",grid:0};
   GXValidFnc[56]={ id: 56, fld:"GRIDTABLE",grid:0};
   GXValidFnc[57]={ id: 57, fld:"",grid:0};
   GXValidFnc[58]={ id: 58, fld:"",grid:0};
   GXValidFnc[59]={ id: 59, fld:"",grid:0};
   GXValidFnc[60]={ id: 60, fld:"",grid:0};
   GXValidFnc[61]={ id:61 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,multiline:true,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"CTLNAME",fmt:0,gxz:"ZV33GXV1",gxold:"OV33GXV1",gxvar:"GXV1",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.GXV1=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV33GXV1=Value},v2c:function(){gx.fn.setControlValue("CTLNAME",gx.O.GXV1,0)},c2v:function(){if(this.val()!==undefined)gx.O.GXV1=this.val()},val:function(){return gx.fn.getControlValue("CTLNAME")},nac:gx.falseFn};
   GXValidFnc[62]={ id: 62, fld:"",grid:0};
   GXValidFnc[63]={ id: 63, fld:"",grid:0};
   GXValidFnc[64]={ id: 64, fld:"",grid:0};
   GXValidFnc[65]={ id:65 ,lvl:0,type:"svchar",len:100,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGAMUSERNAME",fmt:0,gxz:"ZV30GAMUserName",gxold:"OV30GAMUserName",gxvar:"AV30GAMUserName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV30GAMUserName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV30GAMUserName=Value},v2c:function(){gx.fn.setControlValue("vGAMUSERNAME",gx.O.AV30GAMUserName,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV30GAMUserName=this.val()},val:function(){return gx.fn.getControlValue("vGAMUSERNAME")},nac:gx.falseFn};
   GXValidFnc[66]={ id: 66, fld:"",grid:0};
   GXValidFnc[67]={ id: 67, fld:"",grid:0};
   GXValidFnc[69]={ id: 69, fld:"",grid:0};
   GXValidFnc[70]={ id: 70, fld:"",grid:0};
   GXValidFnc[72]={ id:72 ,lvl:2,type:"boolean",len:4,dec:0,sign:false,ro:0,isacc:0,grid:71,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSELECT",fmt:0,gxz:"ZV27Select",gxold:"OV27Select",gxvar:"AV27Select",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"checkbox",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV27Select=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV27Select=gx.lang.booleanValue(Value)},v2c:function(row){gx.fn.setGridCheckBoxValue("vSELECT",row || gx.fn.currentGridRowImpl(71),gx.O.AV27Select,true)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV27Select=gx.lang.booleanValue(this.val(row))},val:function(row){return gx.fn.getGridControlValue("vSELECT",row || gx.fn.currentGridRowImpl(71))},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[73]={ id:73 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:71,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV18Name",gxold:"OV18Name",gxvar:"AV18Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV18Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV18Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(71),gx.O.AV18Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV18Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(71))},nac:gx.falseFn,evt:"e182t2_client"};
   GXValidFnc[74]={ id:74 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:71,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDSC",fmt:0,gxz:"ZV11Dsc",gxold:"OV11Dsc",gxvar:"AV11Dsc",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV11Dsc=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV11Dsc=Value},v2c:function(row){gx.fn.setGridControlValue("vDSC",row || gx.fn.currentGridRowImpl(71),gx.O.AV11Dsc,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV11Dsc=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vDSC",row || gx.fn.currentGridRowImpl(71))},nac:gx.falseFn};
   GXValidFnc[75]={ id:75 ,lvl:2,type:"char",len:1,dec:0,sign:false,ro:0,isacc:0,grid:71,gxgrid:this.GridwwContainer,fnc:this.Validv_Access,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vACCESS",fmt:0,gxz:"ZV5Access",gxold:"OV5Access",gxvar:"AV5Access",ucs:[],op:[75],ip:[75],nacdep:[],ctrltype:"combo",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV5Access=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV5Access=Value},v2c:function(row){gx.fn.setGridComboBoxValue("vACCESS",row || gx.fn.currentGridRowImpl(71),gx.O.AV5Access);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV5Access=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vACCESS",row || gx.fn.currentGridRowImpl(71))},nac:gx.falseFn};
   GXValidFnc[76]={ id:76 ,lvl:2,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,isacc:0,grid:71,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vAPPID",fmt:0,gxz:"ZV6AppId",gxold:"OV6AppId",gxvar:"AV6AppId",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV6AppId=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV6AppId=gx.num.intval(Value)},v2c:function(row){gx.fn.setGridControlValue("vAPPID",row || gx.fn.currentGridRowImpl(71),gx.O.AV6AppId,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV6AppId=gx.num.intval(this.val(row))},val:function(row){return gx.fn.getGridIntegerValue("vAPPID",row || gx.fn.currentGridRowImpl(71),gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[77]={ id:77 ,lvl:2,type:"char",len:40,dec:0,sign:false,ro:0,isacc:0,grid:71,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",fmt:0,gxz:"ZV16Id",gxold:"OV16Id",gxvar:"AV16Id",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV16Id=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV16Id=Value},v2c:function(row){gx.fn.setGridControlValue("vID",row || gx.fn.currentGridRowImpl(71),gx.O.AV16Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV16Id=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vID",row || gx.fn.currentGridRowImpl(71))},nac:gx.falseFn};
   GXValidFnc[78]={ id: 78, fld:"",grid:0};
   GXValidFnc[79]={ id: 79, fld:"",grid:0};
   GXValidFnc[80]={ id: 80, fld:"TABLE1",grid:0};
   GXValidFnc[81]={ id: 81, fld:"",grid:0};
   GXValidFnc[82]={ id: 82, fld:"",grid:0};
   GXValidFnc[83]={ id: 83, fld:"TBFIRST", format:0,grid:0,evt:"e122t1_client", ctrltype: "textblock"};
   GXValidFnc[84]={ id: 84, fld:"",grid:0};
   GXValidFnc[85]={ id: 85, fld:"TB1", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[86]={ id: 86, fld:"",grid:0};
   GXValidFnc[87]={ id: 87, fld:"TBPREV", format:0,grid:0,evt:"e132t1_client", ctrltype: "textblock"};
   GXValidFnc[88]={ id: 88, fld:"",grid:0};
   GXValidFnc[89]={ id: 89, fld:"TB2", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[90]={ id: 90, fld:"",grid:0};
   GXValidFnc[91]={ id: 91, fld:"TBNEXT", format:0,grid:0,evt:"e142t1_client", ctrltype: "textblock"};
   this.AV25Search = "" ;
   this.ZV25Search = "" ;
   this.OV25Search = "" ;
   this.AV26SearchFilter = "" ;
   this.ZV26SearchFilter = "" ;
   this.OV26SearchFilter = "" ;
   this.AV20PermissionAccessType = "" ;
   this.ZV20PermissionAccessType = "" ;
   this.OV20PermissionAccessType = "" ;
   this.AV8BoolenFilter = "" ;
   this.ZV8BoolenFilter = "" ;
   this.OV8BoolenFilter = "" ;
   this.GXV1 = "" ;
   this.ZV33GXV1 = "" ;
   this.OV33GXV1 = "" ;
   this.AV30GAMUserName = "" ;
   this.ZV30GAMUserName = "" ;
   this.OV30GAMUserName = "" ;
   this.ZV27Select = false ;
   this.OV27Select = false ;
   this.ZV18Name = "" ;
   this.OV18Name = "" ;
   this.ZV11Dsc = "" ;
   this.OV11Dsc = "" ;
   this.ZV5Access = "" ;
   this.OV5Access = "" ;
   this.ZV6AppId = 0 ;
   this.OV6AppId = 0 ;
   this.ZV16Id = "" ;
   this.OV16Id = "" ;
   this.AV25Search = "" ;
   this.AV26SearchFilter = "" ;
   this.AV20PermissionAccessType = "" ;
   this.AV8BoolenFilter = "" ;
   this.GXV1 = "" ;
   this.AV30GAMUserName = "" ;
   this.AV28UserId = "" ;
   this.AV7ApplicationId = 0 ;
   this.AV27Select = false ;
   this.AV18Name = "" ;
   this.AV11Dsc = "" ;
   this.AV5Access = "" ;
   this.AV6AppId = 0 ;
   this.AV16Id = "" ;
   this.AV10CurrentPage = 0 ;
   this.AV17isOK = false ;
   this.AV14GAMApplication = {} ;
   this.Events = {"e152t2_client": ["'ADDSELECTED'", true] ,"e192t2_client": ["ENTER", true] ,"e202t1_client": ["CANCEL", true] ,"e112t1_client": ["'HIDE'", false] ,"e182t2_client": ["VNAME.CLICK", false] ,"e122t1_client": ["'FIRST'", false] ,"e132t1_client": ["'PREVIOUS'", false] ,"e142t1_client": ["'NEXT'", false]};
   this.EvtParms["REFRESH"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV28UserId',fld:'vUSERID',pic:''},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV25Search',fld:'vSEARCH',pic:''},{av:'AV26SearchFilter',fld:'vSEARCHFILTER',pic:''},{ctrl:'vPERMISSIONACCESSTYPE'},{av:'AV20PermissionAccessType',fld:'vPERMISSIONACCESSTYPE',pic:''},{ctrl:'vBOOLENFILTER'},{av:'AV8BoolenFilter',fld:'vBOOLENFILTER',pic:''},{av:'AV10CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}],[]];
   this.EvtParms["GRIDWW.LOAD"] = [[{av:'AV28UserId',fld:'vUSERID',pic:''},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV25Search',fld:'vSEARCH',pic:''},{av:'AV26SearchFilter',fld:'vSEARCHFILTER',pic:''},{ctrl:'vPERMISSIONACCESSTYPE'},{av:'AV20PermissionAccessType',fld:'vPERMISSIONACCESSTYPE',pic:''},{ctrl:'vBOOLENFILTER'},{av:'AV8BoolenFilter',fld:'vBOOLENFILTER',pic:''},{av:'AV10CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}],[{av:'AV30GAMUserName',fld:'vGAMUSERNAME',pic:''},{av:'AV16Id',fld:'vID',pic:''},{av:'AV18Name',fld:'vNAME',pic:''},{av:'AV11Dsc',fld:'vDSC',pic:''},{av:'gx.fn.getCtrlProperty("TBNEXT","Class")',ctrl:'TBNEXT',prop:'Class'}]];
   this.EvtParms["'ADDSELECTED'"] = [[{av:'AV28UserId',fld:'vUSERID',pic:''},{av:'AV27Select',fld:'vSELECT',grid:71,pic:''},{av:'GRIDWW_nFirstRecordOnPage'},{av:'nRC_GXsfl_71',ctrl:'GRIDWW',grid:71,prop:'GridRC',grid:71},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV16Id',fld:'vID',grid:71,pic:''},{av:'AV5Access',fld:'vACCESS',grid:71,pic:''},{av:'AV17isOK',fld:'vISOK',pic:''}],[{av:'AV17isOK',fld:'vISOK',pic:''},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV28UserId',fld:'vUSERID',pic:''}]];
   this.EvtParms["'HIDE'"] = [[{av:'gx.fn.getCtrlProperty("FILTERSCONTAINER","Class")',ctrl:'FILTERSCONTAINER',prop:'Class'}],[{av:'gx.fn.getCtrlProperty("FILTERSCONTAINER","Class")',ctrl:'FILTERSCONTAINER',prop:'Class'},{ctrl:'HIDE',prop:'Caption'},{ctrl:'HIDE',prop:'Class'},{av:'gx.fn.getCtrlProperty("GRIDCELL","Class")',ctrl:'GRIDCELL',prop:'Class'}]];
   this.EvtParms["VNAME.CLICK"] = [[{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV16Id',fld:'vID',pic:''}],[{av:'AV16Id',fld:'vID',pic:''},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["'FIRST'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV28UserId',fld:'vUSERID',pic:''},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV25Search',fld:'vSEARCH',pic:''},{av:'AV26SearchFilter',fld:'vSEARCHFILTER',pic:''},{ctrl:'vPERMISSIONACCESSTYPE'},{av:'AV20PermissionAccessType',fld:'vPERMISSIONACCESSTYPE',pic:''},{ctrl:'vBOOLENFILTER'},{av:'AV8BoolenFilter',fld:'vBOOLENFILTER',pic:''},{av:'AV10CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}],[{av:'AV10CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'}]];
   this.EvtParms["'PREVIOUS'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV28UserId',fld:'vUSERID',pic:''},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV25Search',fld:'vSEARCH',pic:''},{av:'AV26SearchFilter',fld:'vSEARCHFILTER',pic:''},{ctrl:'vPERMISSIONACCESSTYPE'},{av:'AV20PermissionAccessType',fld:'vPERMISSIONACCESSTYPE',pic:''},{ctrl:'vBOOLENFILTER'},{av:'AV8BoolenFilter',fld:'vBOOLENFILTER',pic:''},{av:'AV10CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}],[{av:'AV10CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'}]];
   this.EvtParms["'NEXT'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV28UserId',fld:'vUSERID',pic:''},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV25Search',fld:'vSEARCH',pic:''},{av:'AV26SearchFilter',fld:'vSEARCHFILTER',pic:''},{ctrl:'vPERMISSIONACCESSTYPE'},{av:'AV20PermissionAccessType',fld:'vPERMISSIONACCESSTYPE',pic:''},{ctrl:'vBOOLENFILTER'},{av:'AV8BoolenFilter',fld:'vBOOLENFILTER',pic:''},{av:'AV10CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}],[{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'},{av:'AV10CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.EvtParms["VALIDV_PERMISSIONACCESSTYPE"] = [[],[]];
   this.EvtParms["VALIDV_BOOLENFILTER"] = [[],[]];
   this.EvtParms["VALIDV_ACCESS"] = [[{ctrl:'vACCESS'},{av:'AV5Access',fld:'vACCESS',pic:''}],[{ctrl:'vACCESS'},{av:'AV5Access',fld:'vACCESS',pic:''}]];
   this.setVCMap("AV28UserId", "vUSERID", 0, "char", 40, 0);
   this.setVCMap("AV7ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("AV10CurrentPage", "vCURRENTPAGE", 0, "int", 4, 0);
   this.setVCMap("AV17isOK", "vISOK", 0, "boolean", 4, 0);
   this.setVCMap("AV28UserId", "vUSERID", 0, "char", 40, 0);
   this.setVCMap("AV7ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("AV10CurrentPage", "vCURRENTPAGE", 0, "int", 4, 0);
   this.setVCMap("AV10CurrentPage", "vCURRENTPAGE", 0, "int", 4, 0);
   this.setVCMap("AV28UserId", "vUSERID", 0, "char", 40, 0);
   this.setVCMap("AV7ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("AV10CurrentPage", "vCURRENTPAGE", 0, "int", 4, 0);
   GridwwContainer.addRefreshingVar({rfrVar:"AV28UserId"});
   GridwwContainer.addRefreshingVar({rfrVar:"AV7ApplicationId"});
   GridwwContainer.addRefreshingVar(this.GXValidFnc[24]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[34]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[44]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[54]);
   GridwwContainer.addRefreshingVar({rfrVar:"AV10CurrentPage"});
   GridwwContainer.addRefreshingParm({rfrVar:"AV28UserId"});
   GridwwContainer.addRefreshingParm({rfrVar:"AV7ApplicationId"});
   GridwwContainer.addRefreshingParm(this.GXValidFnc[24]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[34]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[44]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[54]);
   GridwwContainer.addRefreshingParm({rfrVar:"AV10CurrentPage"});
   this.addBCProperty("Gamapplication", ["Name"], this.GXValidFnc[61], "AV14GAMApplication");
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(this.gam_userpermissionselect);});
