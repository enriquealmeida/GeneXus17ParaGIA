/*
               File: GAM_AppPermissionChildren
        Description: Permission Application`s Children
             Author: GeneXus .NET Framework Generator version 17_0_10-161416
       Generated on: 6/23/2022 0:58:0.79
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_apppermissionchildren', false, function () {
   this.ServerClass =  "gam_apppermissionchildren" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_apppermissionchildren.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
      this.AV21PermissionId=gx.fn.getControlValue("vPERMISSIONID") ;
      this.AV7ApplicationId=gx.fn.getIntegerValue("vAPPLICATIONID",gx.thousandSeparator) ;
      this.AV22PermissionList=gx.fn.getControlValue("vPERMISSIONLIST") ;
      this.AV21PermissionId=gx.fn.getControlValue("vPERMISSIONID") ;
      this.AV7ApplicationId=gx.fn.getIntegerValue("vAPPLICATIONID",gx.thousandSeparator) ;
   };
   this.Validv_Accesstype=function()
   {
      var currentRow = gx.fn.currentGridRowImpl(35);
      return this.validCliEvt("Validv_Accesstype", 35, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vACCESSTYPE");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV6AccessType , "A" ) == 0 || gx.text.compare( this.AV6AccessType , "R" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Default Access"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.e161e2_client=function()
   {
      /* Name_Click Routine */
      this.clearMessages();
      this.call("gam_apppermissionentry.aspx", ["DSP", this.AV7ApplicationId, this.AV17Id], null, ["Mode","ApplicationId","GUID"]);
      this.refreshOutputs([{av:'AV17Id',fld:'vID',pic:''},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e171e2_client=function()
   {
      /* Btnchildren_Click Routine */
      this.clearMessages();
      this.call("gam_apppermissionchildren.aspx", [this.AV7ApplicationId, this.AV17Id], null, ["ApplicationId","PermissionId"]);
      this.refreshOutputs([{av:'AV17Id',fld:'vID',pic:''},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e141e2_client=function()
   {
      /* Btndlt_Click Routine */
      return this.executeServerEvent("VBTNDLT.CLICK", true, arguments[0], false, false);
   };
   this.e111e2_client=function()
   {
      /* 'AddNew' Routine */
      return this.executeServerEvent("'ADDNEW'", false, null, false, false);
   };
   this.e151e2_client=function()
   {
      /* 'Back' Routine */
      return this.executeServerEvent("'BACK'", true, arguments[0], false, false);
   };
   this.e181e2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e191e1_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,33,34,36,37,38,39,40,41];
   this.GXLastCtrlId =41;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",35,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_apppermissionchildren",[],false,1,false,true,0,false,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),false,false,false,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addSingleLineEdit("Name",36,"vNAME",gx.getMessage( "Permission name"),"","Name","char",0,"px",120,80,"left","e161e2_client",[],"Name","Name",true,0,false,false,"Attribute",1,"WWColumn");
   GridwwContainer.addSingleLineEdit("Dsc",37,"vDSC",gx.getMessage( "Description"),"","Dsc","char",0,"px",254,80,"left",null,[],"Dsc","Dsc",true,0,false,false,"Attribute",1,"WWColumn WWSecondaryColumn");
   GridwwContainer.addComboBox("Accesstype",38,"vACCESSTYPE",gx.getMessage( "Default Access"),"AccessType","char",null,0,true,false,0,"px","WWColumn WWSecondaryColumn");
   GridwwContainer.addSingleLineEdit("Btnchildren",39,"vBTNCHILDREN","","","BtnChildren","char",0,"px",20,20,"left","e171e2_client",[],"Btnchildren","BtnChildren",true,0,false,false,"TextActionAttribute TextLikeLink",1,"WWTextActionColumn");
   GridwwContainer.addSingleLineEdit("Btndlt",40,"vBTNDLT","","","BtnDlt","char",0,"px",20,20,"left","e141e2_client",[],"Btndlt","BtnDlt",true,0,false,false,"TextActionAttribute TextLikeLink",1,"WWTextActionColumn");
   GridwwContainer.addSingleLineEdit("Id",41,"vID",gx.getMessage( "GUID"),"","Id","char",0,"px",40,40,"left",null,[],"Id","Id",false,0,false,false,"Attribute",1,"");
   this.GridwwContainer.emptyText = gx.getMessage( "");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLE2",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"",grid:0};
   GXValidFnc[10]={ id:10 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILNAME",fmt:0,gxz:"ZV15FilName",gxold:"OV15FilName",gxvar:"AV15FilName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV15FilName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV15FilName=Value},v2c:function(){gx.fn.setControlValue("vFILNAME",gx.O.AV15FilName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV15FilName=this.val()},val:function(){return gx.fn.getControlValue("vFILNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 10 , function() {
   });
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"TABLE3",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"",grid:0};
   GXValidFnc[15]={ id: 15, fld:"CANCEL1",grid:0,evt:"e191e1_client"};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"ADDNEW1",grid:0,evt:"e111e2_client"};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"TABLE1",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id:25 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,multiline:true,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"CTLNAME",fmt:0,gxz:"ZV28GXV1",gxold:"OV28GXV1",gxvar:"GXV1",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.GXV1=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV28GXV1=Value},v2c:function(){gx.fn.setControlValue("CTLNAME",gx.O.GXV1,0)},c2v:function(){if(this.val()!==undefined)gx.O.GXV1=this.val()},val:function(){return gx.fn.getControlValue("CTLNAME")},nac:gx.falseFn};
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id:29 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,multiline:true,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"CTLNAME1",fmt:0,gxz:"ZV29GXV2",gxold:"OV29GXV2",gxvar:"GXV2",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.GXV2=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV29GXV2=Value},v2c:function(){gx.fn.setControlValue("CTLNAME1",gx.O.GXV2,0)},c2v:function(){if(this.val()!==undefined)gx.O.GXV2=this.val()},val:function(){return gx.fn.getControlValue("CTLNAME1")},nac:gx.falseFn};
   GXValidFnc[30]={ id: 30, fld:"",grid:0};
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[36]={ id:36 ,lvl:2,type:"char",len:120,dec:0,sign:false,ro:0,isacc:0,grid:35,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV20Name",gxold:"OV20Name",gxvar:"AV20Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV20Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV20Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(35),gx.O.AV20Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV20Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(35))},nac:gx.falseFn,evt:"e161e2_client"};
   GXValidFnc[37]={ id:37 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:35,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDSC",fmt:0,gxz:"ZV12Dsc",gxold:"OV12Dsc",gxvar:"AV12Dsc",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV12Dsc=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12Dsc=Value},v2c:function(row){gx.fn.setGridControlValue("vDSC",row || gx.fn.currentGridRowImpl(35),gx.O.AV12Dsc,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV12Dsc=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vDSC",row || gx.fn.currentGridRowImpl(35))},nac:gx.falseFn};
   GXValidFnc[38]={ id:38 ,lvl:2,type:"char",len:1,dec:0,sign:false,ro:0,isacc:0,grid:35,gxgrid:this.GridwwContainer,fnc:this.Validv_Accesstype,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vACCESSTYPE",fmt:0,gxz:"ZV6AccessType",gxold:"OV6AccessType",gxvar:"AV6AccessType",ucs:[],op:[38],ip:[38],nacdep:[],ctrltype:"combo",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV6AccessType=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV6AccessType=Value},v2c:function(row){gx.fn.setGridComboBoxValue("vACCESSTYPE",row || gx.fn.currentGridRowImpl(35),gx.O.AV6AccessType);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV6AccessType=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vACCESSTYPE",row || gx.fn.currentGridRowImpl(35))},nac:gx.falseFn};
   GXValidFnc[39]={ id:39 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:35,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNCHILDREN",fmt:0,gxz:"ZV10BtnChildren",gxold:"OV10BtnChildren",gxvar:"AV10BtnChildren",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV10BtnChildren=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV10BtnChildren=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNCHILDREN",row || gx.fn.currentGridRowImpl(35),gx.O.AV10BtnChildren,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV10BtnChildren=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNCHILDREN",row || gx.fn.currentGridRowImpl(35))},nac:gx.falseFn,evt:"e171e2_client"};
   GXValidFnc[40]={ id:40 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:35,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNDLT",fmt:0,gxz:"ZV11BtnDlt",gxold:"OV11BtnDlt",gxvar:"AV11BtnDlt",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV11BtnDlt=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV11BtnDlt=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(35),gx.O.AV11BtnDlt,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV11BtnDlt=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(35))},nac:gx.falseFn,evt:"e141e2_client"};
   GXValidFnc[41]={ id:41 ,lvl:2,type:"char",len:40,dec:0,sign:false,ro:0,isacc:0,grid:35,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",fmt:0,gxz:"ZV17Id",gxold:"OV17Id",gxvar:"AV17Id",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV17Id=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV17Id=Value},v2c:function(row){gx.fn.setGridControlValue("vID",row || gx.fn.currentGridRowImpl(35),gx.O.AV17Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV17Id=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vID",row || gx.fn.currentGridRowImpl(35))},nac:gx.falseFn};
   this.AV15FilName = "" ;
   this.ZV15FilName = "" ;
   this.OV15FilName = "" ;
   this.GXV1 = "" ;
   this.ZV28GXV1 = "" ;
   this.OV28GXV1 = "" ;
   this.GXV2 = "" ;
   this.ZV29GXV2 = "" ;
   this.OV29GXV2 = "" ;
   this.ZV20Name = "" ;
   this.OV20Name = "" ;
   this.ZV12Dsc = "" ;
   this.OV12Dsc = "" ;
   this.ZV6AccessType = "" ;
   this.OV6AccessType = "" ;
   this.ZV10BtnChildren = "" ;
   this.OV10BtnChildren = "" ;
   this.ZV11BtnDlt = "" ;
   this.OV11BtnDlt = "" ;
   this.ZV17Id = "" ;
   this.OV17Id = "" ;
   this.AV15FilName = "" ;
   this.GXV1 = "" ;
   this.GXV2 = "" ;
   this.AV7ApplicationId = 0 ;
   this.AV21PermissionId = "" ;
   this.AV20Name = "" ;
   this.AV12Dsc = "" ;
   this.AV6AccessType = "" ;
   this.AV10BtnChildren = "" ;
   this.AV11BtnDlt = "" ;
   this.AV17Id = "" ;
   this.AV22PermissionList = [ ] ;
   this.AV5GAMApplication = {} ;
   this.AV9AppPermissionParent = {} ;
   this.Events = {"e141e2_client": ["VBTNDLT.CLICK", true] ,"e111e2_client": ["'ADDNEW'", true] ,"e151e2_client": ["'BACK'", true] ,"e181e2_client": ["ENTER", true] ,"e191e1_client": ["CANCEL", true] ,"e161e2_client": ["VNAME.CLICK", false] ,"e171e2_client": ["VBTNCHILDREN.CLICK", false]};
   this.EvtParms["REFRESH"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV15FilName',fld:'vFILNAME',pic:''},{av:'AV21PermissionId',fld:'vPERMISSIONID',pic:''}],[]];
   this.EvtParms["GRIDWW.LOAD"] = [[{av:'AV15FilName',fld:'vFILNAME',pic:''},{av:'AV21PermissionId',fld:'vPERMISSIONID',pic:''}],[{av:'AV11BtnDlt',fld:'vBTNDLT',pic:''},{av:'AV10BtnChildren',fld:'vBTNCHILDREN',pic:''},{av:'AV17Id',fld:'vID',pic:''},{av:'AV20Name',fld:'vNAME',pic:''},{av:'AV12Dsc',fld:'vDSC',pic:''},{ctrl:'vACCESSTYPE'},{av:'AV6AccessType',fld:'vACCESSTYPE',pic:''}]];
   this.EvtParms["VNAME.CLICK"] = [[{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV17Id',fld:'vID',pic:''}],[{av:'AV17Id',fld:'vID',pic:''},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["VBTNDLT.CLICK"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV15FilName',fld:'vFILNAME',pic:''},{av:'AV21PermissionId',fld:'vPERMISSIONID',pic:''},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV17Id',fld:'vID',pic:''}],[]];
   this.EvtParms["VBTNCHILDREN.CLICK"] = [[{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV17Id',fld:'vID',pic:''}],[{av:'AV17Id',fld:'vID',pic:''},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["'ADDNEW'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV15FilName',fld:'vFILNAME',pic:''},{av:'AV21PermissionId',fld:'vPERMISSIONID',pic:''},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV21PermissionId',fld:'vPERMISSIONID',pic:''},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["'BACK'"] = [[{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV22PermissionList',fld:'vPERMISSIONLIST',pic:''}],[{av:'AV22PermissionList',fld:'vPERMISSIONLIST',pic:''},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.EvtParms["VALIDV_ACCESSTYPE"] = [[{ctrl:'vACCESSTYPE'},{av:'AV6AccessType',fld:'vACCESSTYPE',pic:''}],[{ctrl:'vACCESSTYPE'},{av:'AV6AccessType',fld:'vACCESSTYPE',pic:''}]];
   this.setVCMap("AV21PermissionId", "vPERMISSIONID", 0, "char", 40, 0);
   this.setVCMap("AV7ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("AV22PermissionList", "vPERMISSIONLIST", 0, "Collchar", 0, 0);
   this.setVCMap("AV21PermissionId", "vPERMISSIONID", 0, "char", 40, 0);
   this.setVCMap("AV7ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("AV21PermissionId", "vPERMISSIONID", 0, "char", 40, 0);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[10]);
   GridwwContainer.addRefreshingVar({rfrVar:"AV21PermissionId"});
   GridwwContainer.addRefreshingParm(this.GXValidFnc[10]);
   GridwwContainer.addRefreshingParm({rfrVar:"AV21PermissionId"});
   this.addBCProperty("Gamapplication", ["Name"], this.GXValidFnc[25], "AV5GAMApplication");
   this.addBCProperty("Apppermissionparent", ["Name"], this.GXValidFnc[29], "AV9AppPermissionParent");
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(this.gam_apppermissionchildren);});
