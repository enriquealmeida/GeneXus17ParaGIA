/*
               File: GAM_WWAppMenuOptions
        Description: GAMExample WWApp Menu Options
             Author: GeneXus .NET Framework Generator version 17_0_10-161416
       Generated on: 6/23/2022 0:59:23.49
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_wwappmenuoptions', false, function () {
   this.ServerClass =  "gam_wwappmenuoptions" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_wwappmenuoptions.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
      this.AV24SearchFilter=gx.fn.getControlValue("vSEARCHFILTER") ;
      this.AV19MenuId=gx.fn.getIntegerValue("vMENUID",gx.thousandSeparator) ;
      this.AV6ApplicationId=gx.fn.getIntegerValue("vAPPLICATIONID",gx.thousandSeparator) ;
      this.AV24SearchFilter=gx.fn.getControlValue("vSEARCHFILTER") ;
      this.AV19MenuId=gx.fn.getIntegerValue("vMENUID",gx.thousandSeparator) ;
      this.AV6ApplicationId=gx.fn.getIntegerValue("vAPPLICATIONID",gx.thousandSeparator) ;
      this.AV6ApplicationId=gx.fn.getIntegerValue("vAPPLICATIONID",gx.thousandSeparator) ;
      this.AV19MenuId=gx.fn.getIntegerValue("vMENUID",gx.thousandSeparator) ;
   };
   this.Validv_Type=function()
   {
      var currentRow = gx.fn.currentGridRowImpl(37);
      return this.validCliEvt("Validv_Type", 37, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vTYPE");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV25Type , "S" ) == 0 || gx.text.compare( this.AV25Type , "M" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Type"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.e122i1_client=function()
   {
      /* 'AddNew' Routine */
      this.clearMessages();
      this.call("gam_appmenuoptionentry.aspx", ["INS", this.AV6ApplicationId, this.AV19MenuId, 0], null, ["Mode","ApplicationId","MenuId","Id"]);
      this.refreshOutputs([{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e112i1_client=function()
   {
      /* 'GoBack' Routine */
      this.clearMessages();
      this.call("gam_wwappmenus.aspx", [this.AV6ApplicationId], null, ["ApplicationId"]);
      this.refreshOutputs([{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e172i2_client=function()
   {
      /* Name_Click Routine */
      this.clearMessages();
      this.call("gam_appmenuoptionentry.aspx", ["DSP", this.AV6ApplicationId, this.AV19MenuId, this.AV17Id], null, ["Mode","ApplicationId","MenuId","Id"]);
      this.refreshOutputs([{av:'AV17Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e182i2_client=function()
   {
      /* Btnupd_Click Routine */
      this.clearMessages();
      this.call("gam_appmenuoptionentry.aspx", ["UPD", this.AV6ApplicationId, this.AV19MenuId, this.AV17Id], null, ["Mode","ApplicationId","MenuId","Id"]);
      this.refreshOutputs([{av:'AV17Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e192i2_client=function()
   {
      /* Btndlt_Click Routine */
      this.clearMessages();
      this.call("gam_appmenuoptionentry.aspx", ["DLT", this.AV6ApplicationId, this.AV19MenuId, this.AV17Id], null, ["Mode","ApplicationId","MenuId","Id"]);
      this.refreshOutputs([{av:'AV17Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e152i2_client=function()
   {
      /* Btnup_Click Routine */
      return this.executeServerEvent("VBTNUP.CLICK", true, arguments[0], false, false);
   };
   this.e162i2_client=function()
   {
      /* Btndown_Click Routine */
      return this.executeServerEvent("VBTNDOWN.CLICK", true, arguments[0], false, false);
   };
   this.e202i2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e212i2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,35,36,38,39,40,41,42,43,44,45];
   this.GXLastCtrlId =45;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",37,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_wwappmenuoptions",[],false,1,false,true,0,false,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),false,false,false,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addSingleLineEdit("Name",38,"vNAME",gx.getMessage( "Menu name"),"","Name","char",0,"px",120,80,"left","e172i2_client",[],"Name","Name",true,0,false,false,"Attribute TextLikeLink SmallLink",1,"WWColumn");
   GridwwContainer.addSingleLineEdit("Dsc",39,"vDSC",gx.getMessage( "Description"),"","Dsc","char",0,"px",254,80,"left",null,[],"Dsc","Dsc",true,0,false,false,"Attribute",1,"WWColumn WWOptionalColumn");
   GridwwContainer.addComboBox("Type",40,"vTYPE",gx.getMessage( "Type"),"Type","char",null,0,true,false,0,"px","WWColumn WWSecondaryColumn");
   GridwwContainer.addSingleLineEdit("Btnup",41,"vBTNUP","","","BtnUp","char",0,"px",20,20,"left","e152i2_client",[],"Btnup","BtnUp",true,0,false,false,"TextActionAttribute TextLikeLink",1,"WWTextActionColumn");
   GridwwContainer.addSingleLineEdit("Btndown",42,"vBTNDOWN","","","BtnDown","char",0,"px",20,20,"left","e162i2_client",[],"Btndown","BtnDown",true,0,false,false,"TextActionAttribute TextLikeLink",1,"WWTextActionColumn");
   GridwwContainer.addSingleLineEdit("Btnupd",43,"vBTNUPD","","","BtnUpd","char",0,"px",20,20,"left","e182i2_client",[],"Btnupd","BtnUpd",true,0,false,false,"TextActionAttribute TextLikeLink",1,"WWTextActionColumn");
   GridwwContainer.addSingleLineEdit("Btndlt",44,"vBTNDLT","","","BtnDlt","char",0,"px",20,20,"left","e192i2_client",[],"Btndlt","BtnDlt",true,0,false,false,"TextActionAttribute TextLikeLink",1,"WWTextActionColumn");
   GridwwContainer.addSingleLineEdit("Id",45,"vID",gx.getMessage( "Id"),"","Id","int",0,"px",12,12,"right",null,[],"Id","Id",false,0,false,false,"Attribute",1,"");
   this.GridwwContainer.emptyText = gx.getMessage( "");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLETOP",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"TABLE1",grid:0};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"BACK",grid:0,evt:"e112i1_client"};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id: 16, fld:"ADDNEW",grid:0,evt:"e122i1_client"};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id:19 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILNAME",fmt:0,gxz:"ZV15FilName",gxold:"OV15FilName",gxvar:"AV15FilName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV15FilName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV15FilName=Value},v2c:function(){gx.fn.setControlValue("vFILNAME",gx.O.AV15FilName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV15FilName=this.val()},val:function(){return gx.fn.getControlValue("vFILNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 19 , function() {
   });
   GXValidFnc[20]={ id: 20, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"GRIDCELL",grid:0};
   GXValidFnc[22]={ id: 22, fld:"TABLE7",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id: 25, fld:"",grid:0};
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id:27 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,multiline:true,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"CTLNAME",fmt:0,gxz:"ZV28GXV1",gxold:"OV28GXV1",gxvar:"GXV1",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.GXV1=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV28GXV1=Value},v2c:function(){gx.fn.setControlValue("CTLNAME",gx.O.GXV1,0)},c2v:function(){if(this.val()!==undefined)gx.O.GXV1=this.val()},val:function(){return gx.fn.getControlValue("CTLNAME")},nac:gx.falseFn};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id: 30, fld:"",grid:0};
   GXValidFnc[31]={ id:31 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,multiline:true,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"CTLNAME1",fmt:0,gxz:"ZV29GXV2",gxold:"OV29GXV2",gxvar:"GXV2",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.GXV2=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV29GXV2=Value},v2c:function(){gx.fn.setControlValue("CTLNAME1",gx.O.GXV2,0)},c2v:function(){if(this.val()!==undefined)gx.O.GXV2=this.val()},val:function(){return gx.fn.getControlValue("CTLNAME1")},nac:gx.falseFn};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[35]={ id: 35, fld:"",grid:0};
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[38]={ id:38 ,lvl:2,type:"char",len:120,dec:0,sign:false,ro:0,isacc:0,grid:37,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV21Name",gxold:"OV21Name",gxvar:"AV21Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV21Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV21Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(37),gx.O.AV21Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV21Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(37))},nac:gx.falseFn,evt:"e172i2_client"};
   GXValidFnc[39]={ id:39 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:37,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDSC",fmt:0,gxz:"ZV12Dsc",gxold:"OV12Dsc",gxvar:"AV12Dsc",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV12Dsc=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12Dsc=Value},v2c:function(row){gx.fn.setGridControlValue("vDSC",row || gx.fn.currentGridRowImpl(37),gx.O.AV12Dsc,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV12Dsc=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vDSC",row || gx.fn.currentGridRowImpl(37))},nac:gx.falseFn};
   GXValidFnc[40]={ id:40 ,lvl:2,type:"char",len:1,dec:0,sign:false,ro:0,isacc:0,grid:37,gxgrid:this.GridwwContainer,fnc:this.Validv_Type,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vTYPE",fmt:0,gxz:"ZV25Type",gxold:"OV25Type",gxvar:"AV25Type",ucs:[],op:[40],ip:[40],nacdep:[],ctrltype:"combo",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV25Type=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV25Type=Value},v2c:function(row){gx.fn.setGridComboBoxValue("vTYPE",row || gx.fn.currentGridRowImpl(37),gx.O.AV25Type);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV25Type=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vTYPE",row || gx.fn.currentGridRowImpl(37))},nac:gx.falseFn};
   GXValidFnc[41]={ id:41 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:37,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNUP",fmt:0,gxz:"ZV10BtnUp",gxold:"OV10BtnUp",gxvar:"AV10BtnUp",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV10BtnUp=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV10BtnUp=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNUP",row || gx.fn.currentGridRowImpl(37),gx.O.AV10BtnUp,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV10BtnUp=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNUP",row || gx.fn.currentGridRowImpl(37))},nac:gx.falseFn,evt:"e152i2_client"};
   GXValidFnc[42]={ id:42 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:37,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNDOWN",fmt:0,gxz:"ZV9BtnDown",gxold:"OV9BtnDown",gxvar:"AV9BtnDown",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV9BtnDown=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV9BtnDown=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNDOWN",row || gx.fn.currentGridRowImpl(37),gx.O.AV9BtnDown,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV9BtnDown=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNDOWN",row || gx.fn.currentGridRowImpl(37))},nac:gx.falseFn,evt:"e162i2_client"};
   GXValidFnc[43]={ id:43 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:37,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNUPD",fmt:0,gxz:"ZV11BtnUpd",gxold:"OV11BtnUpd",gxvar:"AV11BtnUpd",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV11BtnUpd=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV11BtnUpd=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(37),gx.O.AV11BtnUpd,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV11BtnUpd=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(37))},nac:gx.falseFn,evt:"e182i2_client"};
   GXValidFnc[44]={ id:44 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:37,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNDLT",fmt:0,gxz:"ZV8BtnDlt",gxold:"OV8BtnDlt",gxvar:"AV8BtnDlt",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV8BtnDlt=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV8BtnDlt=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(37),gx.O.AV8BtnDlt,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV8BtnDlt=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(37))},nac:gx.falseFn,evt:"e192i2_client"};
   GXValidFnc[45]={ id:45 ,lvl:2,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,isacc:0,grid:37,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",fmt:0,gxz:"ZV17Id",gxold:"OV17Id",gxvar:"AV17Id",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV17Id=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV17Id=gx.num.intval(Value)},v2c:function(row){gx.fn.setGridControlValue("vID",row || gx.fn.currentGridRowImpl(37),gx.O.AV17Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV17Id=gx.num.intval(this.val(row))},val:function(row){return gx.fn.getGridIntegerValue("vID",row || gx.fn.currentGridRowImpl(37),gx.thousandSeparator)},nac:gx.falseFn};
   this.AV15FilName = "" ;
   this.ZV15FilName = "" ;
   this.OV15FilName = "" ;
   this.GXV1 = "" ;
   this.ZV28GXV1 = "" ;
   this.OV28GXV1 = "" ;
   this.GXV2 = "" ;
   this.ZV29GXV2 = "" ;
   this.OV29GXV2 = "" ;
   this.ZV21Name = "" ;
   this.OV21Name = "" ;
   this.ZV12Dsc = "" ;
   this.OV12Dsc = "" ;
   this.ZV25Type = "" ;
   this.OV25Type = "" ;
   this.ZV10BtnUp = "" ;
   this.OV10BtnUp = "" ;
   this.ZV9BtnDown = "" ;
   this.OV9BtnDown = "" ;
   this.ZV11BtnUpd = "" ;
   this.OV11BtnUpd = "" ;
   this.ZV8BtnDlt = "" ;
   this.OV8BtnDlt = "" ;
   this.ZV17Id = 0 ;
   this.OV17Id = 0 ;
   this.AV15FilName = "" ;
   this.GXV1 = "" ;
   this.GXV2 = "" ;
   this.AV6ApplicationId = 0 ;
   this.AV19MenuId = 0 ;
   this.AV21Name = "" ;
   this.AV12Dsc = "" ;
   this.AV25Type = "" ;
   this.AV10BtnUp = "" ;
   this.AV9BtnDown = "" ;
   this.AV11BtnUpd = "" ;
   this.AV8BtnDlt = "" ;
   this.AV17Id = 0 ;
   this.AV24SearchFilter = "" ;
   this.AV5Application = {} ;
   this.AV18Menu = {} ;
   this.Events = {"e152i2_client": ["VBTNUP.CLICK", true] ,"e162i2_client": ["VBTNDOWN.CLICK", true] ,"e202i2_client": ["ENTER", true] ,"e212i2_client": ["CANCEL", true] ,"e122i1_client": ["'ADDNEW'", false] ,"e112i1_client": ["'GOBACK'", false] ,"e172i2_client": ["VNAME.CLICK", false] ,"e182i2_client": ["VBTNUPD.CLICK", false] ,"e192i2_client": ["VBTNDLT.CLICK", false]};
   this.EvtParms["REFRESH"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV15FilName',fld:'vFILNAME',pic:''},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV24SearchFilter',fld:'vSEARCHFILTER',pic:'',hsh:true}],[]];
   this.EvtParms["GRIDWW.LOAD"] = [[{av:'AV15FilName',fld:'vFILNAME',pic:''},{av:'AV24SearchFilter',fld:'vSEARCHFILTER',pic:'',hsh:true},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV11BtnUpd',fld:'vBTNUPD',pic:''},{av:'AV8BtnDlt',fld:'vBTNDLT',pic:''},{av:'AV10BtnUp',fld:'vBTNUP',pic:''},{av:'AV9BtnDown',fld:'vBTNDOWN',pic:''},{av:'AV17Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV21Name',fld:'vNAME',pic:''},{av:'AV12Dsc',fld:'vDSC',pic:''},{ctrl:'vTYPE'},{av:'AV25Type',fld:'vTYPE',pic:''}]];
   this.EvtParms["'ADDNEW'"] = [[{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["'GOBACK'"] = [[{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["VNAME.CLICK"] = [[{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV17Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV17Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["VBTNUPD.CLICK"] = [[{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV17Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV17Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["VBTNDLT.CLICK"] = [[{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV17Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV17Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["VBTNUP.CLICK"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV15FilName',fld:'vFILNAME',pic:''},{av:'AV24SearchFilter',fld:'vSEARCHFILTER',pic:'',hsh:true},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV17Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[]];
   this.EvtParms["VBTNDOWN.CLICK"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV15FilName',fld:'vFILNAME',pic:''},{av:'AV24SearchFilter',fld:'vSEARCHFILTER',pic:'',hsh:true},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV17Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[]];
   this.EvtParms["ENTER"] = [[],[]];
   this.EvtParms["VALIDV_TYPE"] = [[{ctrl:'vTYPE'},{av:'AV25Type',fld:'vTYPE',pic:''}],[{ctrl:'vTYPE'},{av:'AV25Type',fld:'vTYPE',pic:''}]];
   this.setVCMap("AV24SearchFilter", "vSEARCHFILTER", 0, "char", 254, 0);
   this.setVCMap("AV19MenuId", "vMENUID", 0, "int", 12, 0);
   this.setVCMap("AV6ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("AV24SearchFilter", "vSEARCHFILTER", 0, "char", 254, 0);
   this.setVCMap("AV19MenuId", "vMENUID", 0, "int", 12, 0);
   this.setVCMap("AV6ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("AV6ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("AV19MenuId", "vMENUID", 0, "int", 12, 0);
   this.setVCMap("AV24SearchFilter", "vSEARCHFILTER", 0, "char", 254, 0);
   this.setVCMap("AV19MenuId", "vMENUID", 0, "int", 12, 0);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[19]);
   GridwwContainer.addRefreshingVar({rfrVar:"AV24SearchFilter"});
   GridwwContainer.addRefreshingVar({rfrVar:"AV19MenuId"});
   GridwwContainer.addRefreshingParm(this.GXValidFnc[19]);
   GridwwContainer.addRefreshingParm({rfrVar:"AV24SearchFilter"});
   GridwwContainer.addRefreshingParm({rfrVar:"AV19MenuId"});
   this.addBCProperty("Application", ["Name"], this.GXValidFnc[27], "AV5Application");
   this.addBCProperty("Menu", ["Name"], this.GXValidFnc[31], "AV18Menu");
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(this.gam_wwappmenuoptions);});
