/*
               File: GAM_ConnectionEntry
        Description: Connection
             Author: GeneXus .NET Framework Generator version 17_0_10-161416
       Generated on: 6/23/2022 0:57:21.14
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_connectionentry', false, function () {
   this.ServerClass =  "gam_connectionentry" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_connectionentry.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = true;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
      this.AV26CurrentConnectionKey=gx.fn.getControlValue("vCURRENTCONNECTIONKEY") ;
      this.Gx_mode=gx.fn.getControlValue("vMODE") ;
      this.AV13pConnectionName=gx.fn.getControlValue("vPCONNECTIONNAME") ;
      this.AV19FileXML=gx.fn.getControlValue("vFILEXML") ;
      this.AV26CurrentConnectionKey=gx.fn.getControlValue("vCURRENTCONNECTIONKEY") ;
      this.AV13pConnectionName=gx.fn.getControlValue("vPCONNECTIONNAME") ;
   };
   this.e120m1_client=function()
   {
      /* 'Edit' Routine */
      this.clearMessages();
      this.call("gam_connectionentry.aspx", ["UPD", this.AV13pConnectionName], null, ["Mode","pConnectionName"]);
      this.refreshOutputs([{av:'AV13pConnectionName',fld:'vPCONNECTIONNAME',pic:''}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e130m1_client=function()
   {
      /* 'WWConnKeys' Routine */
      this.clearMessages();
      this.call("gam_connectionentry.aspx", ["KEY", this.AV13pConnectionName], null, ["Mode","pConnectionName"]);
      this.refreshOutputs([{av:'AV13pConnectionName',fld:'vPCONNECTIONNAME',pic:''}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e140m1_client=function()
   {
      /* 'Delete' Routine */
      this.clearMessages();
      this.call("gam_connectionentry.aspx", ["DLT", this.AV13pConnectionName], null, ["Mode","pConnectionName"]);
      this.refreshOutputs([{av:'AV13pConnectionName',fld:'vPCONNECTIONNAME',pic:''}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e240m2_client=function()
   {
      /* 'ShowHide' Routine */
      this.clearMessages();
      if ( gx.text.compare( gx.fn.getCtrlProperty("ACTIONSCONTAINER","Class") , "ActionsContainer" ) == 0 )
      {
         gx.fn.setCtrlProperty("ACTIONSCONTAINER","Class", "ActionsContainerVisible" );
      }
      else
      {
         gx.fn.setCtrlProperty("ACTIONSCONTAINER","Class", "ActionsContainer" );
      }
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("ACTIONSCONTAINER","Class")',ctrl:'ACTIONSCONTAINER',prop:'Class'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e110m1_client=function()
   {
      /* 'GoBack' Routine */
      this.clearMessages();
      this.call("gam_wwconnections.aspx", [], null, []);
      this.refreshOutputs([]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e150m2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e160m2_client=function()
   {
      /* 'GenerateKey' Routine */
      return this.executeServerEvent("'GENERATEKEY'", false, null, false, false);
   };
   this.e170m2_client=function()
   {
      /* 'UseAutomaticConnKey' Routine */
      return this.executeServerEvent("'USEAUTOMATICCONNKEY'", false, null, false, false);
   };
   this.e180m2_client=function()
   {
      /* 'UseCurrentConnKey' Routine */
      return this.executeServerEvent("'USECURRENTCONNKEY'", false, null, false, false);
   };
   this.e190m2_client=function()
   {
      /* 'SaveNewConnKey' Routine */
      return this.executeServerEvent("'SAVENEWCONNKEY'", true, null, false, false);
   };
   this.e220m2_client=function()
   {
      /* 'GenerateConnectionFile' Routine */
      return this.executeServerEvent("'GENERATECONNECTIONFILE'", true, arguments[0], false, false);
   };
   this.e230m2_client=function()
   {
      /* 'DeleteConnectionKey' Routine */
      return this.executeServerEvent("'DELETECONNECTIONKEY'", true, arguments[0], false, false);
   };
   this.e250m1_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126];
   this.GXLastCtrlId =126;
   this.GridwwsysconnsContainer = new gx.grid.grid(this, 2,"WbpLvl2",105,"Gridwwsysconns","Gridwwsysconns","GridwwsysconnsContainer",this.CmpContext,this.IsMasterPage,"gam_connectionentry",[],false,1,false,true,0,false,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),false,false,false,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwsysconnsContainer = this.GridwwsysconnsContainer;
   GridwwsysconnsContainer.addSingleLineEdit("Connectionkey",106,"vCONNECTIONKEY",gx.getMessage( "Connection Key"),"","ConnectionKey","char",0,"px",40,40,"left",null,[],"Connectionkey","ConnectionKey",true,0,false,false,"Attribute",1,"WWColumn");
   GridwwsysconnsContainer.addSingleLineEdit("Iscurrentkey",107,"vISCURRENTKEY","","","isCurrentKey","svchar",0,"px",40,40,"left",null,[],"Iscurrentkey","isCurrentKey",true,0,false,false,"Attribute",1,"WWColumn WWSecondaryColumn");
   GridwwsysconnsContainer.addSingleLineEdit("Btnfile",108,"vBTNFILE","","","BtnFile","svchar",0,"px",40,40,"left","e220m2_client",[],"Btnfile","BtnFile",true,0,false,false,"TextActionAttribute TextLikeLink",1,"WWTextActionColumn");
   GridwwsysconnsContainer.addSingleLineEdit("Btndlt",109,"vBTNDLT","","","BtnDlt","char",0,"px",20,20,"left","e230m2_client",[],"Btndlt","BtnDlt",true,0,false,false,"TextActionAttribute TextLikeLink",1,"WWTextActionColumn");
   this.GridwwsysconnsContainer.emptyText = gx.getMessage( "");
   this.setGrid(GridwwsysconnsContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TBLHEADERTOPWW",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TBTITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"BTNBACK",grid:0,evt:"e110m1_client"};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"TBLHEADERTOP",grid:0};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"TBLHEADERTITLE",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"TBTITLE2", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id: 25, fld:"",grid:0};
   GXValidFnc[26]={ id: 26, fld:"ACTIONSCONTAINER",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id: 29, fld:"TABLEEDIT",grid:0};
   GXValidFnc[30]={ id: 30, fld:"",grid:0};
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[32]={ id: 32, fld:"IMAGE3",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"TEXTBLOCK2", format:0,grid:0,evt:"e120m1_client", ctrltype: "textblock"};
   GXValidFnc[35]={ id: 35, fld:"",grid:0};
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"TBLACCTIONKEYS",grid:0};
   GXValidFnc[38]={ id: 38, fld:"",grid:0};
   GXValidFnc[39]={ id: 39, fld:"",grid:0};
   GXValidFnc[40]={ id: 40, fld:"IMAGE1",grid:0};
   GXValidFnc[41]={ id: 41, fld:"",grid:0};
   GXValidFnc[42]={ id: 42, fld:"TBKEYS", format:0,grid:0,evt:"e130m1_client", ctrltype: "textblock"};
   GXValidFnc[43]={ id: 43, fld:"",grid:0};
   GXValidFnc[44]={ id: 44, fld:"",grid:0};
   GXValidFnc[45]={ id: 45, fld:"TABLE5",grid:0};
   GXValidFnc[46]={ id: 46, fld:"",grid:0};
   GXValidFnc[47]={ id: 47, fld:"",grid:0};
   GXValidFnc[48]={ id: 48, fld:"IMAGE2",grid:0};
   GXValidFnc[49]={ id: 49, fld:"",grid:0};
   GXValidFnc[50]={ id: 50, fld:"DELETECONNECTION", format:0,grid:0,evt:"e140m1_client", ctrltype: "textblock"};
   GXValidFnc[51]={ id: 51, fld:"",grid:0};
   GXValidFnc[52]={ id: 52, fld:"TABLE4",grid:0};
   GXValidFnc[53]={ id: 53, fld:"",grid:0};
   GXValidFnc[54]={ id: 54, fld:"",grid:0};
   GXValidFnc[55]={ id: 55, fld:"TBLMAINDATA",grid:0};
   GXValidFnc[56]={ id: 56, fld:"",grid:0};
   GXValidFnc[57]={ id: 57, fld:"",grid:0};
   GXValidFnc[58]={ id: 58, fld:"",grid:0};
   GXValidFnc[59]={ id: 59, fld:"",grid:0};
   GXValidFnc[60]={ id:60 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCONNECTIONNAME",fmt:0,gxz:"ZV8ConnectionName",gxold:"OV8ConnectionName",gxvar:"AV8ConnectionName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV8ConnectionName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV8ConnectionName=Value},v2c:function(){gx.fn.setControlValue("vCONNECTIONNAME",gx.O.AV8ConnectionName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV8ConnectionName=this.val()},val:function(){return gx.fn.getControlValue("vCONNECTIONNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 60 , function() {
   });
   GXValidFnc[61]={ id: 61, fld:"",grid:0};
   GXValidFnc[62]={ id: 62, fld:"",grid:0};
   GXValidFnc[63]={ id: 63, fld:"",grid:0};
   GXValidFnc[64]={ id: 64, fld:"",grid:0};
   GXValidFnc[65]={ id:65 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERNAME",fmt:0,gxz:"ZV14UserName",gxold:"OV14UserName",gxvar:"AV14UserName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV14UserName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV14UserName=Value},v2c:function(){gx.fn.setControlValue("vUSERNAME",gx.O.AV14UserName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV14UserName=this.val()},val:function(){return gx.fn.getControlValue("vUSERNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 65 , function() {
   });
   GXValidFnc[66]={ id: 66, fld:"",grid:0};
   GXValidFnc[67]={ id: 67, fld:"CELLPWD",grid:0};
   GXValidFnc[68]={ id: 68, fld:"",grid:0};
   GXValidFnc[69]={ id: 69, fld:"",grid:0};
   GXValidFnc[70]={ id:70 ,lvl:0,type:"char",len:254,dec:0,sign:false,isPwd:true,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERPASSWORD",fmt:0,gxz:"ZV15UserPassword",gxold:"OV15UserPassword",gxvar:"AV15UserPassword",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV15UserPassword=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV15UserPassword=Value},v2c:function(){gx.fn.setControlValue("vUSERPASSWORD",gx.O.AV15UserPassword,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV15UserPassword=this.val()},val:function(){return gx.fn.getControlValue("vUSERPASSWORD")},nac:gx.falseFn};
   this.declareDomainHdlr( 70 , function() {
   });
   GXValidFnc[71]={ id: 71, fld:"",grid:0};
   GXValidFnc[72]={ id: 72, fld:"CELLENCKEY",grid:0};
   GXValidFnc[73]={ id: 73, fld:"TBLENCRYPTIONKEY",grid:0};
   GXValidFnc[74]={ id: 74, fld:"",grid:0};
   GXValidFnc[75]={ id: 75, fld:"",grid:0};
   GXValidFnc[76]={ id: 76, fld:"",grid:0};
   GXValidFnc[77]={ id: 77, fld:"",grid:0};
   GXValidFnc[78]={ id:78 ,lvl:0,type:"char",len:32,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vENCRYPTIONKEY",fmt:0,gxz:"ZV18EncryptionKey",gxold:"OV18EncryptionKey",gxvar:"AV18EncryptionKey",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV18EncryptionKey=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV18EncryptionKey=Value},v2c:function(){gx.fn.setControlValue("vENCRYPTIONKEY",gx.O.AV18EncryptionKey,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV18EncryptionKey=this.val()},val:function(){return gx.fn.getControlValue("vENCRYPTIONKEY")},nac:gx.falseFn};
   this.declareDomainHdlr( 78 , function() {
   });
   GXValidFnc[79]={ id: 79, fld:"",grid:0};
   GXValidFnc[80]={ id: 80, fld:"BTNGENKEY",grid:0,evt:"e160m2_client"};
   GXValidFnc[81]={ id: 81, fld:"",grid:0};
   GXValidFnc[82]={ id: 82, fld:"",grid:0};
   GXValidFnc[83]={ id: 83, fld:"TBLCONNKEYS",grid:0};
   GXValidFnc[84]={ id: 84, fld:"",grid:0};
   GXValidFnc[85]={ id: 85, fld:"",grid:0};
   GXValidFnc[86]={ id: 86, fld:"",grid:0};
   GXValidFnc[87]={ id: 87, fld:"TBLADDCONNKEY",grid:0};
   GXValidFnc[88]={ id: 88, fld:"",grid:0};
   GXValidFnc[89]={ id: 89, fld:"",grid:0};
   GXValidFnc[90]={ id: 90, fld:"TABLE1",grid:0};
   GXValidFnc[91]={ id: 91, fld:"",grid:0};
   GXValidFnc[92]={ id: 92, fld:"",grid:0};
   GXValidFnc[93]={ id: 93, fld:"",grid:0};
   GXValidFnc[94]={ id: 94, fld:"",grid:0};
   GXValidFnc[95]={ id:95 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNEWCONNECTIONKEY",fmt:0,gxz:"ZV24NewConnectionKey",gxold:"OV24NewConnectionKey",gxvar:"AV24NewConnectionKey",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV24NewConnectionKey=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV24NewConnectionKey=Value},v2c:function(){gx.fn.setControlValue("vNEWCONNECTIONKEY",gx.O.AV24NewConnectionKey,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV24NewConnectionKey=this.val()},val:function(){return gx.fn.getControlValue("vNEWCONNECTIONKEY")},nac:gx.falseFn};
   this.declareDomainHdlr( 95 , function() {
   });
   GXValidFnc[96]={ id: 96, fld:"",grid:0};
   GXValidFnc[97]={ id: 97, fld:"",grid:0};
   GXValidFnc[98]={ id: 98, fld:"BTNUSERAUTOMATICKEY",grid:0,evt:"e170m2_client"};
   GXValidFnc[99]={ id: 99, fld:"",grid:0};
   GXValidFnc[100]={ id: 100, fld:"BTNUSECURRENTKEY",grid:0,evt:"e180m2_client"};
   GXValidFnc[101]={ id: 101, fld:"",grid:0};
   GXValidFnc[102]={ id: 102, fld:"TBADDCONNKEY", format:0,grid:0,evt:"e190m2_client", ctrltype: "textblock"};
   GXValidFnc[103]={ id: 103, fld:"",grid:0};
   GXValidFnc[104]={ id: 104, fld:"",grid:0};
   GXValidFnc[106]={ id:106 ,lvl:2,type:"char",len:40,dec:0,sign:false,ro:0,isacc:0,grid:105,gxgrid:this.GridwwsysconnsContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCONNECTIONKEY",fmt:0,gxz:"ZV17ConnectionKey",gxold:"OV17ConnectionKey",gxvar:"AV17ConnectionKey",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV17ConnectionKey=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV17ConnectionKey=Value},v2c:function(row){gx.fn.setGridControlValue("vCONNECTIONKEY",row || gx.fn.currentGridRowImpl(105),gx.O.AV17ConnectionKey,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV17ConnectionKey=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vCONNECTIONKEY",row || gx.fn.currentGridRowImpl(105))},nac:gx.falseFn};
   GXValidFnc[107]={ id:107 ,lvl:2,type:"svchar",len:40,dec:0,sign:false,ro:0,isacc:0,grid:105,gxgrid:this.GridwwsysconnsContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vISCURRENTKEY",fmt:0,gxz:"ZV27isCurrentKey",gxold:"OV27isCurrentKey",gxvar:"AV27isCurrentKey",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV27isCurrentKey=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV27isCurrentKey=Value},v2c:function(row){gx.fn.setGridControlValue("vISCURRENTKEY",row || gx.fn.currentGridRowImpl(105),gx.O.AV27isCurrentKey,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV27isCurrentKey=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vISCURRENTKEY",row || gx.fn.currentGridRowImpl(105))},nac:gx.falseFn};
   GXValidFnc[108]={ id:108 ,lvl:2,type:"svchar",len:40,dec:0,sign:false,ro:0,isacc:0,grid:105,gxgrid:this.GridwwsysconnsContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNFILE",fmt:0,gxz:"ZV25BtnFile",gxold:"OV25BtnFile",gxvar:"AV25BtnFile",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV25BtnFile=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV25BtnFile=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNFILE",row || gx.fn.currentGridRowImpl(105),gx.O.AV25BtnFile,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV25BtnFile=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNFILE",row || gx.fn.currentGridRowImpl(105))},nac:gx.falseFn,evt:"e220m2_client"};
   GXValidFnc[109]={ id:109 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:105,gxgrid:this.GridwwsysconnsContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNDLT",fmt:0,gxz:"ZV16BtnDlt",gxold:"OV16BtnDlt",gxvar:"AV16BtnDlt",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV16BtnDlt=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV16BtnDlt=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(105),gx.O.AV16BtnDlt,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV16BtnDlt=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(105))},nac:gx.falseFn,evt:"e230m2_client"};
   GXValidFnc[110]={ id: 110, fld:"",grid:0};
   GXValidFnc[111]={ id: 111, fld:"",grid:0};
   GXValidFnc[112]={ id: 112, fld:"",grid:0};
   GXValidFnc[113]={ id: 113, fld:"",grid:0};
   GXValidFnc[114]={ id:114 ,lvl:0,type:"char",len:2048,dec:0,sign:false,ro:0,multiline:true,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCONNECTIONFILEXML",fmt:0,gxz:"ZV7ConnectionFileXML",gxold:"OV7ConnectionFileXML",gxvar:"AV7ConnectionFileXML",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV7ConnectionFileXML=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV7ConnectionFileXML=Value},v2c:function(){gx.fn.setControlValue("vCONNECTIONFILEXML",gx.O.AV7ConnectionFileXML,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV7ConnectionFileXML=this.val()},val:function(){return gx.fn.getControlValue("vCONNECTIONFILEXML")},nac:gx.falseFn};
   GXValidFnc[115]={ id: 115, fld:"",grid:0};
   GXValidFnc[116]={ id: 116, fld:"",grid:0};
   GXValidFnc[117]={ id: 117, fld:"",grid:0};
   GXValidFnc[118]={ id: 118, fld:"",grid:0};
   GXValidFnc[119]={ id:119 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILECONNECTIONKEY",fmt:0,gxz:"ZV28FileConnectionKey",gxold:"OV28FileConnectionKey",gxvar:"AV28FileConnectionKey",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV28FileConnectionKey=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV28FileConnectionKey=Value},v2c:function(){gx.fn.setControlValue("vFILECONNECTIONKEY",gx.O.AV28FileConnectionKey,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV28FileConnectionKey=this.val()},val:function(){return gx.fn.getControlValue("vFILECONNECTIONKEY")},nac:gx.falseFn};
   this.declareDomainHdlr( 119 , function() {
   });
   GXValidFnc[120]={ id: 120, fld:"",grid:0};
   GXValidFnc[121]={ id: 121, fld:"",grid:0};
   GXValidFnc[122]={ id: 122, fld:"",grid:0};
   GXValidFnc[123]={ id: 123, fld:"",grid:0};
   GXValidFnc[124]={ id: 124, fld:"BTNCANCEL",grid:0,evt:"e250m1_client"};
   GXValidFnc[125]={ id: 125, fld:"",grid:0};
   GXValidFnc[126]={ id: 126, fld:"BTNCONFIRM",grid:0,evt:"e150m2_client",std:"ENTER"};
   this.AV8ConnectionName = "" ;
   this.ZV8ConnectionName = "" ;
   this.OV8ConnectionName = "" ;
   this.AV14UserName = "" ;
   this.ZV14UserName = "" ;
   this.OV14UserName = "" ;
   this.AV15UserPassword = "" ;
   this.ZV15UserPassword = "" ;
   this.OV15UserPassword = "" ;
   this.AV18EncryptionKey = "" ;
   this.ZV18EncryptionKey = "" ;
   this.OV18EncryptionKey = "" ;
   this.AV24NewConnectionKey = "" ;
   this.ZV24NewConnectionKey = "" ;
   this.OV24NewConnectionKey = "" ;
   this.ZV17ConnectionKey = "" ;
   this.OV17ConnectionKey = "" ;
   this.ZV27isCurrentKey = "" ;
   this.OV27isCurrentKey = "" ;
   this.ZV25BtnFile = "" ;
   this.OV25BtnFile = "" ;
   this.ZV16BtnDlt = "" ;
   this.OV16BtnDlt = "" ;
   this.AV7ConnectionFileXML = "" ;
   this.ZV7ConnectionFileXML = "" ;
   this.OV7ConnectionFileXML = "" ;
   this.AV28FileConnectionKey = "" ;
   this.ZV28FileConnectionKey = "" ;
   this.OV28FileConnectionKey = "" ;
   this.AV8ConnectionName = "" ;
   this.AV14UserName = "" ;
   this.AV15UserPassword = "" ;
   this.AV18EncryptionKey = "" ;
   this.AV24NewConnectionKey = "" ;
   this.AV7ConnectionFileXML = "" ;
   this.AV28FileConnectionKey = "" ;
   this.AV13pConnectionName = "" ;
   this.AV17ConnectionKey = "" ;
   this.AV27isCurrentKey = "" ;
   this.AV25BtnFile = "" ;
   this.AV16BtnDlt = "" ;
   this.AV26CurrentConnectionKey = "" ;
   this.Gx_mode = "" ;
   this.AV19FileXML = "" ;
   this.Events = {"e150m2_client": ["ENTER", true] ,"e160m2_client": ["'GENERATEKEY'", true] ,"e170m2_client": ["'USEAUTOMATICCONNKEY'", true] ,"e180m2_client": ["'USECURRENTCONNKEY'", true] ,"e190m2_client": ["'SAVENEWCONNKEY'", true] ,"e220m2_client": ["'GENERATECONNECTIONFILE'", true] ,"e230m2_client": ["'DELETECONNECTIONKEY'", true] ,"e250m1_client": ["CANCEL", true] ,"e120m1_client": ["'EDIT'", false] ,"e130m1_client": ["'WWCONNKEYS'", false] ,"e140m1_client": ["'DELETE'", false] ,"e240m2_client": ["'SHOWHIDE'", false] ,"e110m1_client": ["'GOBACK'", false]};
   this.EvtParms["REFRESH"] = [[{av:'GRIDWWSYSCONNS_nFirstRecordOnPage'},{av:'GRIDWWSYSCONNS_nEOF'},{av:'AV26CurrentConnectionKey',fld:'vCURRENTCONNECTIONKEY',pic:'',hsh:true},{av:'AV19FileXML',fld:'vFILEXML',pic:'',hsh:true},{av:'Gx_mode',fld:'vMODE',pic:'@!',hsh:true}],[]];
   this.EvtParms["GRIDWWSYSCONNS.LOAD"] = [[{av:'AV26CurrentConnectionKey',fld:'vCURRENTCONNECTIONKEY',pic:'',hsh:true}],[{av:'AV17ConnectionKey',fld:'vCONNECTIONKEY',pic:'',hsh:true},{av:'AV27isCurrentKey',fld:'vISCURRENTKEY',pic:''},{av:'AV25BtnFile',fld:'vBTNFILE',pic:''},{av:'AV16BtnDlt',fld:'vBTNDLT',pic:''},{ctrl:'BTNUSECURRENTKEY',prop:'Visible'}]];
   this.EvtParms["ENTER"] = [[{av:'AV8ConnectionName',fld:'vCONNECTIONNAME',pic:''},{av:'Gx_mode',fld:'vMODE',pic:'@!',hsh:true},{av:'AV14UserName',fld:'vUSERNAME',pic:''},{av:'AV15UserPassword',fld:'vUSERPASSWORD',pic:''},{av:'AV18EncryptionKey',fld:'vENCRYPTIONKEY',pic:''},{av:'AV13pConnectionName',fld:'vPCONNECTIONNAME',pic:''}],[]];
   this.EvtParms["'GENERATEKEY'"] = [[],[{av:'AV18EncryptionKey',fld:'vENCRYPTIONKEY',pic:''}]];
   this.EvtParms["'EDIT'"] = [[{av:'AV13pConnectionName',fld:'vPCONNECTIONNAME',pic:''}],[{av:'AV13pConnectionName',fld:'vPCONNECTIONNAME',pic:''}]];
   this.EvtParms["'WWCONNKEYS'"] = [[{av:'AV13pConnectionName',fld:'vPCONNECTIONNAME',pic:''}],[{av:'AV13pConnectionName',fld:'vPCONNECTIONNAME',pic:''}]];
   this.EvtParms["'DELETE'"] = [[{av:'AV13pConnectionName',fld:'vPCONNECTIONNAME',pic:''}],[{av:'AV13pConnectionName',fld:'vPCONNECTIONNAME',pic:''}]];
   this.EvtParms["'SHOWHIDE'"] = [[{av:'gx.fn.getCtrlProperty("ACTIONSCONTAINER","Class")',ctrl:'ACTIONSCONTAINER',prop:'Class'}],[{av:'gx.fn.getCtrlProperty("ACTIONSCONTAINER","Class")',ctrl:'ACTIONSCONTAINER',prop:'Class'}]];
   this.EvtParms["'USEAUTOMATICCONNKEY'"] = [[],[{av:'AV24NewConnectionKey',fld:'vNEWCONNECTIONKEY',pic:''}]];
   this.EvtParms["'USECURRENTCONNKEY'"] = [[{av:'AV26CurrentConnectionKey',fld:'vCURRENTCONNECTIONKEY',pic:'',hsh:true}],[{av:'AV24NewConnectionKey',fld:'vNEWCONNECTIONKEY',pic:''}]];
   this.EvtParms["'SAVENEWCONNKEY'"] = [[{av:'AV24NewConnectionKey',fld:'vNEWCONNECTIONKEY',pic:''},{av:'AV8ConnectionName',fld:'vCONNECTIONNAME',pic:''},{av:'AV13pConnectionName',fld:'vPCONNECTIONNAME',pic:''}],[{av:'AV13pConnectionName',fld:'vPCONNECTIONNAME',pic:''}]];
   this.EvtParms["'GENERATECONNECTIONFILE'"] = [[{av:'AV28FileConnectionKey',fld:'vFILECONNECTIONKEY',pic:''},{av:'AV17ConnectionKey',fld:'vCONNECTIONKEY',pic:'',hsh:true},{av:'AV8ConnectionName',fld:'vCONNECTIONNAME',pic:''},{av:'AV19FileXML',fld:'vFILEXML',pic:'',hsh:true}],[{av:'AV7ConnectionFileXML',fld:'vCONNECTIONFILEXML',pic:''},{av:'AV28FileConnectionKey',fld:'vFILECONNECTIONKEY',pic:''},{av:'gx.fn.getCtrlProperty("vCONNECTIONFILEXML","Visible")',ctrl:'vCONNECTIONFILEXML',prop:'Visible'}]];
   this.EvtParms["'DELETECONNECTIONKEY'"] = [[{av:'AV17ConnectionKey',fld:'vCONNECTIONKEY',pic:'',hsh:true},{av:'AV8ConnectionName',fld:'vCONNECTIONNAME',pic:''},{av:'AV13pConnectionName',fld:'vPCONNECTIONNAME',pic:''}],[{av:'AV13pConnectionName',fld:'vPCONNECTIONNAME',pic:''}]];
   this.EvtParms["'GOBACK'"] = [[],[]];
   this.EnterCtrl = ["BTNCONFIRM"];
   this.setVCMap("AV26CurrentConnectionKey", "vCURRENTCONNECTIONKEY", 0, "char", 40, 0);
   this.setVCMap("Gx_mode", "vMODE", 0, "char", 3, 0);
   this.setVCMap("AV13pConnectionName", "vPCONNECTIONNAME", 0, "char", 254, 0);
   this.setVCMap("AV19FileXML", "vFILEXML", 0, "char", 2048, 0);
   this.setVCMap("AV26CurrentConnectionKey", "vCURRENTCONNECTIONKEY", 0, "char", 40, 0);
   this.setVCMap("AV13pConnectionName", "vPCONNECTIONNAME", 0, "char", 254, 0);
   this.setVCMap("AV26CurrentConnectionKey", "vCURRENTCONNECTIONKEY", 0, "char", 40, 0);
   GridwwsysconnsContainer.addRefreshingVar({rfrVar:"AV26CurrentConnectionKey"});
   GridwwsysconnsContainer.addRefreshingVar({rfrVar:"AV19FileXML"});
   GridwwsysconnsContainer.addRefreshingVar({rfrVar:"Gx_mode"});
   GridwwsysconnsContainer.addRefreshingParm({rfrVar:"AV26CurrentConnectionKey"});
   GridwwsysconnsContainer.addRefreshingParm({rfrVar:"AV19FileXML"});
   GridwwsysconnsContainer.addRefreshingParm({rfrVar:"Gx_mode"});
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(this.gam_connectionentry);});
