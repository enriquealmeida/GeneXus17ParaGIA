/*
               File: GAM_Dashboard
        Description: GAM_Dashboard
             Author: GeneXus .NET Framework Generator version 17_0_10-161416
       Generated on: 6/23/2022 0:59:18.96
       Program type: Main program
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_dashboard', false, function () {
   this.ServerClass =  "gam_dashboard" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_dashboard.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
   };
   this.e132u2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e142u2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3];
   this.GXLastCtrlId =3;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   this.Events = {"e132u2_client": ["ENTER", true] ,"e142u2_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[],[]];
   this.EvtParms["ENTER"] = [[],[]];
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(this.gam_dashboard);});
